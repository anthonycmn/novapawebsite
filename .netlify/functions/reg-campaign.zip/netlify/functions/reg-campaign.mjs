
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};

// netlify/functions/reg-config.mjs
var SUPABASE_URL, LAST_INSTALLMENT_UTC, CLASS_BILL_ANCHOR_UTC, CLASS_SEASON_END_UTC;
var init_reg_config = __esm({
  "netlify/functions/reg-config.mjs"() {
    SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
    LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
    CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
    CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;
  }
});

// netlify/functions/reg-campaign.mjs
init_reg_config();
import crypto from "node:crypto";
var BATCH_SIZE = 25;
var FROM = "Broadway Bound <hello@mail.novapa.org>";
var REPLY_TO = "info@novapa.org";
async function mailer() {
  const { default: nodemailer } = await import("nodemailer");
  return nodemailer.createTransport({
    host: "smtp.resend.com",
    port: 465,
    secure: true,
    auth: { user: "resend", pass: process.env.RESEND_API_KEY }
  });
}
function unsubToken(email) {
  return crypto.createHmac("sha256", process.env.SUPABASE_SERVICE_ROLE_KEY).update(email.toLowerCase()).digest("hex").slice(0, 24);
}
function unsubUrl(email) {
  return `https://novapa.org/api/unsubscribe?e=${encodeURIComponent(email.toLowerCase())}&t=${unsubToken(email)}`;
}
function renderEmail(rawBody, vars) {
  let body = rawBody;
  const personal = body.startsWith("[plain]\n");
  if (personal) body = body.slice("[plain]\n".length);
  for (const [k, v] of Object.entries(vars)) body = body.replaceAll(`{${k}}`, v);
  const LINK = /\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g;
  const IMG_LINE = /^!\[([^\]]*)\]\((https?:\/\/[^)\s]+)\)$/;
  const text = body.split("\n").filter((l) => !IMG_LINE.test(l.trim())).join("\n").replace(LINK, (_, t, u) => `${t}: ${u}`);
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = (s) => esc(s).replace(LINK, '<a href="$2" style="color:#0b5fff">$1</a>');
  let footer = false;
  const blocks = body.split(/\n\s*\n/).map((block) => {
    let lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
    if (lines[0] === "--") {
      footer = true;
      lines = lines.slice(1);
    }
    if (!lines.length) return "";
    const base = footer ? "font-size:13px;color:#8a93a3" : "font-size:16px;color:#1a2233";
    const img = lines.length === 1 && lines[0].match(IMG_LINE);
    if (img) {
      return `<p style="margin:0 0 22px"><img src="${esc(img[2])}" alt="${esc(img[1])}" width="520" style="width:100%;max-width:520px;height:auto;border-radius:12px;display:block;margin:0 auto"></p>`;
    }
    const imgs = lines.map((l) => l.match(IMG_LINE)).filter(Boolean);
    if (imgs.length > 1 && imgs.length === lines.length) {
      const w = Math.floor(520 / imgs.length) - 8;
      return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin:0 0 20px"><tr>` + imgs.map((m) => `<td align="center" style="padding:0 4px" valign="top"><img src="${esc(m[2])}" alt="${esc(m[1])}" width="${w}" style="width:100%;max-width:${w}px;height:auto;border-radius:10px;display:block"></td>`).join("") + `</tr></table>`;
    }
    const btn = !personal && lines.length === 1 && lines[0].match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);
    if (btn) {
      return `<p style="text-align:center;margin:28px 0"><a href="${esc(btn[2])}" style="display:inline-block;background:#f2c94c;color:#0b1b33;font-weight:700;font-size:16px;padding:13px 30px;border-radius:8px;text-decoration:none">${esc(btn[1])}</a></p>`;
    }
    if (lines.every((l) => l.startsWith("* "))) {
      return `<ul style="margin:0 0 18px;padding-left:22px;${base}">` + lines.map((l) => `<li style="margin:5px 0">${inline(l.slice(2))}</li>`).join("") + `</ul>`;
    }
    const bold = lines.length === 1 && lines[0].endsWith(":") && lines[0].length < 40;
    return `<p style="margin:0 0 18px;${base}${bold ? ";font-weight:700" : ""}">${lines.map(inline).join("<br>")}</p>`;
  }).filter(Boolean).join("\n");
  const html = personal ? `<!doctype html><html><body style="margin:0;padding:0"><div style="max-width:560px;padding:8px 4px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;line-height:1.55">
${blocks}
</div></body></html>` : `<!doctype html><html><body style="margin:0;padding:0;background:#f6f7f9"><div style="max-width:560px;margin:0 auto;padding:32px 20px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;line-height:1.55">
<p style="text-align:center;margin:0 0 22px"><img src="https://www.northernvirginiaperformingarts.org/favicon.png" width="56" height="56" alt="NOVAPA" style="display:inline-block"></p>
${blocks}
</div></body></html>`;
  return { text, html };
}
async function svc(path, init = {}) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    ...init,
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", ...init.headers || {} }
  });
  if (!r.ok) throw new Error(`db ${path} ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const t = await r.text();
  return t ? JSON.parse(t) : null;
}
async function svcAll(path) {
  const all = [];
  for (let offset = 0; ; offset += 1e3) {
    const page = await svc(`${path}&limit=1000&offset=${offset}`);
    if (!Array.isArray(page)) break;
    all.push(...page);
    if (page.length < 1e3) break;
  }
  return all;
}
var TEAM = [
  { email: "jason@novapa.org", first: "Jason" },
  { email: "cj@novapa.org", first: "CJ" },
  { email: "todd@novapa.org", first: "Todd" },
  { email: "jen@novapa.org", first: "Jen" }
];
async function audienceFor(campaign) {
  const ccBatch = (campaign.audience || "").match(/^cc_batch_(\d+)$/);
  if (ccBatch) {
    const [contacts, orders2, supp2, sent2] = await Promise.all([
      svcAll(`cc_contacts?batch=eq.${ccBatch[1]}&select=email,first_name&order=email`),
      svcAll("orders?status=in.(paid,confirmed,complete,succeeded)&select=email&order=created_at"),
      svcAll("email_suppressions?scope=eq.marketing&select=email&order=email"),
      svcAll(`campaign_sends?campaign_id=eq.${campaign.id}&select=email&order=email`)
    ]);
    const out2 = /* @__PURE__ */ new Set([
      ...orders2.map((o) => (o.email || "").toLowerCase()),
      ...supp2.map((s) => s.email.toLowerCase()),
      ...sent2.map((s) => s.email.toLowerCase())
    ]);
    const list2 = contacts.filter((c) => !out2.has(c.email.toLowerCase())).map((c) => ({
      email: c.email.toLowerCase(),
      first: (c.first_name || "").trim().split(" ")[0] || "there"
    }));
    return [...TEAM.filter((t) => !out2.has(t.email)), ...list2];
  }
  const seg = (campaign.audience || "").match(/^seg_([a-z0-9_]+)$/);
  if (seg) {
    const [rows, supp2, sent2] = await Promise.all([
      svcAll(`campaign_segments?segment=eq.${seg[1]}&select=email,first_name&order=email`),
      svcAll("email_suppressions?scope=eq.marketing&select=email&order=email"),
      svcAll(`campaign_sends?campaign_id=eq.${campaign.id}&select=email&order=email`)
    ]);
    const out2 = /* @__PURE__ */ new Set([
      ...supp2.map((s) => s.email.toLowerCase()),
      ...sent2.map((s) => s.email.toLowerCase())
    ]);
    const list2 = rows.filter((r) => !out2.has(r.email.toLowerCase())).map((r) => ({
      email: r.email.toLowerCase(),
      first: (r.first_name || "").trim().split(" ")[0] || "there"
    }));
    return [...TEAM.filter((t) => !out2.has(t.email)), ...list2];
  }
  const [fams, orders, supp, sent] = await Promise.all([
    svcAll("families?select=email,parent_name&order=email"),
    svcAll("orders?status=in.(paid,confirmed,complete,succeeded)&select=email&order=created_at"),
    svcAll("email_suppressions?scope=eq.marketing&select=email&order=email"),
    svcAll(`campaign_sends?campaign_id=eq.${campaign.id}&select=email&order=email`)
  ]);
  const buyers = new Set(orders.map((o) => (o.email || "").toLowerCase()));
  const out = /* @__PURE__ */ new Set([...supp.map((s) => s.email.toLowerCase()), ...sent.map((s) => s.email.toLowerCase())]);
  const list = fams.filter((f) => {
    const e = (f.email || "").toLowerCase();
    if (!e.includes("@") || e.endsWith("@novapa.org")) return false;
    if (campaign.audience === "non_buyers_2027" && buyers.has(e)) return false;
    if (campaign.audience === "buyers_2027" && !buyers.has(e)) return false;
    return !out.has(e);
  }).map((f) => ({
    email: (f.email || "").toLowerCase(),
    first: (f.parent_name || "").trim().split(" ")[0] || "there"
  }));
  return [...TEAM.filter((t) => !out.has(t.email)), ...list];
}
var reg_campaign_default = async () => {
  if (process.env.CONTEXT && process.env.CONTEXT !== "production") {
    return new Response("skipped: non-production context", { status: 200 });
  }
  const due = await svc(`campaigns?status=in.(scheduled,sending)&scheduled_at=lte.${encodeURIComponent((/* @__PURE__ */ new Date()).toISOString())}&order=scheduled_at&limit=1`);
  if (!due.length) return new Response("no due campaigns", { status: 200 });
  const c = due[0];
  const audience = await audienceFor(c);
  if (!audience.length) {
    await svc(`campaigns?id=eq.${c.id}`, { method: "PATCH", body: JSON.stringify({ status: "done" }) });
    return new Response(`campaign ${c.name}: done (${c.sent_count} total)`, { status: 200 });
  }
  if (c.status === "scheduled") {
    await svc(`campaigns?id=eq.${c.id}`, { method: "PATCH", body: JSON.stringify({ status: "sending" }) });
  }
  const transporter = await mailer();
  const batch = audience.slice(0, BATCH_SIZE);
  let sent = 0;
  for (const r of batch) {
    const unsub = unsubUrl(r.email);
    const { text, html } = renderEmail(c.body, { first_name: r.first, unsub_url: unsub, email: encodeURIComponent(r.email) });
    try {
      const claim = await svc("campaign_sends?select=email", {
        method: "POST",
        headers: { Prefer: "resolution=ignore-duplicates,return=representation" },
        body: JSON.stringify({ campaign_id: c.id, email: r.email })
      });
      if (!Array.isArray(claim) || !claim.length) continue;
      await transporter.sendMail({
        from: FROM,
        replyTo: REPLY_TO,
        to: r.email,
        subject: c.subject,
        text,
        html,
        headers: {
          "List-Unsubscribe": `<${unsub}>`,
          "List-Unsubscribe-Post": "List-Unsubscribe=One-Click"
        }
      });
      sent++;
    } catch (e) {
      console.error(`campaign send failed ${r.email}:`, e.message);
    }
  }
  await svc(`campaigns?id=eq.${c.id}`, {
    method: "PATCH",
    body: JSON.stringify({ sent_count: c.sent_count + sent })
  });
  return new Response(`campaign ${c.name}: sent ${sent}, ~${audience.length - sent} remaining`, { status: 200 });
};
var config = { schedule: "*/5 * * * *" };
export {
  FROM,
  REPLY_TO,
  config,
  reg_campaign_default as default,
  mailer,
  renderEmail,
  unsubToken,
  unsubUrl
};
