
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reg-pay.mjs
import Stripe from "stripe";

// netlify/functions/reg-email.mjs
var GOLD = "#C8892A";
var NAVY = "#0F1E36";
function money(cents) {
  return "$" + (cents / 100).toLocaleString(
    "en-US",
    { minimumFractionDigits: cents % 100 ? 2 : 0, maximumFractionDigits: 2 }
  );
}
var TEEN_CONS_IDS = [1960809, 1960811, 1805731];
function spansLunch(w) {
  if (!w || !w.time) return false;
  const m = String(w.time).match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm).*?(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i);
  if (!m) return false;
  const h = (hh, ap) => Number(hh) % 12 + (/pm/i.test(ap) ? 12 : 0);
  return h(m[1], m[3]) <= 12 && h(m[4], m[6]) >= 13;
}
var VENUE = "National Conference Center, 18945 Conference Center Drive, Plaza C, Leesburg, VA 20176";
var MAP_URL = "https://maps.google.com/?q=" + encodeURIComponent("18945 Conference Center Drive, Plaza C, Leesburg, VA 20176");
var ARRIVAL = [
  "We are in the South Building at Plaza C. Park in the south parking lot and take the walkway to the entrance.",
  "Parking is free. If you are dropping off and going, drop off at Plaza C.",
  "Pick-up has a fifteen minute grace period, after which a late fee of $15 per fifteen minutes applies. If you are running late, email us rather than letting us wonder.",
  "Email is our official channel for schedule changes, closures, casting and billing. Please check your spam folder and mark us as safe."
];
async function svcJson(path) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) return [];
  try {
    const r = await fetch(
      `https://tlkuqwsqicxcjdmumkje.supabase.co/rest/v1/${path}`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } }
    );
    return r.ok ? await r.json() : [];
  } catch {
    return [];
  }
}
function whenFrom(classTimes) {
  const t = Array.isArray(classTimes) ? classTimes[0] : null;
  if (!t) return null;
  const day = (t.title_text || "").trim();
  const time = Array.isArray(t.primary_text) ? t.primary_text.join(", ") : t.primary_text || "";
  const span = t.secondary_text || t.product_detail_date || "";
  return { day, time, span };
}
async function itemDetails(m, pi) {
  const piId = pi && pi.id;
  let rows = [];
  if (piId) {
    const orders = await svcJson(`orders?stripe_payment_intent=eq.${encodeURIComponent(piId)}&select=id,order_items(camper_name,show,band,activity_id,unit_price_cents)`);
    rows = orders[0] && orders[0].order_items || [];
    if (orders[0]) m.__order_id = orders[0].id;
  }
  if (!rows.length) return [];
  const ids = [...new Set(rows.map((r) => r.activity_id).filter(Boolean))];
  const acts = ids.length ? await svcJson(`activities?id=in.(${ids.join(",")})&select=id,name,class_times,location,age_range,category,price_cents`) : [];
  const byId = Object.fromEntries(acts.map((a) => [a.id, a]));
  return rows.map((r) => {
    const a = r.activity_id ? byId[r.activity_id] : null;
    const w = a ? whenFrom(a.class_times) : null;
    const summer = !!r.show;
    const price = a ? a.price_cents || 0 : 99500;
    const cat = a ? a.category : "camp";
    return {
      camper: r.camper_name || "Camper",
      name: a ? a.name : r.show ? `${r.show} (ages ${r.band})` : "Program",
      ages: a && a.age_range ? a.age_range : "",
      when: w,
      price: r.unit_price_cents,
      // Day-1 auditions run for every production. Teen Conservatory casts
      // audition months ahead, so Sweeney, Hadestown and Dear Evan Hansen are
      // out — Mean Girls is back on day-1 auditions (Jason, Aug 13).
      production: summer || cat === "camp" && price >= 5e4 && !TEEN_CONS_IDS.includes(a && a.id),
      allDay: summer || spansLunch(w)
    };
  });
}
function confirmationHtml(m, pi, details) {
  const items = (m.order_desc || "").split("; ").filter(Boolean);
  const today = pi.amount_received ?? pi.amount;
  const total = parseInt(m.total_cents || "0", 10) || today;
  const nInst = parseInt(m.n_installments || "0", 10) || 0;
  const instCents = parseInt(m.installment_cents || "0", 10) || 0;
  const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  let planLine = "Paid in full \u2014 no future charges.";
  if (m.plan === "deposit" && nInst && firstInst) {
    const d = new Date(firstInst * 1e3);
    planLine = `Then ${nInst} monthly payments of ${money(instCents)}, automatic on your card, starting ${months[d.getUTCMonth()]} 1, ${d.getUTCFullYear()} \u2014 fully paid before your program begins.`;
  } else if (m.plan === "subscription") {
    planLine = m.first_month_free === "1" ? "Your first month is on us. Your card is saved, and monthly tuition starts October 1, then the 1st of each month through June 1, 2027. Nothing is charged in September, and nothing is charged after June \u2014 the plan ends itself. Cancel any time with 30 days' notice." : "Today's payment covers your first month, so there is no further charge in September. Monthly tuition then runs October 1 and the 1st of each month through June 1, 2027, and the plan ends itself after that. Cancel any time with 30 days' notice.";
  }
  const esc = (x) => String(x == null ? "" : x).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const rows = details && details.length ? details.map((d) => `<tr><td style="padding:14px 0;border-bottom:1px solid #eee8dd">
        <div style="font-size:15px;color:#2a2a2a"><b>${esc(d.name)}</b></div>
        <div style="font-size:14px;color:#444;margin-top:3px">Participant: ${esc(d.camper)}${d.ages ? " &nbsp;\xB7&nbsp; ages " + esc(d.ages) : ""}</div>
        ${d.when && (d.when.day || d.when.span) ? `<div style="font-size:14px;color:#444;margin-top:3px">
          ${d.when.day ? "<b>" + esc(d.when.day) + "</b>" : ""}${d.when.time ? " &nbsp;" + esc(d.when.time) : ""}
          ${d.when.span ? "<br>" + esc(d.when.span) : ""}</div>` : ""}
        ${d.price != null ? `<div style="font-size:13.5px;color:#666;margin-top:3px">${money(d.price)}</div>` : ""}
      </td></tr>`).join("") : items.map(
    (it) => `<tr><td style="padding:10px 0;border-bottom:1px solid #eee8dd;font-size:15px;color:#2a2a2a">${it}</td></tr>`
  ).join("");
  const couponRow = m.coupon ? `<tr><td style="padding:6px 0;font-size:14px;color:#2e7d4f">Coupon ${m.coupon}: \u2212${money(parseInt(m.coupon_cents || "0", 10))}</td></tr>` : "";
  return `<!doctype html><html><body style="margin:0;padding:0;background:#f5f2ec;font-family:Georgia,'Times New Roman',serif">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;padding:28px 12px"><tr><td align="center">
    <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e7e0d2">
      <tr><td style="background:${NAVY};padding:26px 32px;text-align:center">
        <div style="font-family:Georgia,serif;font-size:22px;letter-spacing:0.25em;color:#ffffff">NOVA<span style="color:#E8B84B">PA</span></div>
        <div style="font-size:12px;letter-spacing:0.18em;color:#c9b47a;text-transform:uppercase;margin-top:6px">Registration Confirmed</div>
      </td></tr>
      <tr><td style="padding:30px 32px 8px">
        <p style="margin:0 0 16px;font-size:16px;color:#2a2a2a">Hi${m.parent_name ? " " + m.parent_name.split(" ")[0] : ""},</p>
        <p style="margin:0 0 18px;font-size:15px;color:#444;line-height:1.6">You're in! Here's what we have for your family:</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">${rows}</table>
      </td></tr>
      <tr><td style="padding:14px 32px 6px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf7f0;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            ${couponRow ? '<table role="presentation" width="100%">' + couponRow + "</table>" : ""}
            <div style="font-size:15px;color:#2a2a2a"><b>Paid today: ${money(today)}</b>${total > today ? " &nbsp;\xB7&nbsp; Program total: " + money(total) : ""}</div>
            <div style="font-size:13.5px;color:#666;margin-top:6px;line-height:1.5">${planLine}</div>
          </td></tr>
        </table>
      </td></tr>

      ${details && details.some((d) => d.production) ? `
      <tr><td style="padding:14px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">Auditions are on day one</div>
            <p style="margin:8px 0 0;font-size:14px;color:#2a2a2a;line-height:1.6">
              This is for placement only. <b>Everyone who registered is in the company and everyone is cast.</b>
              Day one decides where your performer fits best.</p>
            <p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">What to bring to the audition:</p>
            <ul style="margin:6px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              <li style="margin:4px 0"><b>A song they are confident singing.</b> Sixteen to thirty-two bars is plenty. Sheet music in a binder, or a backing track on a phone with a way to play it.</li>
              <li style="margin:4px 0"><b>A short monologue</b> if they have one they like. Optional, but it helps us.</li>
              <li style="margin:4px 0">Themselves, warmed up, having slept.</li>
            </ul>
            <p style="margin:10px 0 0;font-size:13.5px;color:#666;line-height:1.6">
              An audition here is not a test anyone can fail. We already want them. We are listening for where their
              voice sits and which room will stretch them most.</p>
          </td></tr>
        </table>
      </td></tr>` : ""}
      <tr><td style="padding:14px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">What to bring and wear</div>
            <ul style="margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              ${details && details.some((d) => d.allDay) ? `<li style="margin:4px 0"><b>A packed lunch and a snack.</b> Lunch is not provided. No delivery during the day, and that one is firm.</li>` : ""}
              <li style="margin:4px 0">A refillable <b>water bottle</b>, named.</li>
              <li style="margin:4px 0">A <b>pencil</b>. Not a pen.</li>
              <li style="margin:4px 0">A <b>layer</b> \u2014 the building runs cold.</li>
              <li style="margin:4px 0">Anything with a name on it stands a much better chance of coming home.</li>
            </ul>
            <p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">
              <b>What to wear:</b> modest movement clothes with closed-toed shoes or dance shoes. Leggings, joggers or
              athletic shorts with a fitted top or t-shirt, things that stay put when you bend, lift your arms or lie on
              the floor. Hair tied back and off the face. No dangling jewellery or smartwatches. On the build crew,
              closed-toed shoes are the rule, not a suggestion.</p>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:18px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf7f0;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">Where to go</div>
            <div style="font-size:14.5px;color:#2a2a2a;margin-top:6px">${VENUE}</div>
            <div style="margin-top:8px"><a href="${MAP_URL}" style="color:${GOLD};font-size:14px">Get directions &rarr;</a></div>
            <ul style="margin:12px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              ${ARRIVAL.map((l) => `<li style="margin:4px 0">${l}</li>`).join("")}
            </ul>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:14px 32px 6px">
        <p style="margin:0;font-size:13.5px;color:#555;line-height:1.7">
          ${m.__order_id ? `Reference: order ${String(m.__order_id).slice(0, 8).toUpperCase()}<br>` : ""}
          ${m.fsa_eligible === "1" && pi && pi.id ? `Using a Dependent Care FSA? <a href="https://www.northernvirginiaperformingarts.org/api/fsa-receipt?pi=${pi.id}" style="color:${GOLD}">View and print your dependent-care receipt</a> (Tax ID 99-1421341).<br>` : m.fsa_eligible === "1" ? "Using a Dependent Care FSA? Print your dependent-care receipt from your confirmation page (Tax ID 99-1421341).<br>" : ""}
        </p>
      </td></tr>
      <tr><td style="padding:8px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">If plans change</div>
            <ul style="margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              <li style="margin:5px 0"><b>All fees are non-refundable</b>, including for missed days or early withdrawal. Registering is a commitment to the full fee.</li>
              <li style="margin:5px 0"><b>Withdrawals must be in writing, at least one month before the program starts.</b> Email <a href="mailto:info@novapa.org" style="color:${GOLD}">info@novapa.org</a> \u2014 only written notice inside that window can be moved to another program.</li>
              <li style="margin:5px 0">Drop out <b>60 or more days before the start</b> with the balance paid in full and what you paid can go toward a future program as a tuition credit, good for one year, administrative fees apply.</li>
              <li style="margin:5px 0">Withdrawals <b>inside 30 days</b> are not eligible for a credit, and partial payments are non-transferable.</li>
              <li style="margin:5px 0">If we cancel for weather or an emergency, a make-up is scheduled rather than a refund issued.</li>
            </ul>
            ${m.insured === "1" ? `<p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">
              <b>You bought tuition insurance</b>, so a withdrawal refunds 100% at 90&ndash;76 days before the start,
              75% at 75&ndash;51 days, 50% at 50&ndash;31 days, and 0% inside 30 days. Email us to start a claim.
              The premium itself is non-refundable and is deducted from the refund.</p>` : ""}
            <p style="margin:10px 0 0;font-size:13px;color:#777;line-height:1.6">
              This is a summary. The full terms are at
              <a href="https://www.northernvirginiaperformingarts.org/policies#refunds" style="color:${GOLD}">novapa.org/policies</a>
              and they govern.</p>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:20px 32px 26px">
        <p style="margin:0;font-size:13px;color:#999;line-height:1.6;border-top:1px solid #eee8dd;padding-top:16px">
          Northern Virginia Performing Arts \xB7 Leesburg, VA<br>
          <a href="mailto:info@novapa.org" style="color:${GOLD}">info@novapa.org</a> \xB7 (571) 571-2120
        </p>
      </td></tr>
    </table>
  </td></tr></table><table role="presentation" cellpadding="0" cellspacing="0" style="margin:22px auto 0"><tr><td style="background:${GOLD};border-radius:8px"><a href="https://www.northernvirginiaperformingarts.org/register/account.html" style="display:inline-block;padding:12px 26px;color:#fff;text-decoration:none;font-weight:700;font-size:14px;font-family:Georgia,serif">View or update in My NOVAPA</a></td></tr></table><p style="font-size:12px;color:#999;text-align:center;margin-top:8px;font-family:Georgia,serif">Your registrations, tickets, and credits live in your account.</p></body></html>`;
}
async function ccFor(email) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key || !email) return null;
  try {
    const r = await fetch(
      `https://tlkuqwsqicxcjdmumkje.supabase.co/rest/v1/families?select=cc_email&email=eq.${encodeURIComponent(email.toLowerCase())}&limit=1`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } }
    );
    const rows = r.ok ? await r.json() : [];
    return rows[0]?.cc_email || null;
  } catch {
    return null;
  }
}
var DCU_PINK = "#ff2d8f";
var DCU_INK = "#0d0d0d";
var DCU_VENUE = "The National Conference Center, 18665 Conference Center Drive, Leesburg, VA 20176";
var DCU_TRACKS = {
  970601: { when: "October 15\u201318, 2026", where: DCU_VENUE, note: null },
  970602: {
    when: "October 24\u201325, 2026",
    where: "Online \u2014 live callback weekend",
    note: "Your join details will be emailed to you before the event."
  },
  // No submission deadline is published on the site, so this promises a
  // follow-up rather than inventing a date.
  970603: {
    when: "Asynchronous \u2014 submit on your own schedule",
    where: "Online",
    note: "Your upload link and submission window will be emailed to you."
  }
};
function dcuConfirmationHtml(m, pi) {
  const paid = pi ? pi.amount_received ?? pi.amount ?? 0 : 0;
  const total = parseInt(m.total_cents || "0", 10) || 0;
  const nInst = parseInt(m.n_installments || "0", 10) || 0;
  const instCents = parseInt(m.installment_cents || "0", 10) || 0;
  const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
  const track = DCU_TRACKS[parseInt(m.activity_id || "0", 10)] || {};
  const fmt = (t) => new Date(t * 1e3).toLocaleDateString(
    "en-US",
    { month: "long", day: "numeric", year: "numeric", timeZone: "UTC" }
  );
  const row = (k, v) => `<tr><td style="padding:7px 16px 7px 0;color:#666;font-size:14px">${k}</td><td style="padding:7px 0;font-size:14px;font-weight:600">${v}</td></tr>`;
  const facts = [
    row("Student", m.student_name || "\u2014"),
    row("Track", (m.order_desc || "").split(" \u2014 ").slice(1).join(" \u2014 ") || "DC Unifieds 2026"),
    track.when ? row("When", track.when) : "",
    track.where ? row("Where", track.where) : ""
  ].join("");
  const money2 = [
    row("Total", money(total)),
    row("Paid today", money(paid)),
    nInst ? row(
      "Remaining",
      `${nInst} \xD7 ${money(instCents)}, charged automatically starting ${fmt(firstInst)}`
    ) : ""
  ].join("");
  return `<div style="font-family:Helvetica,Arial,sans-serif;background:#f4f4f5;padding:28px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden">
<tr><td style="background:${DCU_INK};padding:26px 28px">
  <div style="color:#fff;font-size:20px;font-weight:800;letter-spacing:.14em">DC UNIFIEDS</div>
  <div style="color:${DCU_PINK};font-size:13px;font-weight:700;margin-top:5px">COLLEGE AUDITIONS 2026</div>
</td></tr>
<tr><td style="padding:28px">
  <div style="font-size:23px;font-weight:800;color:${DCU_INK};margin-bottom:6px">You're registered.</div>
  <p style="font-size:15px;color:#444;line-height:1.6;margin:0 0 22px">
    Thanks${m.parent_name ? ", " + m.parent_name : ""} \u2014 your spot is confirmed. Here are the details.</p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse">${facts}</table>
  ${track.note ? `<p style="font-size:14px;color:#444;line-height:1.6;margin:18px 0 0">${track.note}</p>` : ""}
  <div style="height:1px;background:#e5e5e5;margin:22px 0"></div>
  <div style="font-size:12px;font-weight:800;letter-spacing:.1em;color:#888;margin-bottom:8px">PAYMENT</div>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse">${money2}</table>
  ${nInst ? `<p style="font-size:13px;color:#666;line-height:1.6;margin:14px 0 0">
    Installments are charged to the card you used today. All installments are paid in full before the event.</p>` : ""}
  <div style="height:1px;background:#e5e5e5;margin:22px 0"></div>
  <p style="font-size:14px;color:#444;line-height:1.6;margin:0">
    Questions about your registration, or need to change something?
    Email <a href="mailto:support@dcunifieds.com" style="color:${DCU_PINK};font-weight:700">support@dcunifieds.com</a>.</p>
</td></tr>
<tr><td style="padding:18px 28px 24px;background:#fafafa;color:#888;font-size:12px;line-height:1.6">
  DC Unifieds \xB7 ${DCU_VENUE}<br>All sales final. Installment plans must be paid in full prior to the event.
</td></tr>
</table></div>`;
}
async function sendConfirmationEmail(m, pi) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS || !m.email) return;
  const { default: nodemailer } = await import("nodemailer");
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  if (m.brand === "dcu") {
    await transporter.sendMail({
      from: `DC Unifieds <${process.env.SMTP_USER}>`,
      replyTo: "support@dcunifieds.com",
      to: m.email,
      subject: "You're registered \u2014 DC Unifieds 2026",
      html: dcuConfirmationHtml(m, pi)
    });
    return;
  }
  const cc = await ccFor(m.email);
  let details = [];
  try {
    details = await itemDetails(m, pi);
  } catch (e) {
    console.error("item details failed:", e.message);
  }
  await transporter.sendMail({
    from: `NOVAPA <${process.env.SMTP_USER}>`,
    replyTo: "info@novapa.org",
    to: m.email,
    ...cc ? { cc } : {},
    subject: "You're in \u2014 NOVAPA registration confirmed",
    html: confirmationHtml(m, pi, details)
  });
}

// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
var PRICE_CENTS = 99500;
var DEPOSIT_PER_ITEM_CENTS = 18e3;
var EARLYBIRD_END = "2026-08-15T23:59:59-04:00";
var MAX_INSTALLMENTS = 8;
var PAY_FULL_CUTOFF_DAYS = 14;
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var SPECIAL_PLANS = {
  "SOK20": {
    email: "isabel.castillejo13@gmail.com",
    waivePlanFee: true,
    months: 10
    // Mrs. Sok, approved Jul 30 2026. Her 20% comes from the global
    // show+camp combo now — this code only waives the plan fee and
    // stretches her schedule to 10 months.
  },
  "SMITH20": {
    // Jamie + Christie Smith — Grace. Todd approved 20% off (Aug 5 2026) for
    // Grace doing four productions across summer, fall and spring; the launch
    // ladder lapsed Aug 15 before they registered Frozen + Mermaid, and CJ
    // extended the discount (Aug 17, "Voice Classes" thread). Both household
    // emails are unlocked: the paid summer order lives under Christie's
    // address, the email thread under Jamie's.
    email: ["christieamstadt@gmail.com", "jcs@smith82.com"],
    pctOffList: 20,
    // Plus the retro true-up Todd approved Aug 10: their summer camps were
    // paid at the 15% two-show rate, and with four productions the whole set
    // is 20% — $49.75 x 2 = $99.50 back, delivered as a credit on this
    // checkout (the coupons row has carried the amount since Aug 10).
    creditCents: 9950,
    // months: 5 spreads the Frozen+Mermaid cart Sep-Jan instead of the
    // 1-payment collapse the Sep-15 Frozen start forces — same concession
    // as ANSELL0. Jamie asked Aug 24; Jason approved same day.
    months: 5
  },
  "ANSELL0": {
    email: "ajansell@gmail.com",
    waivePlanFee: true,
    months: 5
    // Andrea Ansell, approved by Todd Aug 7 2026: no 5% plan fee. months: 5
    // spreads her Frozen+Mermaid cart Sep-Jan instead of the 1-payment
    // collapse the Sep-15 Frozen start forces (Jason, Aug 7).
  },
  "ANSELLO": {
    email: "ajansell@gmail.com",
    waivePlanFee: true,
    months: 5
    // Same waiver, letter-O spelling — ANSELL0 ends in a zero that reads as
    // the letter O in most fonts, and Andrea typed the O. Both work.
  }
};
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;
var SIBLING_PCT = 5;
var INSURANCE_PCT = 10;
var PLAN_FEE_PCT = 5;
var DAY_CAMP_MAX_CENTS = 2e4;
var DAY_CAMP_PACK_ID = 990010;
var DAY_CAMP_PACK_SIZE = 5;
var DAY_CAMP_PACK_CENTS = 34900;
var DAY_CAMP_PACK_CREDITS = 5;
var DAY_CAMP_PACK_SNOW_BONUS = 2;
var DAY_CAMP_PACK_SNOW_END = /* @__PURE__ */ new Date("2026-09-08T03:59:59Z");
var isSnowDayName = (name) => /snow day/i.test(name || "");
var SHOWS = {
  httyd: "How to Train Your Dragon JR.",
  charlie: "Charlie and the Chocolate Factory JR.",
  trolls: "Trolls The Musical JR."
};
var CAMP_START = {
  httyd: "2027-07-05",
  charlie: "2027-07-19",
  trolls: "2027-08-02"
};
function showStartFor(name) {
  if (/frozen/i.test(name)) return "2026-09-15";
  if (/mermaid/i.test(name)) return "2027-02-03";
  if (/mean girls/i.test(name)) return "2027-06-14";
  if (/sweeney/i.test(name)) return "2026-10-23";
  if (/hadestown/i.test(name)) return "2027-03-05";
  return null;
}
var COACHING_ID_MIN = 97e4;
var COACHING_ID_MAX = 979999;
var isCoachingId = (id) => Number.isFinite(id) && id >= COACHING_ID_MIN && id <= COACHING_ID_MAX;
var kindOf = (it) => it.offering_kind || null;
var isCoaching = (it) => kindOf(it) ? kindOf(it) === "coaching" : isCoachingId(it.activity_id);
function specialFromCouponRow(row) {
  if (!row) return null;
  const locked = Array.isArray(row.email_lock) && row.email_lock.length > 0;
  if (!row.pct_off_list && !row.waive_plan_fee && !row.plan_months && !locked) return null;
  const s = {};
  if (locked) s.email = row.email_lock;
  if (row.pct_off_list) s.pctOffList = row.pct_off_list;
  if (row.waive_plan_fee) s.waivePlanFee = true;
  if (row.plan_months) s.months = row.plan_months;
  if (row.balance_cents) s.creditCents = row.balance_cents;
  if (Array.isArray(row.scope_activity_ids) && row.scope_activity_ids.length) s.scopeActivityIds = row.scope_activity_ids;
  if (Array.isArray(row.scope_shows) && row.scope_shows.length) s.scopeShows = row.scope_shows;
  return s;
}
function specialCovers(special, it) {
  if (!special) return false;
  const scoped = special.scopeActivityIds && special.scopeActivityIds.length || special.scopeShows && special.scopeShows.length;
  if (!scoped) return true;
  if (it.activity_id && (special.scopeActivityIds || []).includes(it.activity_id)) return true;
  if (it.show && (special.scopeShows || []).includes(it.show)) return true;
  return false;
}
function perKidRate(nCampsForKid, now = /* @__PURE__ */ new Date()) {
  if (now > new Date(EARLYBIRD_END)) return 0;
  if (nCampsForKid >= 3) return 0.2;
  if (nCampsForKid === 2) return 0.15;
  if (nCampsForKid === 1) return 0.1;
  return 0;
}
function classMonthlyCents(nClassesForKid) {
  if (nClassesForKid <= 0) return 0;
  if (nClassesForKid === 1) return 9e3;
  if (nClassesForKid === 2) return 15900;
  return 19900 + (nClassesForKid - 3) * 4e3;
}
function siblingActive(isBB, now = /* @__PURE__ */ new Date()) {
  return isBB ? now > new Date(EARLYBIRD_END) : true;
}
function installmentDates(startISO, now = /* @__PURE__ */ new Date(), forceMonths = 0) {
  const dates = [];
  let d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, 4, 0, 0));
  if (forceMonths > 0) {
    while (dates.length < forceMonths) {
      dates.push(Math.floor(d.getTime() / 1e3));
      d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1, 4, 0, 0));
    }
    return dates;
  }
  if (!startISO) return [];
  const start = /* @__PURE__ */ new Date(startISO + "T00:00:00-04:00");
  const lastOk = new Date(Math.min(
    start.getTime() - PAY_FULL_CUTOFF_DAYS * 864e5,
    LAST_INSTALLMENT_UTC
  ));
  while (d <= lastOk && dates.length < MAX_INSTALLMENTS) {
    dates.push(Math.floor(d.getTime() / 1e3));
    d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1, 4, 0, 0));
  }
  return dates;
}
var kidKey = (it) => it && it.ci != null ? "i" + it.ci : it && it.camper || "?";
function priceCart(cart, plan, opts = {}) {
  const now = opts.now || /* @__PURE__ */ new Date();
  const insurance = !!opts.insurance;
  const special = opts.special || null;
  const couponPct = special ? 0 : Math.min(100, Math.max(0, opts.couponPct || 0));
  const couponFixed = special ? Math.max(0, special.creditCents || 0) : Math.max(0, opts.couponFixedCents || 0);
  const priorCampsByKid = opts.priorCampsByKid || {};
  const priorShowsByKid = opts.priorShowsByKid || {};
  const isDayCampItem = (it) => kindOf(it) ? kindOf(it) === "day_camp" : !it.show && !isCoaching(it) && (it.price_cents || 0) <= DAY_CAMP_MAX_CENTS;
  const isCounted = (it) => it.show || !isDayCampItem(it) && !isCoaching(it) && it.activity_id !== DAY_CAMP_PACK_ID;
  const countByKid = {};
  for (const it of cart) if (isCounted(it)) {
    const k = kidKey(it);
    countByKid[k] = (countByKid[k] || 0) + 1;
  }
  for (const k of Object.keys(countByKid)) {
    countByKid[k] += (priorCampsByKid[k] || 0) + (priorShowsByKid[k] || 0);
  }
  const kidOrder = [...new Set(cart.map(kidKey))];
  const firstKid = kidOrder[0];
  const priced = cart.map((it) => {
    if (it.activity_id === DAY_CAMP_PACK_ID) {
      return { ...it, unit: DAY_CAMP_PACK_CENTS, rate: 0, daycamp: true, pack: true };
    }
    if (it.show) {
      const kid2 = kidKey(it);
      const rate2 = perKidRate(countByKid[kid2], now);
      let unit2 = Math.round(PRICE_CENTS * (1 - rate2));
      if (rate2 === 0 && siblingActive(true, now) && kid2 !== firstKid) {
        unit2 = Math.round(unit2 * (1 - SIBLING_PCT / 100));
      }
      return { ...it, unit: unit2, rate: rate2 };
    }
    if (isCoaching(it)) {
      return { ...it, unit: it.price_cents || 0, rate: 0, daycamp: true, coaching: true };
    }
    if (isDayCampItem(it)) {
      let unit2 = it.price_cents;
      if (kidKey(it) !== firstKid) {
        unit2 = Math.round(unit2 * (1 - SIBLING_PCT / 100));
      }
      return { ...it, unit: unit2, rate: 0, daycamp: true };
    }
    const kid = kidKey(it);
    const rate = perKidRate(countByKid[kid], now);
    let unit = Math.round((it.price_cents || 0) * (1 - rate));
    if (rate === 0 && siblingActive(true, now) && kid !== firstKid) {
      unit = Math.round(unit * (1 - SIBLING_PCT / 100));
    }
    return { ...it, unit, rate };
  }).map((it) => {
    if (!special || !special.pctOffList || it.daycamp || !specialCovers(special, it)) return it;
    const list = it.show ? PRICE_CENTS : it.price_cents || 0;
    const rate = special.pctOffList / 100;
    return { ...it, unit: Math.round(list * (1 - rate)), rate };
  });
  const byKidDc = {};
  for (const it of priced) {
    if (it.daycamp && !it.coaching && !it.pack) (byKidDc[kidKey(it)] = byKidDc[kidKey(it)] || []).push(it);
  }
  const dayPacksByKid = {};
  for (const k of Object.keys(byKidDc)) {
    const arr = byKidDc[k];
    const packs = Math.floor(arr.length / DAY_CAMP_PACK_SIZE);
    if (!packs) continue;
    dayPacksByKid[k] = packs;
    arr.sort((a, b) => b.unit - a.unit);
    const packed = arr.slice(0, packs * DAY_CAMP_PACK_SIZE);
    const target = packs * DAY_CAMP_PACK_CENTS;
    const packedSum = packed.reduce((sum, it) => sum + it.unit, 0);
    let acc = 0;
    packed.forEach((it, i) => {
      const u = i === packed.length - 1 ? target - acc : Math.round(it.unit * target / packedSum);
      acc += u;
      it.unit = u;
      it.pack = true;
    });
  }
  const creditsByKid = opts.creditsByKid || {};
  const creditsUsed = {};
  const redeemable = priced.filter((it) => it.daycamp && !it.coaching && !it.pack).sort((a, b) => b.unit - a.unit);
  for (const it of redeemable) {
    const k = kidKey(it);
    const bal = creditsByKid[k];
    if (!bal) continue;
    const kind = isSnowDayName(it.name) ? "snow" : "day";
    const used = creditsUsed[k] || (creditsUsed[k] = { day: 0, snow: 0 });
    if ((bal[kind] || 0) - used[kind] > 0) {
      used[kind] += 1;
      it.unit = 0;
      it.credited = true;
    }
  }
  const grossSubtotal = priced.reduce((s, it) => s + it.unit, 0);
  const couponCents = couponPct ? Math.round(grossSubtotal * couponPct / 100) : Math.min(couponFixed, grossSubtotal);
  const subtotal = grossSubtotal - couponCents;
  const couponFactor = grossSubtotal > 0 ? subtotal / grossSubtotal : 1;
  const listInsurableCents = priced.reduce(
    (s, it) => s + (it.daycamp ? 0 : it.show ? PRICE_CENTS : it.price_cents || 0),
    0
  );
  const insuranceCents = insurance ? Math.round(listInsurableCents * INSURANCE_PCT / 100 * (1 - couponPct / 100)) : 0;
  const totalCents = subtotal + insuranceCents;
  const starts = cart.map((it) => it.show ? CAMP_START[it.show] : it.start || showStartFor(it.name || "")).filter(Boolean).sort();
  const schedule = installmentDates(starts[0], now, special && special.months || 0);
  const payFullOnly = schedule.length === 0;
  if (plan === "full" || payFullOnly) {
    return {
      items: priced,
      creditsUsed,
      dayPacksByKid,
      subtotal,
      couponCents,
      insuranceCents,
      totalCents,
      planFeeCents: 0,
      todayCents: totalCents,
      installmentCents: 0,
      installmentDatesUTC: [],
      payFullOnly,
      plan: "full"
    };
  }
  const dayCampCents = priced.reduce((s, it) => s + (it.daycamp ? it.unit : 0), 0);
  const planFeeCents = special && special.waivePlanFee ? 0 : Math.round(subtotal * PLAN_FEE_PCT / 100);
  if (special) {
    const planCount = priced.filter((it) => !it.daycamp).length;
    const depositCents = Math.min(DEPOSIT_PER_ITEM_CENTS * planCount + dayCampCents, subtotal);
    const remainder = subtotal - depositCents;
    if (remainder <= 0) {
      return {
        items: priced,
        creditsUsed,
        dayPacksByKid,
        subtotal,
        couponCents,
        insuranceCents,
        totalCents,
        planFeeCents: 0,
        todayCents: totalCents,
        installmentCents: 0,
        installmentDatesUTC: [],
        payFullOnly: false,
        plan: "full"
      };
    }
    return {
      items: priced,
      creditsUsed,
      dayPacksByKid,
      subtotal,
      couponCents,
      insuranceCents,
      totalCents: totalCents + planFeeCents,
      planFeeCents,
      todayCents: depositCents + insuranceCents,
      installmentCents: Math.max(0, Math.ceil((remainder + planFeeCents) / schedule.length)),
      installmentDatesUTC: schedule,
      payFullOnly: false,
      plan: "deposit"
    };
  }
  const financeable = subtotal - dayCampCents + planFeeCents;
  const payments = schedule.length + 1;
  const installmentCents = Math.floor(financeable / payments);
  const todayShare = financeable - installmentCents * schedule.length;
  if (installmentCents <= 0) {
    return {
      items: priced,
      creditsUsed,
      dayPacksByKid,
      subtotal,
      couponCents,
      insuranceCents,
      totalCents,
      planFeeCents: 0,
      todayCents: totalCents,
      installmentCents: 0,
      installmentDatesUTC: [],
      payFullOnly: false,
      plan: "full"
    };
  }
  return {
    items: priced,
    creditsUsed,
    dayPacksByKid,
    subtotal,
    couponCents,
    insuranceCents,
    totalCents: totalCents + planFeeCents,
    planFeeCents,
    todayCents: todayShare + insuranceCents + dayCampCents,
    installmentCents,
    installmentDatesUTC: schedule,
    payFullOnly: false,
    plan: "deposit"
  };
}

// netlify/functions/reg-pay.mjs
var CAMP_STARTS = { httyd: "2027-07-05", charlie: "2027-07-19", trolls: "2027-08-02" };
function fsaUnder13(bday, startISO) {
  if (!bday) return false;
  const b = /* @__PURE__ */ new Date(bday + "T00:00:00"), s = startISO ? /* @__PURE__ */ new Date(startISO + "T00:00:00") : /* @__PURE__ */ new Date();
  let age = s.getFullYear() - b.getFullYear();
  if (s.getMonth() < b.getMonth() || s.getMonth() === b.getMonth() && s.getDate() < b.getDate()) age--;
  return age < 13;
}
async function familyIdByEmail(email, hdrs) {
  const e = encodeURIComponent(email);
  const r = await fetch(`${SUPABASE_URL}/rest/v1/families?or=(email.ilike.${e},cc_email.ilike.${e})&select=id,email`, { headers: hdrs });
  const rows = await r.json();
  if (!Array.isArray(rows) || !rows.length) return null;
  const exact = rows.find((f) => String(f.email || "").toLowerCase() === String(email || "").toLowerCase());
  return (exact || rows[0]).id;
}
async function anonRpc(fn, args, jwt) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: `Bearer ${jwt || SUPABASE_ANON_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(args)
  });
  if (!res.ok) return null;
  return res.json();
}
var reg_pay_default = async (req) => {
  if (req.method !== "POST") {
    return Response.json({ error: "method_not_allowed" }, { status: 405 });
  }
  if (!process.env.STRIPE_SECRET_KEY) {
    return Response.json({ error: "payments_not_configured" }, { status: 503 });
  }
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "bad_json" }, { status: 400 });
  }
  const { hold_id, plan, parent_name } = body || {};
  const insurance = !!(body || {}).insurance;
  const couponCode = String((body || {}).coupon || "").trim();
  if (!hold_id || !["deposit", "full", "subscription"].includes(plan)) {
    return Response.json({ error: "bad_request" }, { status: 400 });
  }
  let email = "";
  let guest = false;
  let hold = null;
  if (jwt) {
    const userRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${jwt}` }
    });
    if (!userRes.ok) return Response.json({ error: "unauthorized" }, { status: 401 });
    const user = await userRes.json();
    email = (user.email || "").toLowerCase();
    if (!email) return Response.json({ error: "unauthorized" }, { status: 401 });
    hold = await anonRpc("get_my_hold", { p_hold_id: hold_id }, jwt);
  } else {
    guest = true;
    email = String((body || {}).email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return Response.json({ error: "unauthorized" }, { status: 401 });
    }
    if (!/^[0-9a-f-]{36}$/.test(String(hold_id))) {
      return Response.json({ error: "hold_not_found" }, { status: 404 });
    }
    const svcKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const rows = await (await fetch(
      `${SUPABASE_URL}/rest/v1/holds?id=eq.${hold_id}&email=eq.${encodeURIComponent(email)}&select=id,items,status,expires_at&limit=1`,
      { headers: { apikey: svcKey, Authorization: `Bearer ${svcKey}` } }
    )).json();
    hold = rows?.[0] || null;
  }
  if (!hold || !hold.items) return Response.json({ error: "hold_not_found" }, { status: 404 });
  if (hold.status !== "active" || new Date(hold.expires_at) < /* @__PURE__ */ new Date()) {
    return Response.json({ error: "hold_expired" }, { status: 409 });
  }
  const kidBdays = {};
  if (guest) {
    const kb = (body || {}).bdays;
    if (kb && typeof kb === "object") {
      for (const [k, v] of Object.entries(kb)) {
        if (typeof k === "string" && /^\d{4}-\d{2}-\d{2}$/.test(String(v))) kidBdays[k.slice(0, 60)] = v;
      }
    }
  }
  let couponPct = 0, couponFixedCents = 0, special = null;
  if (couponCode) {
    const c = await anonRpc("check_coupon", { p_code: couponCode });
    special = SPECIAL_PLANS[couponCode.toUpperCase()] || null;
    if (!special && c) {
      try {
        const svcKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
        const rows = await (await fetch(
          `${SUPABASE_URL}/rest/v1/coupons?code=ilike.${encodeURIComponent(couponCode)}&select=email_lock,pct_off_list,waive_plan_fee,plan_months,balance_cents,scope_activity_ids,scope_shows&limit=1`,
          { headers: { apikey: svcKey, Authorization: `Bearer ${svcKey}` } }
        )).json();
        special = specialFromCouponRow(rows?.[0]);
      } catch (e) {
        console.error("special row lookup", e.message);
      }
    }
    if (!c || !special && !c.pct && !c.amount_cents) {
      return Response.json({ error: "bad_coupon" }, { status: 400 });
    }
    couponPct = c.pct || 0;
    couponFixedCents = c.amount_cents || 0;
    if (special && special.email) {
      const locks = (Array.isArray(special.email) ? special.email : [special.email]).map((e) => e.toLowerCase());
      if (!locks.includes(email)) {
        return Response.json({ error: "bad_coupon" }, { status: 400 });
      }
    }
  }
  const items = hold.items;
  const summerItems = items.filter((it) => it.show);
  const activityItems = items.filter((it) => it.activity_id);
  const priorCampsByKid = {}, priorShowsByKid = {};
  const bdayByKid = {}, creditsByKid = {};
  const SUMMER_SLUGS = /* @__PURE__ */ new Set(["httyd", "charlie", "trolls"]);
  try {
    const svcKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const famId = await familyIdByEmail(email, { apikey: svcKey, Authorization: `Bearer ${svcKey}` });
    if (famId) {
      const cr = await fetch(`${SUPABASE_URL}/rest/v1/campers?family_id=eq.${famId}&select=name,already_registered,birthdate,day_camp_credits,snow_day_credits`, {
        headers: { apikey: svcKey, Authorization: `Bearer ${svcKey}` }
      });
      const camps = await cr.json();
      const byName = {};
      for (const c of Array.isArray(camps) ? camps : []) {
        const reg = c.already_registered || [];
        byName[String(c.name || "").trim().toLowerCase()] = {
          camps: reg.filter((s) => SUMMER_SLUGS.has(s)).length,
          shows: reg.filter((s) => !SUMMER_SLUGS.has(s)).length,
          bday: c.birthdate || null,
          dayCr: c.day_camp_credits || 0,
          snowCr: c.snow_day_credits || 0
        };
      }
      for (const it of items) {
        const p = byName[String(it.camper || "").trim().toLowerCase()];
        if (!p) continue;
        if (p.camps) priorCampsByKid[kidKey(it)] = p.camps;
        if (p.shows) priorShowsByKid[kidKey(it)] = p.shows;
        if (p.bday) bdayByKid[kidKey(it)] = p.bday;
        if (p.dayCr || p.snowCr) creditsByKid[kidKey(it)] = { day: p.dayCr, snow: p.snowCr };
      }
    }
  } catch (e) {
    console.error("prior lookup failed:", e.message);
  }
  let byId = {};
  if (activityItems.length) {
    const ids = [...new Set(activityItems.map((it) => it.activity_id))];
    let acts = await anonRpc("activity_facts", { p_ids: ids });
    if (!Array.isArray(acts)) {
      console.warn("activity_facts unavailable \u2014 falling back to activity_prices");
      acts = await anonRpc("activity_prices", { p_ids: ids });
    }
    if (!Array.isArray(acts) || acts.length !== ids.length) {
      return Response.json({ error: "unknown_activity" }, { status: 400 });
    }
    const closed = acts.filter((a) => a.sells_now === false);
    if (closed.length) {
      return Response.json(
        { error: "registration_closed", activities: closed.map((a) => a.name) },
        { status: 400 }
      );
    }
    byId = Object.fromEntries(acts.map((a) => [a.id, a]));
  }
  const classItems = activityItems.filter((it) => byId[it.activity_id].category === "class");
  const showItems = activityItems.filter((it) => byId[it.activity_id].category !== "class");
  if (classItems.length && (summerItems.length || showItems.length)) {
    return Response.json({ error: "mixed_cart" }, { status: 400 });
  }
  let pricing;
  let description;
  if (classItems.length) {
    if (plan !== "subscription") return Response.json({ error: "bad_plan" }, { status: 400 });
    const kk = (it) => it && it.ci != null ? "i" + it.ci : it && it.camper || "";
    const byKidClasses = {};
    classItems.forEach((it, idx) => {
      (byKidClasses[kk(it)] = byKidClasses[kk(it)] || []).push(idx);
    });
    const unitPrices = new Array(classItems.length).fill(0);
    for (const k of Object.keys(byKidClasses)) {
      const idxs = byKidClasses[k];
      const bundle = classMonthlyCents(idxs.length);
      const per = Math.floor(bundle / idxs.length);
      idxs.forEach((idx, j) => {
        unitPrices[idx] = j === idxs.length - 1 ? bundle - per * (idxs.length - 1) : per;
      });
    }
    const subtotal = unitPrices.reduce((s, v) => s + v, 0);
    const couponCents = couponPct ? Math.round(subtotal * couponPct / 100) : Math.min(couponFixedCents, subtotal);
    let firstMonthFree = false;
    try {
      const svcKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      const hdrs = { apikey: svcKey, Authorization: `Bearer ${svcKey}` };
      const famId = await familyIdByEmail(email, hdrs);
      if (famId) {
        const kids = await (await fetch(`${SUPABASE_URL}/rest/v1/campers?family_id=eq.${famId}&select=already_registered`, { headers: hdrs })).json();
        firstMonthFree = kids.some((c) => Array.isArray(c.already_registered) && c.already_registered.length);
      }
      if (!firstMonthFree) {
        const ords = await (await fetch(`${SUPABASE_URL}/rest/v1/orders?email=ilike.${encodeURIComponent(email)}&status=in.(paid,confirmed,complete,succeeded)&select=id`, { headers: hdrs })).json();
        if (ords.length) {
          const ids = ords.map((o) => o.id).join(",");
          const its = await (await fetch(`${SUPABASE_URL}/rest/v1/order_items?order_id=in.(${ids})&select=activity_id`, { headers: hdrs })).json();
          const actIds = [...new Set(its.map((i) => i.activity_id).filter(Boolean))];
          if (its.some((i) => !i.activity_id)) firstMonthFree = true;
          else if (actIds.length) {
            const acts = await (await fetch(`${SUPABASE_URL}/rest/v1/activities?id=in.(${actIds.join(",")})&select=id,category`, { headers: hdrs })).json();
            firstMonthFree = acts.some((a) => a.category !== "class");
          }
        }
      }
    } catch (e) {
      console.error("first-month-free check failed:", e.message);
    }
    pricing = {
      todayCents: firstMonthFree ? 0 : subtotal - couponCents,
      totalCents: firstMonthFree ? 0 : subtotal - couponCents,
      subtotalCents: subtotal,
      couponCents,
      insuranceCents: 0,
      // built into the monthly price for classes
      installmentCents: 0,
      nInstallments: 0,
      firstInstallmentUTC: 0,
      unitPrices,
      monthlyItems: unitPrices,
      discountPct: 0,
      firstMonthFree
    };
    description = classItems.map((it) => `${it.camper || "Camper"} \u2014 ${byId[it.activity_id].name}`).join("; ");
  } else {
    if (plan === "subscription") return Response.json({ error: "bad_plan" }, { status: 400 });
    const cart = [
      ...summerItems,
      ...showItems.map((it) => ({
        ...it,
        name: byId[it.activity_id].name,
        price_cents: byId[it.activity_id].price_cents,
        // The listing's own start date, and only then the hardcoded name list.
        // A show created in the staff portal is not on that list and never
        // will be; without starts_on it got null here, installmentDates
        // returned no dates, and the family was silently refused a payment
        // plan and charged $995 in full.
        start: byId[it.activity_id].starts_on || showStartFor(byId[it.activity_id].name),
        // Lets priceCart stop inferring a day camp from its price.
        offering_kind: byId[it.activity_id].offering_kind || null
      }))
    ];
    const p = priceCart(cart, plan, { insurance, couponPct, couponFixedCents, priorCampsByKid, priorShowsByKid, special, creditsByKid });
    if (plan === "deposit" && p.payFullOnly) {
      return Response.json({ error: "pay_full_only" }, { status: 400 });
    }
    pricing = {
      todayCents: p.todayCents,
      totalCents: p.totalCents,
      subtotalCents: p.subtotal,
      couponCents: p.couponCents || 0,
      planFeeCents: p.planFeeCents || 0,
      insuranceCents: p.insuranceCents,
      installmentCents: p.installmentCents,
      nInstallments: p.installmentDatesUTC.length,
      firstInstallmentUTC: p.installmentDatesUTC[0] || 0,
      unitPrices: p.items.map((it) => it.unit),
      monthlyItems: [],
      discountPct: Math.round(Math.max(...p.items.map((it) => it.rate), 0) * 100),
      creditsUsed: p.creditsUsed || {},
      dayPacksByKid: p.dayPacksByKid || {}
    };
    description = cart.map((it) => it.show ? `${it.camper || "Camper"} \u2014 ${SHOWS[it.show] || it.show} (${it.band})` : `${it.camper || "Camper"} \u2014 ${it.name}`).join("; ");
  }
  if (pricing.todayCents === 0 && pricing.totalCents === 0 && plan !== "subscription") {
    if (!body.confirm_free) {
      return Response.json({
        free: true,
        pricing: {
          n: items.length,
          discount_pct: pricing.discountPct,
          unit_prices: pricing.unitPrices,
          subtotal_cents: pricing.subtotalCents,
          coupon_cents: pricing.couponCents || 0,
          coupon: couponPct || couponFixedCents ? couponCode.toUpperCase() : null,
          plan_fee_cents: 0,
          insurance_cents: pricing.insuranceCents,
          total_cents: 0,
          today_cents: 0,
          installment_cents: 0,
          n_installments: 0,
          first_installment_utc: 0,
          monthly_items: []
        }
      });
    }
    const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    const svc = async (fn, args) => {
      const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
        method: "POST",
        headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", Prefer: "return=representation" },
        body: JSON.stringify(args)
      });
      const t = await r.text();
      if (!r.ok) throw new Error(`rpc ${fn} failed ${r.status}: ${t.slice(0, 200)}`);
      try {
        return JSON.parse(t);
      } catch {
        return t;
      }
    };
    await svc("confirm_order", {
      p_hold_id: hold_id,
      p_email: email,
      p_parent_name: parent_name || null,
      p_plan: "full",
      p_amount_today_cents: 0,
      p_total_cents: 0,
      p_installment_cents: null,
      p_stripe_payment_intent: "free_" + hold_id,
      p_stripe_customer: null,
      p_unit_prices: pricing.unitPrices
    });
    try {
      const held = await svc("hold_items_admin", { p_hold_id: hold_id });
      if (Array.isArray(held) && held.length) await svc("mark_registered", { p_email: email, p_items: held });
    } catch (e) {
      console.error("free order: mark_registered failed:", e.message);
    }
    if (couponCode) {
      try {
        await svc("redeem_coupon", { p_code: couponCode, p_applied_cents: pricing.couponCents || 0 });
      } catch (e) {
        console.error("free order: redeem_coupon failed:", e.message);
      }
    }
    try {
      const grants = [
        ...items.filter((it) => it.activity_id === DAY_CAMP_PACK_ID).map((it) => ({
          camper: it.camper || "",
          day: DAY_CAMP_PACK_CREDITS,
          snow: /* @__PURE__ */ new Date() <= DAY_CAMP_PACK_SNOW_END ? DAY_CAMP_PACK_SNOW_BONUS : 0
        })),
        .../* @__PURE__ */ new Date() <= DAY_CAMP_PACK_SNOW_END ? Object.entries(pricing.dayPacksByKid || {}).map(([k, n]) => ({ camper: k, day: 0, snow: DAY_CAMP_PACK_SNOW_BONUS * n })) : []
      ];
      const redemptions = Object.entries(pricing.creditsUsed || {}).map(([k, u]) => ({ camper: k, day: u.day || 0, snow: u.snow || 0 }));
      if (grants.length || redemptions.length) {
        await svc("apply_credit_events", { p_pi: "free_" + hold_id, p_email: email, p_detail: { grants, redemptions } });
      }
    } catch (e) {
      console.error("free order: credit events failed:", e.message);
    }
    if (parent_name && email) {
      try {
        const famId = await familyIdByEmail(email, { apikey: key, Authorization: `Bearer ${key}` });
        if (famId) await fetch(`${SUPABASE_URL}/rest/v1/families?id=eq.${famId}`, {
          method: "PATCH",
          headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({ parent_name })
        });
      } catch {
      }
    }
    try {
      await sendConfirmationEmail({
        email,
        parent_name: parent_name || "",
        order_desc: description.slice(0, 480),
        total_cents: "0",
        coupon: couponCode.toUpperCase(),
        coupon_cents: String(pricing.couponCents || 0),
        fsa_eligible: "0"
      }, { amount_received: 0, amount: 0 });
    } catch (e) {
      console.error("free order: email failed:", e.message);
    }
    return Response.json({ confirmed: true });
  }
  if (plan === "subscription" && pricing.firstMonthFree && pricing.todayCents === 0) {
    const stripeS = new Stripe(process.env.STRIPE_SECRET_KEY);
    const customerS = await stripeS.customers.create({
      email,
      name: parent_name || void 0,
      metadata: { source: "novapa-register" }
    });
    const si = await stripeS.setupIntents.create({
      customer: customerS.id,
      payment_method_types: ["card", "link"],
      metadata: {
        hold_id,
        plan,
        email,
        guest: guest ? "1" : "0",
        kid_bdays: guest ? JSON.stringify(kidBdays).slice(0, 450) : "",
        parent_name: (parent_name || "").slice(0, 100),
        total_cents: "0",
        installment_cents: "0",
        n_installments: "0",
        first_installment_utc: "0",
        insurance_cents: "0",
        insured: "0",
        coupon: "",
        coupon_cents: "0",
        plan_fee_cents: "0",
        fsa_eligible: "0",
        first_month_free: "1",
        unit_prices: JSON.stringify(pricing.unitPrices).slice(0, 450),
        monthly_items: JSON.stringify(pricing.monthlyItems).slice(0, 450),
        n_items: String(items.length),
        order_desc: description.slice(0, 480)
      }
    });
    return Response.json({
      client_secret: si.client_secret,
      setup: true,
      pricing: {
        n: items.length,
        discount_pct: 0,
        unit_prices: pricing.unitPrices,
        subtotal_cents: pricing.subtotalCents,
        coupon_cents: 0,
        coupon: null,
        plan_fee_cents: 0,
        insurance_cents: 0,
        total_cents: 0,
        today_cents: 0,
        installment_cents: 0,
        n_installments: 0,
        first_installment_utc: 0,
        monthly_cents: pricing.monthlyItems.reduce((s, v) => s + v, 0),
        first_month_free: true
      }
    });
  }
  if (pricing.todayCents < 50) {
    return Response.json({ error: "coupon_too_small" }, { status: 400 });
  }
  const refCodeRaw = String((body || {}).ref || "").trim().toUpperCase().slice(0, 20);
  let refMeta = {};
  if (refCodeRaw && /^[A-Z0-9]+$/.test(refCodeRaw)) {
    try {
      const svcKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
      const hdrs = { apikey: svcKey, Authorization: `Bearer ${svcKey}` };
      const fr = await fetch(`${SUPABASE_URL}/rest/v1/families?ref_code=eq.${encodeURIComponent(refCodeRaw)}&select=email`, { headers: hdrs });
      const rows = await fr.json();
      const referrer = (rows && rows[0] && rows[0].email || "").toLowerCase();
      if (referrer && referrer !== email) {
        const or = await fetch(`${SUPABASE_URL}/rest/v1/orders?email=ilike.${encodeURIComponent(email)}&status=in.(paid,confirmed,complete,succeeded)&select=id&limit=1`, { headers: hdrs });
        const prior = await or.json();
        if (Array.isArray(prior) && prior.length === 0) {
          refMeta = { ref_code: refCodeRaw, ref_referrer: referrer };
        }
      }
    } catch (e) {
      console.error("referral check failed:", e.message);
    }
  }
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const customer = await stripe.customers.create({
    email,
    name: parent_name || void 0,
    metadata: { source: "novapa-register" }
  });
  const pi = await stripe.paymentIntents.create({
    amount: pricing.todayCents,
    currency: "usd",
    customer: customer.id,
    setup_future_usage: plan === "deposit" || plan === "subscription" ? "off_session" : void 0,
    // Cards + Link only. Apple Pay / Google Pay ride the card rails via the
    // Express Checkout element. Redirect methods (Amazon Pay, Klarna, ...)
    // are excluded deliberately: they hijack mobile checkout and cannot be
    // charged off-session for installment schedules / class subscriptions.
    payment_method_types: ["card", "link"],
    description: `NOVAPA \u2014 ${plan === "deposit" ? "reservation deposit" : plan === "subscription" ? "class enrollment (first month)" : "paid in full"}`,
    statement_descriptor_suffix: "NOVAPA",
    metadata: {
      hold_id,
      plan,
      email,
      guest: guest ? "1" : "0",
      kid_bdays: guest ? JSON.stringify(kidBdays).slice(0, 450) : "",
      parent_name: (parent_name || "").slice(0, 100),
      total_cents: String(pricing.totalCents),
      installment_cents: String(pricing.installmentCents),
      n_installments: String(pricing.nInstallments),
      first_installment_utc: String(pricing.firstInstallmentUTC),
      insurance_cents: String(pricing.insuranceCents),
      insured: insurance ? "1" : "0",
      coupon: couponPct || couponFixedCents ? couponCode.toUpperCase() : "",
      coupon_cents: String(pricing.couponCents || 0),
      plan_fee_cents: String(pricing.planFeeCents || 0),
      // IRS Pub. 503: FSA language only for daytime day camps (summer camps +
      // one-day specialty camps, never classes or show fees) AND only when the
      // camper is under 13 when care starts. No birthday on file = not
      // eligible (checkout collects birthdays; fail closed on a tax flag).
      fsa_eligible: summerItems.some((it) => fsaUnder13(bdayByKid[kidKey(it)], CAMP_STARTS[it.show])) || showItems.some((it) => {
        const a = byId[it.activity_id];
        const isDayCamp = a.offering_kind ? a.offering_kind === "day_camp" : (a.price_cents || 0) <= DAY_CAMP_MAX_CENTS && !isCoachingId(it.activity_id);
        return isDayCamp && fsaUnder13(bdayByKid[kidKey(it)], a.starts_on || null);
      }) ? "1" : "0",
      unit_prices: JSON.stringify(pricing.unitPrices).slice(0, 450),
      monthly_items: JSON.stringify(pricing.monthlyItems).slice(0, 450),
      n_items: String(items.length),
      order_desc: description.slice(0, 480),
      // pack purchases grant per-camper credits; redeemed credits deduct —
      // both applied by the webhook via apply_credit_events (exactly-once)
      credit_grants: JSON.stringify([
        ...items.filter((it) => it.activity_id === DAY_CAMP_PACK_ID).map((it) => ({
          camper: it.camper || "",
          day: DAY_CAMP_PACK_CREDITS,
          snow: /* @__PURE__ */ new Date() <= DAY_CAMP_PACK_SNOW_END ? DAY_CAMP_PACK_SNOW_BONUS : 0
        })),
        // cart-form packs: the camper books all 5 days now, so no day credits —
        // just the Labor Day snow-day bonus
        .../* @__PURE__ */ new Date() <= DAY_CAMP_PACK_SNOW_END ? Object.entries(pricing.dayPacksByKid || {}).map(([k, n]) => ({ camper: k, day: 0, snow: DAY_CAMP_PACK_SNOW_BONUS * n })) : []
      ]).slice(0, 450),
      credit_redeems: JSON.stringify(Object.entries(pricing.creditsUsed || {}).map(([k, u]) => ({ camper: k, day: u.day || 0, snow: u.snow || 0 }))).slice(0, 450),
      ...refMeta
    }
  });
  return Response.json({
    client_secret: pi.client_secret,
    pricing: {
      n: items.length,
      discount_pct: pricing.discountPct,
      unit_prices: pricing.unitPrices,
      subtotal_cents: pricing.subtotalCents,
      coupon_cents: pricing.couponCents || 0,
      coupon: couponPct || couponFixedCents ? couponCode.toUpperCase() : null,
      plan_fee_cents: pricing.planFeeCents || 0,
      insurance_cents: pricing.insuranceCents,
      total_cents: pricing.totalCents,
      today_cents: pricing.todayCents,
      installment_cents: pricing.installmentCents,
      n_installments: pricing.nInstallments,
      first_installment_utc: pricing.firstInstallmentUTC,
      monthly_items: pricing.monthlyItems
    }
  });
};
var config = { path: "/api/reg-pay" };
export {
  config,
  reg_pay_default as default
};
