
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/reg-apply.mjs
var MAX_RESUME_BYTES = 3 * 1024 * 1024;
var ALLOWED = {
  "application/pdf": "pdf",
  "application/msword": "doc",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
  "text/plain": "txt"
};
var POSITIONS = [
  "Teaching Artist \u2014 Theatre / Acting",
  "Teaching Artist \u2014 Dance",
  "Teaching Artist \u2014 Voice / Music",
  "Teaching Artist \u2014 Musical Theatre",
  "Music Director / Accompanist",
  "Choreographer",
  "Director / Assistant Director",
  "Summer Camp Staff / Counselor",
  "Production & Technical Theatre",
  "Stage Management",
  "Front Desk / Administrative",
  "Marketing / Social Media",
  "Substitute / On-Call",
  "Volunteer",
  "Intern",
  "Other"
];
var AVAILABILITY = [
  "Weekday daytime",
  "Weekday after-school (3\u20136pm)",
  "Weekday evenings (6\u20139pm)",
  "Saturdays",
  "Summer camps (weekdays, full-day)",
  "Seasonal productions / tech weeks"
];
function svcHeaders(extra = {}) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return { apikey: key, Authorization: `Bearer ${key}`, ...extra };
}
function clean(s, max) {
  return String(s == null ? "" : s).replace(/\s+/g, " ").trim().slice(0, max);
}
function esc(s) {
  return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
var reg_apply_default = async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "bad_request" }, { status: 400 });
  }
  if (clean(body.website, 40)) return Response.json({ ok: true });
  const full_name = clean(body.full_name, 120);
  const email = clean(body.email, 160).toLowerCase();
  const phone = clean(body.phone, 40);
  if (!full_name) return Response.json({ error: "name_required" }, { status: 400 });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return Response.json({ error: "email_invalid" }, { status: 400 });
  const positions = (Array.isArray(body.positions) ? body.positions : []).filter((p) => POSITIONS.includes(p));
  const availability = (Array.isArray(body.availability) ? body.availability : []).filter((a) => AVAILABILITY.includes(a));
  if (!positions.length) return Response.json({ error: "position_required" }, { status: 400 });
  const earliest_start = clean(body.earliest_start, 60);
  const experience = clean(body.experience, 60);
  const message = clean(body.message, 4e3);
  let resume_path = null, resume_name = null, resume_bytes = null;
  if (body.resume && body.resume.data) {
    const mime = clean(body.resume.type, 120);
    const ext = ALLOWED[mime];
    if (!ext) return Response.json({ error: "resume_type" }, { status: 400 });
    let bytes;
    try {
      bytes = Buffer.from(String(body.resume.data), "base64");
    } catch {
      return Response.json({ error: "resume_unreadable" }, { status: 400 });
    }
    if (!bytes.length) return Response.json({ error: "resume_unreadable" }, { status: 400 });
    if (bytes.length > MAX_RESUME_BYTES) return Response.json({ error: "resume_too_big" }, { status: 400 });
    const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[^0-9]/g, "").slice(0, 14);
    const slug = full_name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 40) || "applicant";
    const rand = Math.random().toString(36).slice(2, 10);
    resume_path = `${stamp}-${slug}-${rand}.${ext}`;
    resume_name = clean(body.resume.name, 160) || `resume.${ext}`;
    resume_bytes = bytes.length;
    const up = await fetch(`${SUPABASE_URL}/storage/v1/object/resumes/${encodeURIComponent(resume_path)}`, {
      method: "POST",
      headers: svcHeaders({ "Content-Type": mime, "x-upsert": "false" }),
      body: bytes
    });
    if (!up.ok) {
      console.error("resume upload failed:", up.status, (await up.text()).slice(0, 200));
      return Response.json({ error: "resume_upload_failed" }, { status: 502 });
    }
  }
  const ins = await fetch(`${SUPABASE_URL}/rest/v1/job_applications`, {
    method: "POST",
    headers: svcHeaders({ "Content-Type": "application/json", Prefer: "return=representation" }),
    body: JSON.stringify({
      full_name,
      email,
      phone: phone || null,
      positions,
      availability,
      earliest_start: earliest_start || null,
      experience: experience || null,
      message: message || null,
      resume_path,
      resume_name,
      resume_bytes
    })
  });
  if (!ins.ok) {
    console.error("application insert failed:", ins.status, (await ins.text()).slice(0, 200));
    return Response.json({ error: "save_failed" }, { status: 502 });
  }
  try {
    if (process.env.SMTP_USER && process.env.SMTP_PASS) {
      const admins = await fetch(`${SUPABASE_URL}/rest/v1/admin_emails?select=email`, { headers: svcHeaders() }).then((r) => r.ok ? r.json() : []).then((rows) => rows.map((r) => r.email).filter(Boolean));
      if (admins.length) {
        const { default: nodemailer } = await import("nodemailer");
        const t = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 465,
          secure: true,
          auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        });
        await t.sendMail({
          from: `NOVAPA Careers <${process.env.SMTP_USER}>`,
          to: admins.join(", "),
          replyTo: email,
          subject: `Employment interest: ${full_name}`,
          html: [
            `<b>${esc(full_name)}</b> &lt;${esc(email)}&gt;${phone ? " \xB7 " + esc(phone) : ""}`,
            `<b>Interested in:</b><br>${positions.map(esc).join("<br>")}`,
            availability.length ? `<b>Availability:</b><br>${availability.map(esc).join("<br>")}` : "",
            earliest_start ? `<b>Can start:</b> ${esc(earliest_start)}` : "",
            experience ? `<b>Experience:</b> ${esc(experience)}` : "",
            message ? `<b>Message:</b><br>${esc(message).replace(/\n/g, "<br>")}` : "",
            resume_path ? `R\xE9sum\xE9 attached to their record (${esc(resume_name)}).` : "No r\xE9sum\xE9 uploaded.",
            `<a href="https://www.northernvirginiaperformingarts.org/register/admin/">Open admin dashboard</a>`
          ].filter(Boolean).join("<br><br>")
        });
      }
    }
  } catch (e) {
    console.error("applicant notify failed:", e.message);
  }
  return Response.json({ ok: true });
};
var config = { path: "/api/apply" };
export {
  config,
  reg_apply_default as default
};
