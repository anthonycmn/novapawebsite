
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/reg-leads.mjs
var STAGES = [
  { id: "new", label: "New" },
  { id: "contacted", label: "Contacted" },
  { id: "nurturing", label: "Interested" },
  { id: "registered", label: "Registered" },
  { id: "closed_lost", label: "Closed lost" }
];
var STAGE_IDS = new Set(STAGES.map((s) => s.id));
async function isAdmin(userToken) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/is_admin`, {
    method: "POST",
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${userToken}`, "Content-Type": "application/json" },
    body: "{}"
  });
  if (!r.ok) return false;
  return (await r.text()).trim() === "true";
}
function svc(extra = {}) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return { apikey: key, Authorization: `Bearer ${key}`, ...extra };
}
async function db(path) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { headers: svc() });
  const t = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${t.slice(0, 200)}`);
  try {
    return JSON.parse(t);
  } catch {
    return null;
  }
}
async function dbPost(path, body, prefer) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method: "POST",
    headers: svc({ "Content-Type": "application/json", ...prefer ? { Prefer: prefer } : {} }),
    body: JSON.stringify(body)
  });
  const t = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${t.slice(0, 200)}`);
  try {
    return JSON.parse(t);
  } catch {
    return null;
  }
}
function emailFromToken(token) {
  try {
    const seg = String(token).split(".")[1];
    const pad = seg.replace(/-/g, "+").replace(/_/g, "/");
    return JSON.parse(atob(pad + "=".repeat((4 - pad.length % 4) % 4))).email || null;
  } catch {
    return null;
  }
}
function parseJson(v, fallback) {
  if (v == null) return fallback;
  if (typeof v === "object") return v;
  try {
    return JSON.parse(v);
  } catch {
    return fallback;
  }
}
async function loadDcu() {
  const base = process.env.DCU_SUPABASE_URL;
  const key = process.env.DCU_SERVICE_KEY;
  if (!base || !key) return { rows: [], status: "not_configured" };
  try {
    const r = await fetch(
      `${base}/rest/v1/funnel_leads_ro?select=*&order=updated_at.desc.nullslast&limit=500`,
      { headers: { apikey: key, Authorization: `Bearer ${key}`, "Accept-Profile": "leads_api" } }
    );
    const t = await r.text();
    if (!r.ok) return { rows: [], status: `error ${r.status}: ${t.slice(0, 120)}` };
    const raw = JSON.parse(t);
    const rows = raw.map((x) => {
      const a = parseJson(x.answers, {});
      const m = parseJson(x.matches, []);
      return {
        id: x.id,
        key: `dcu:${x.id}`,
        board: "dcu",
        created_at: x.created_at,
        updated_at: x.updated_at,
        name: x.name,
        email: x.email,
        phone: x.phone,
        role: x.role,
        grad_year: x.grad_year,
        // DCU rows predating their stage column come back null; the board has
        // no null column to drop them in, so they land in New.
        stage: x.stage || "new",
        coach_notes: x.coach_notes,
        purchased_at: x.purchased_at,
        campaign: x.utm_campaign,
        content: x.utm_content,
        source: x.utm_source,
        dream: a.dream,
        structure: a.structure,
        distance: a.distance,
        home_state: a.homeState,
        dance: a.dance,
        gpa: a.gpa,
        budget: a.budget,
        prescreen: a.prescreen,
        certainty: a.certainty,
        // Prescreens already filmed + decision locked is the DC Unifieds
        // buyer. Surfacing it as a flag so the list can sort itself.
        hot: a.certainty === "locked" && a.prescreen === "filmed",
        matches: Array.isArray(m) ? m.map((s) => s.school).filter(Boolean) : []
      };
    });
    return { rows, status: "ok" };
  } catch (e) {
    return { rows: [], status: `error: ${String(e.message).slice(0, 120)}` };
  }
}
async function dcuSetStage(id, stage, by) {
  const base = process.env.DCU_SUPABASE_URL;
  const key = process.env.DCU_SERVICE_KEY;
  if (!base || !key) return { ok: false, error: "dcu_not_configured" };
  const r = await fetch(`${base}/rest/v1/rpc/set_lead_stage`, {
    method: "POST",
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      // RPC is a write, so PostgREST wants Content-Profile here — Accept-Profile
      // (what the read path uses) is ignored on POST and the call 404s.
      "Content-Profile": "leads_api"
    },
    body: JSON.stringify({ p_id: String(id), p_stage: stage, p_by: by || "novapa-admin" })
  });
  const t = await r.text();
  if (!r.ok) return { ok: false, error: `dcu ${r.status}: ${t.slice(0, 160)}` };
  return { ok: true };
}
async function loadStageMap() {
  try {
    const rows = await db("lead_stages?select=board,lead_id,stage&limit=5000");
    const m = /* @__PURE__ */ new Map();
    for (const r of rows || []) m.set(`${r.board}:${r.lead_id}`, r.stage);
    return m;
  } catch {
    return /* @__PURE__ */ new Map();
  }
}
async function loadPaidEmails(emails) {
  const variants = /* @__PURE__ */ new Set();
  for (const e of emails) {
    if (!e) continue;
    const v = String(e).trim();
    if (v) {
      variants.add(v);
      variants.add(v.toLowerCase());
    }
  }
  const list = [...variants];
  const paid = /* @__PURE__ */ new Set();
  for (let i = 0; i < list.length; i += 100) {
    const chunk = list.slice(i, i + 100).map(encodeURIComponent).join(",");
    try {
      const rows = await db(`orders?select=email&email=in.(${chunk})&status=eq.paid`);
      for (const o of rows || []) if (o.email) paid.add(String(o.email).trim().toLowerCase());
    } catch {
    }
  }
  return paid;
}
function applyPaid(lead, isPaid) {
  if (!isPaid) return { ...lead, stage_locked: false };
  return { ...lead, stage: "registered", stage_locked: true };
}
var reg_leads_default = async (req) => {
  if (req.method !== "POST") return new Response("method", { status: 405 });
  const auth = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!auth || !await isAdmin(auth)) return Response.json({ error: "not admin" }, { status: 403 });
  let body = {};
  try {
    body = await req.json();
  } catch {
  }
  const action = body.action || "list";
  if (action === "set_stage") {
    const key = String(body.key || "");
    const stage = String(body.stage || "");
    if (!STAGE_IDS.has(stage)) return Response.json({ error: "bad_stage" }, { status: 400 });
    const cut = key.indexOf(":");
    const prefix = cut < 0 ? "" : key.slice(0, cut);
    const id = cut < 0 ? "" : key.slice(cut + 1);
    if (!id) return Response.json({ error: "bad_key" }, { status: 400 });
    const by = emailFromToken(auth) || body.by || null;
    if (prefix === "dcu") {
      const r = await dcuSetStage(id, stage, by);
      if (!r.ok) return Response.json({ error: r.error }, { status: 502 });
      return Response.json({ ok: true, stage });
    }
    if (prefix === "quiz" || prefix === "free") {
      try {
        await dbPost(
          "lead_stages",
          { board: prefix, lead_id: id, stage, updated_at: (/* @__PURE__ */ new Date()).toISOString(), updated_by: by },
          "resolution=merge-duplicates"
        );
      } catch (e) {
        return Response.json({ error: String(e.message).slice(0, 200) }, { status: 502 });
      }
      return Response.json({ ok: true, stage });
    }
    return Response.json({ error: "bad_key" }, { status: 400 });
  }
  if (action !== "list") {
    return Response.json({ error: "unknown_action" }, { status: 400 });
  }
  const [dcu, quiz, freeclass, stageMap] = await Promise.all([
    loadDcu(),
    db("quiz_leads?select=*&order=created_at.desc&limit=500").catch(() => []),
    db("free_class_bookings?select=*&order=created_at.desc&limit=500").catch(() => []),
    loadStageMap()
  ]);
  const quizRows = (quiz || []).map((q) => ({
    id: q.id,
    key: `quiz:${q.id}`,
    board: "novapa",
    stage: stageMap.get(`quiz:${q.id}`) || "new",
    created_at: q.created_at,
    parent_name: q.parent_name,
    email: q.email,
    child_name: q.child_name,
    age_band: q.age_band,
    persona: q.persona,
    source: q.source
  }));
  const freeRows = (freeclass || []).map((f) => ({
    id: f.id,
    key: `free:${f.id}`,
    board: "novapa",
    stage: stageMap.get(`free:${f.id}`) || "new",
    created_at: f.created_at,
    parent_name: f.parent_name,
    email: f.email,
    phone: f.phone,
    child_name: f.child_name,
    child_age: f.child_age,
    cast_key: f.cast_key,
    class_date: f.class_date,
    status: f.status
  }));
  const paid = await loadPaidEmails([...quizRows, ...freeRows].map((l) => l.email));
  const isPaid = (e) => !!e && paid.has(String(e).trim().toLowerCase());
  return Response.json({
    stages: STAGES,
    dcu: dcu.rows.map((d) => applyPaid(d, !!d.purchased_at)),
    dcu_status: dcu.status,
    quiz: quizRows.map((q) => applyPaid(q, isPaid(q.email))),
    freeclass: freeRows.map((f) => applyPaid(f, isPaid(f.email)))
  });
};
var config = { path: "/api/reg-leads" };
export {
  config,
  reg_leads_default as default
};
