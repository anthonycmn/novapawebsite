
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/resend-webhook.mjs
import crypto from "node:crypto";

// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/resend-webhook.mjs
function verify(req, payload) {
  const secret = process.env.RESEND_WEBHOOK_SECRET || "";
  const id = req.headers.get("svix-id"), ts = req.headers.get("svix-timestamp");
  const sigs = (req.headers.get("svix-signature") || "").split(" ");
  if (!secret || !id || !ts) return false;
  if (Math.abs(Date.now() / 1e3 - Number(ts)) > 300) return false;
  const key = Buffer.from(secret.replace(/^whsec_/, ""), "base64");
  const expected = crypto.createHmac("sha256", key).update(`${id}.${ts}.${payload}`).digest("base64");
  return sigs.some((s) => {
    const v = s.split(",")[1] || "";
    return v.length === expected.length && crypto.timingSafeEqual(Buffer.from(v), Buffer.from(expected));
  });
}
var resend_webhook_default = async (req) => {
  if (req.method !== "POST") return new Response("method", { status: 405 });
  const payload = await req.text();
  if (!verify(req, payload)) return new Response("bad signature", { status: 401 });
  let ev;
  try {
    ev = JSON.parse(payload);
  } catch {
    return new Response("bad json", { status: 400 });
  }
  if (!["email.bounced", "email.complained"].includes(ev.type)) {
    return new Response("ignored", { status: 200 });
  }
  const reason = ev.type === "email.bounced" ? "hard bounce (resend)" : "spam complaint (resend)";
  const to = [].concat(ev.data?.to || []);
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  for (const addr of to) {
    const email = String(addr).toLowerCase().trim();
    if (!email.includes("@")) continue;
    await fetch(`${SUPABASE_URL}/rest/v1/email_suppressions?on_conflict=email,scope`, {
      method: "POST",
      headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json", Prefer: "resolution=ignore-duplicates" },
      body: JSON.stringify({ email, scope: "marketing", reason })
    });
  }
  return new Response("ok", { status: 200 });
};
var config = { path: "/api/resend-webhook" };
export {
  config,
  resend_webhook_default as default
};
