
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// netlify/functions/tix-confirm.mjs
var tix_confirm_exports = {};
__export(tix_confirm_exports, {
  confirmTickets: () => confirmTickets
});
async function svcRpc(fn, args) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const r = await fetch(`${SUPABASE_URL2}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify(args)
  });
  const t = await r.text();
  if (!r.ok) throw new Error(`${fn} ${r.status}: ${t.slice(0, 250)}`);
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}
async function confirmTickets(pi) {
  const m = pi.metadata || {};
  const res = await svcRpc("tix_confirm", {
    p_hold_id: m.tix_hold_id,
    p_email: m.email || "",
    p_buyer_name: m.buyer_name || null,
    p_total_cents: parseInt(m.total_cents || "0", 10),
    p_stripe_payment_intent: pi.id
  });
  if (!res.duplicate) {
    if (m.reward_id && m.reward_side && m.reward_email) {
      try {
        const col = m.reward_side === "referrer" ? "referrer_redeemed_at" : "referred_redeemed_at";
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
        await fetch(`${SUPABASE_URL2}/rest/v1/referral_rewards?id=eq.${m.reward_id}&${col}=is.null`, {
          method: "PATCH",
          headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({ [col]: (/* @__PURE__ */ new Date()).toISOString() })
        });
      } catch (e) {
        console.error("reward settle failed:", e.message);
      }
    }
    if (m.coupon && parseInt(m.coupon_cents || "0", 10) > 0) {
      try {
        await svcRpc("redeem_coupon", {
          p_code: m.coupon,
          p_applied_cents: parseInt(m.coupon_cents, 10)
        });
      } catch (e) {
        console.error("ticket coupon settle failed:", e.message);
      }
    }
    try {
      await sendTicketEmail(m, res.code);
    } catch (e) {
      console.error("ticket email failed:", e.message);
    }
  }
  return res;
}
async function sendTicketEmail(m, code) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS || !m.email) return;
  const { default: nodemailer } = await import("nodemailer");
  const t = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  const GOLD2 = "#C8892A";
  const seats = (m.seats || "").split(", ").filter(Boolean);
  const usd = (c) => "$" + ((parseInt(c || "0", 10) || 0) / 100).toFixed(2);
  await t.sendMail({
    from: `NOVAPA Box Office <${process.env.SMTP_USER}>`,
    replyTo: "info@novapa.org",
    to: m.email,
    subject: `Your tickets \u2014 ${m.show_title}, ${m.performance_when}`,
    html: `
<div style="font-family:Georgia,serif;background:#f5f2ec;padding:28px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden">
<tr><td style="background:#0F1E36;padding:24px 28px">
  <div style="color:#fff;font-size:20px;font-weight:700">NOVAPA</div>
  <div style="color:${GOLD2};font-size:13px;letter-spacing:.12em;margin-top:4px">BOX OFFICE</div>
</td></tr>
<tr><td style="padding:28px">
  <div style="font-size:12px;letter-spacing:.14em;color:#888">THIS IS YOUR TICKET</div>
  <div style="font-size:22px;font-weight:700;color:#1a1a1a;margin-top:6px">${m.show_title}</div>
  <div style="font-size:15px;color:#444;margin-top:4px">${m.performance_when} \xB7 Loudoun Auditorium</div>
  <div style="font-size:13.5px;color:#666;margin-top:6px">Show this email at the door. No printing needed.</div>
  <div style="margin:22px 0;padding:18px;background:#f8f5ef;border-radius:10px;text-align:center">
    <div style="font-size:12px;letter-spacing:.14em;color:#888">ORDER CODE</div>
    <div style="font-size:32px;font-weight:800;letter-spacing:.18em;color:#0F1E36;margin-top:4px">${code}</div>
    <div style="font-size:12.5px;color:#666;margin-top:6px">Give this code and your name at the door.</div>
  </div>
  <div style="font-size:12px;letter-spacing:.1em;color:#888;margin-bottom:6px">YOUR SEATS (${seats.length})</div>
  ${seats.map((s) => `<div style="padding:8px 0;border-bottom:1px solid #eee;font-size:15px;color:#1a1a1a">${s}</div>`).join("")}
  ${m.reward_cents ? `<div style="padding:8px 0;font-size:14px;color:#2e7d4f">Referral reward \u2014 2 free tickets: \u2212${usd(m.reward_cents)}</div>` : ""}
  ${m.coupon_cents ? `<div style="padding:8px 0;font-size:14px;color:#2e7d4f">Credit ${m.coupon || ""}: \u2212${usd(m.coupon_cents)}</div>` : ""}
  <div style="padding:12px 0;font-size:15px"><b>Total paid: ${usd(m.total_cents)}</b></div>
  <p style="font-size:13px;color:#666;line-height:1.6;margin-top:16px">
    The auditorium is between the ballroom and the hotel lobby at the Northern Virginia Conference Center,
    18980 West Belmont Place, Leesburg. Park in the garage. House opens 15 minutes before curtain.
    All sales are final; tickets are non-refundable and non-transferable.</p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="margin:18px auto 0"><tr><td
    style="background:${GOLD2};border-radius:8px">
    <a href="https://www.northernvirginiaperformingarts.org/register/account.html"
       style="display:inline-block;padding:12px 26px;color:#fff;text-decoration:none;font-weight:700;font-size:14px">
      View in My NOVAPA</a></td></tr></table>
  <p style="font-size:12px;color:#999;text-align:center;margin-top:8px">
    Your tickets are always available in your account.</p>
</td></tr>
</table></div>`
  });
}
var SUPABASE_URL2;
var init_tix_confirm = __esm({
  "netlify/functions/tix-confirm.mjs"() {
    SUPABASE_URL2 = "https://tlkuqwsqicxcjdmumkje.supabase.co";
  }
});

// netlify/functions/reg-webhook.mjs
import Stripe from "stripe";

// netlify/functions/reg-email.mjs
var GOLD = "#C8892A";
var NAVY = "#0F1E36";
function money(cents) {
  return "$" + (cents / 100).toLocaleString(
    "en-US",
    { minimumFractionDigits: cents % 100 ? 2 : 0, maximumFractionDigits: 2 }
  );
}
var TEEN_CONS_IDS = [1960809, 1960811, 1805731];
function spansLunch(w) {
  if (!w || !w.time) return false;
  const m = String(w.time).match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm).*?(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i);
  if (!m) return false;
  const h = (hh, ap) => Number(hh) % 12 + (/pm/i.test(ap) ? 12 : 0);
  return h(m[1], m[3]) <= 12 && h(m[4], m[6]) >= 13;
}
var VENUE = "National Conference Center, 18945 Conference Center Drive, Plaza C, Leesburg, VA 20176";
var MAP_URL = "https://maps.google.com/?q=" + encodeURIComponent("18945 Conference Center Drive, Plaza C, Leesburg, VA 20176");
var ARRIVAL = [
  "We are in the South Building at Plaza C. Park in the south parking lot and take the walkway to the entrance.",
  "Parking is free. If you are dropping off and going, drop off at Plaza C.",
  "Pick-up has a fifteen minute grace period, after which a late fee of $15 per fifteen minutes applies. If you are running late, email us rather than letting us wonder.",
  "Email is our official channel for schedule changes, closures, casting and billing. Please check your spam folder and mark us as safe."
];
async function svcJson(path) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) return [];
  try {
    const r = await fetch(
      `https://tlkuqwsqicxcjdmumkje.supabase.co/rest/v1/${path}`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } }
    );
    return r.ok ? await r.json() : [];
  } catch {
    return [];
  }
}
function whenFrom(classTimes) {
  const t = Array.isArray(classTimes) ? classTimes[0] : null;
  if (!t) return null;
  const day = (t.title_text || "").trim();
  const time = Array.isArray(t.primary_text) ? t.primary_text.join(", ") : t.primary_text || "";
  const span = t.secondary_text || t.product_detail_date || "";
  return { day, time, span };
}
async function itemDetails(m, pi) {
  const piId = pi && pi.id;
  let rows = [];
  if (piId) {
    const orders = await svcJson(`orders?stripe_payment_intent=eq.${encodeURIComponent(piId)}&select=id,order_items(camper_name,show,band,activity_id,unit_price_cents)`);
    rows = orders[0] && orders[0].order_items || [];
    if (orders[0]) m.__order_id = orders[0].id;
  }
  if (!rows.length) return [];
  const ids = [...new Set(rows.map((r) => r.activity_id).filter(Boolean))];
  const acts = ids.length ? await svcJson(`activities?id=in.(${ids.join(",")})&select=id,name,class_times,location,age_range,category,price_cents`) : [];
  const byId = Object.fromEntries(acts.map((a) => [a.id, a]));
  return rows.map((r) => {
    const a = r.activity_id ? byId[r.activity_id] : null;
    const w = a ? whenFrom(a.class_times) : null;
    const summer = !!r.show;
    const price = a ? a.price_cents || 0 : 99500;
    const cat = a ? a.category : "camp";
    return {
      camper: r.camper_name || "Camper",
      name: a ? a.name : r.show ? `${r.show} (ages ${r.band})` : "Program",
      ages: a && a.age_range ? a.age_range : "",
      when: w,
      price: r.unit_price_cents,
      // Day-1 auditions run for every production. Teen Conservatory casts
      // audition months ahead, so Sweeney, Hadestown and Dear Evan Hansen are
      // out — Mean Girls is back on day-1 auditions (Jason, Aug 13).
      production: summer || cat === "camp" && price >= 5e4 && !TEEN_CONS_IDS.includes(a && a.id),
      allDay: summer || spansLunch(w)
    };
  });
}
function confirmationHtml(m, pi, details) {
  const items = (m.order_desc || "").split("; ").filter(Boolean);
  const today = pi.amount_received ?? pi.amount;
  const total = parseInt(m.total_cents || "0", 10) || today;
  const nInst = parseInt(m.n_installments || "0", 10) || 0;
  const instCents = parseInt(m.installment_cents || "0", 10) || 0;
  const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  let planLine = "Paid in full \u2014 no future charges.";
  if (m.plan === "deposit" && nInst && firstInst) {
    const d = new Date(firstInst * 1e3);
    planLine = `Then ${nInst} monthly payments of ${money(instCents)}, automatic on your card, starting ${months[d.getUTCMonth()]} 1, ${d.getUTCFullYear()} \u2014 fully paid before your program begins.`;
  } else if (m.plan === "subscription") {
    planLine = m.first_month_free === "1" ? "Your first month is on us. Your card is saved, and monthly tuition starts October 1, then the 1st of each month through June 1, 2027. Nothing is charged in September, and nothing is charged after June \u2014 the plan ends itself. Cancel any time with 30 days' notice." : "Today's payment covers your first month, so there is no further charge in September. Monthly tuition then runs October 1 and the 1st of each month through June 1, 2027, and the plan ends itself after that. Cancel any time with 30 days' notice.";
  }
  const esc = (x) => String(x == null ? "" : x).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const rows = details && details.length ? details.map((d) => `<tr><td style="padding:14px 0;border-bottom:1px solid #eee8dd">
        <div style="font-size:15px;color:#2a2a2a"><b>${esc(d.name)}</b></div>
        <div style="font-size:14px;color:#444;margin-top:3px">Participant: ${esc(d.camper)}${d.ages ? " &nbsp;\xB7&nbsp; ages " + esc(d.ages) : ""}</div>
        ${d.when && (d.when.day || d.when.span) ? `<div style="font-size:14px;color:#444;margin-top:3px">
          ${d.when.day ? "<b>" + esc(d.when.day) + "</b>" : ""}${d.when.time ? " &nbsp;" + esc(d.when.time) : ""}
          ${d.when.span ? "<br>" + esc(d.when.span) : ""}</div>` : ""}
        ${d.price != null ? `<div style="font-size:13.5px;color:#666;margin-top:3px">${money(d.price)}</div>` : ""}
      </td></tr>`).join("") : items.map(
    (it) => `<tr><td style="padding:10px 0;border-bottom:1px solid #eee8dd;font-size:15px;color:#2a2a2a">${it}</td></tr>`
  ).join("");
  const couponRow = m.coupon ? `<tr><td style="padding:6px 0;font-size:14px;color:#2e7d4f">Coupon ${m.coupon}: \u2212${money(parseInt(m.coupon_cents || "0", 10))}</td></tr>` : "";
  return `<!doctype html><html><body style="margin:0;padding:0;background:#f5f2ec;font-family:Georgia,'Times New Roman',serif">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;padding:28px 12px"><tr><td align="center">
    <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e7e0d2">
      <tr><td style="background:${NAVY};padding:26px 32px;text-align:center">
        <div style="font-family:Georgia,serif;font-size:22px;letter-spacing:0.25em;color:#ffffff">NOVA<span style="color:#E8B84B">PA</span></div>
        <div style="font-size:12px;letter-spacing:0.18em;color:#c9b47a;text-transform:uppercase;margin-top:6px">Registration Confirmed</div>
      </td></tr>
      <tr><td style="padding:30px 32px 8px">
        <p style="margin:0 0 16px;font-size:16px;color:#2a2a2a">Hi${m.parent_name ? " " + m.parent_name.split(" ")[0] : ""},</p>
        <p style="margin:0 0 18px;font-size:15px;color:#444;line-height:1.6">You're in! Here's what we have for your family:</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">${rows}</table>
      </td></tr>
      <tr><td style="padding:14px 32px 6px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf7f0;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            ${couponRow ? '<table role="presentation" width="100%">' + couponRow + "</table>" : ""}
            <div style="font-size:15px;color:#2a2a2a"><b>Paid today: ${money(today)}</b>${total > today ? " &nbsp;\xB7&nbsp; Program total: " + money(total) : ""}</div>
            <div style="font-size:13.5px;color:#666;margin-top:6px;line-height:1.5">${planLine}</div>
          </td></tr>
        </table>
      </td></tr>

      ${details && details.some((d) => d.production) ? `
      <tr><td style="padding:14px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">Auditions are on day one</div>
            <p style="margin:8px 0 0;font-size:14px;color:#2a2a2a;line-height:1.6">
              This is for placement only. <b>Everyone who registered is in the company and everyone is cast.</b>
              Day one decides where your performer fits best.</p>
            <p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">What to bring to the audition:</p>
            <ul style="margin:6px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              <li style="margin:4px 0"><b>A song they are confident singing.</b> Sixteen to thirty-two bars is plenty. Sheet music in a binder, or a backing track on a phone with a way to play it.</li>
              <li style="margin:4px 0"><b>A short monologue</b> if they have one they like. Optional, but it helps us.</li>
              <li style="margin:4px 0">Themselves, warmed up, having slept.</li>
            </ul>
            <p style="margin:10px 0 0;font-size:13.5px;color:#666;line-height:1.6">
              An audition here is not a test anyone can fail. We already want them. We are listening for where their
              voice sits and which room will stretch them most.</p>
          </td></tr>
        </table>
      </td></tr>` : ""}
      <tr><td style="padding:14px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">What to bring and wear</div>
            <ul style="margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              ${details && details.some((d) => d.allDay) ? `<li style="margin:4px 0"><b>A packed lunch and a snack.</b> Lunch is not provided. No delivery during the day, and that one is firm.</li>` : ""}
              <li style="margin:4px 0">A refillable <b>water bottle</b>, named.</li>
              <li style="margin:4px 0">A <b>pencil</b>. Not a pen.</li>
              <li style="margin:4px 0">A <b>layer</b> \u2014 the building runs cold.</li>
              <li style="margin:4px 0">Anything with a name on it stands a much better chance of coming home.</li>
            </ul>
            <p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">
              <b>What to wear:</b> modest movement clothes with closed-toed shoes or dance shoes. Leggings, joggers or
              athletic shorts with a fitted top or t-shirt, things that stay put when you bend, lift your arms or lie on
              the floor. Hair tied back and off the face. No dangling jewellery or smartwatches. On the build crew,
              closed-toed shoes are the rule, not a suggestion.</p>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:18px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf7f0;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">Where to go</div>
            <div style="font-size:14.5px;color:#2a2a2a;margin-top:6px">${VENUE}</div>
            <div style="margin-top:8px"><a href="${MAP_URL}" style="color:${GOLD};font-size:14px">Get directions &rarr;</a></div>
            <ul style="margin:12px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              ${ARRIVAL.map((l) => `<li style="margin:4px 0">${l}</li>`).join("")}
            </ul>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:14px 32px 6px">
        <p style="margin:0;font-size:13.5px;color:#555;line-height:1.7">
          ${m.__order_id ? `Reference: order ${String(m.__order_id).slice(0, 8).toUpperCase()}<br>` : ""}
          ${m.fsa_eligible === "1" && pi && pi.id ? `Using a Dependent Care FSA? <a href="https://www.northernvirginiaperformingarts.org/api/fsa-receipt?pi=${pi.id}" style="color:${GOLD}">View and print your dependent-care receipt</a> (Tax ID 99-1421341).<br>` : m.fsa_eligible === "1" ? "Using a Dependent Care FSA? Print your dependent-care receipt from your confirmation page (Tax ID 99-1421341).<br>" : ""}
        </p>
      </td></tr>
      <tr><td style="padding:8px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">If plans change</div>
            <ul style="margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              <li style="margin:5px 0"><b>All fees are non-refundable</b>, including for missed days or early withdrawal. Registering is a commitment to the full fee.</li>
              <li style="margin:5px 0"><b>Withdrawals must be in writing, at least one month before the program starts.</b> Email <a href="mailto:info@novapa.org" style="color:${GOLD}">info@novapa.org</a> \u2014 only written notice inside that window can be moved to another program.</li>
              <li style="margin:5px 0">Drop out <b>60 or more days before the start</b> with the balance paid in full and what you paid can go toward a future program as a tuition credit, good for one year, administrative fees apply.</li>
              <li style="margin:5px 0">Withdrawals <b>inside 30 days</b> are not eligible for a credit, and partial payments are non-transferable.</li>
              <li style="margin:5px 0">If we cancel for weather or an emergency, a make-up is scheduled rather than a refund issued.</li>
            </ul>
            ${m.insured === "1" ? `<p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">
              <b>You bought tuition insurance</b>, so a withdrawal refunds 100% at 90&ndash;76 days before the start,
              75% at 75&ndash;51 days, 50% at 50&ndash;31 days, and 0% inside 30 days. Email us to start a claim.
              The premium itself is non-refundable and is deducted from the refund.</p>` : ""}
            <p style="margin:10px 0 0;font-size:13px;color:#777;line-height:1.6">
              This is a summary. The full terms are at
              <a href="https://www.northernvirginiaperformingarts.org/policies#refunds" style="color:${GOLD}">novapa.org/policies</a>
              and they govern.</p>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:20px 32px 26px">
        <p style="margin:0;font-size:13px;color:#999;line-height:1.6;border-top:1px solid #eee8dd;padding-top:16px">
          Northern Virginia Performing Arts \xB7 Leesburg, VA<br>
          <a href="mailto:info@novapa.org" style="color:${GOLD}">info@novapa.org</a> \xB7 (571) 571-2120
        </p>
      </td></tr>
    </table>
  </td></tr></table><table role="presentation" cellpadding="0" cellspacing="0" style="margin:22px auto 0"><tr><td style="background:${GOLD};border-radius:8px"><a href="https://www.northernvirginiaperformingarts.org/register/account.html" style="display:inline-block;padding:12px 26px;color:#fff;text-decoration:none;font-weight:700;font-size:14px;font-family:Georgia,serif">View or update in My NOVAPA</a></td></tr></table><p style="font-size:12px;color:#999;text-align:center;margin-top:8px;font-family:Georgia,serif">Your registrations, tickets, and credits live in your account.</p></body></html>`;
}
async function ccFor(email) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key || !email) return null;
  try {
    const r = await fetch(
      `https://tlkuqwsqicxcjdmumkje.supabase.co/rest/v1/families?select=cc_email&email=eq.${encodeURIComponent(email.toLowerCase())}&limit=1`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } }
    );
    const rows = r.ok ? await r.json() : [];
    return rows[0]?.cc_email || null;
  } catch {
    return null;
  }
}
var DCU_PINK = "#ff2d8f";
var DCU_INK = "#0d0d0d";
var DCU_VENUE = "The National Conference Center, 18665 Conference Center Drive, Leesburg, VA 20176";
var DCU_TRACKS = {
  970601: { when: "October 15\u201318, 2026", where: DCU_VENUE, note: null },
  970602: {
    when: "October 24\u201325, 2026",
    where: "Online \u2014 live callback weekend",
    note: "Your join details will be emailed to you before the event."
  },
  // No submission deadline is published on the site, so this promises a
  // follow-up rather than inventing a date.
  970603: {
    when: "Asynchronous \u2014 submit on your own schedule",
    where: "Online",
    note: "Your upload link and submission window will be emailed to you."
  }
};
function dcuConfirmationHtml(m, pi) {
  const paid = pi ? pi.amount_received ?? pi.amount ?? 0 : 0;
  const total = parseInt(m.total_cents || "0", 10) || 0;
  const nInst = parseInt(m.n_installments || "0", 10) || 0;
  const instCents = parseInt(m.installment_cents || "0", 10) || 0;
  const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
  const track = DCU_TRACKS[parseInt(m.activity_id || "0", 10)] || {};
  const fmt = (t) => new Date(t * 1e3).toLocaleDateString(
    "en-US",
    { month: "long", day: "numeric", year: "numeric", timeZone: "UTC" }
  );
  const row = (k, v) => `<tr><td style="padding:7px 16px 7px 0;color:#666;font-size:14px">${k}</td><td style="padding:7px 0;font-size:14px;font-weight:600">${v}</td></tr>`;
  const facts = [
    row("Student", m.student_name || "\u2014"),
    row("Track", (m.order_desc || "").split(" \u2014 ").slice(1).join(" \u2014 ") || "DC Unifieds 2026"),
    track.when ? row("When", track.when) : "",
    track.where ? row("Where", track.where) : ""
  ].join("");
  const money2 = [
    row("Total", money(total)),
    row("Paid today", money(paid)),
    nInst ? row(
      "Remaining",
      `${nInst} \xD7 ${money(instCents)}, charged automatically starting ${fmt(firstInst)}`
    ) : ""
  ].join("");
  return `<div style="font-family:Helvetica,Arial,sans-serif;background:#f4f4f5;padding:28px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden">
<tr><td style="background:${DCU_INK};padding:26px 28px">
  <div style="color:#fff;font-size:20px;font-weight:800;letter-spacing:.14em">DC UNIFIEDS</div>
  <div style="color:${DCU_PINK};font-size:13px;font-weight:700;margin-top:5px">COLLEGE AUDITIONS 2026</div>
</td></tr>
<tr><td style="padding:28px">
  <div style="font-size:23px;font-weight:800;color:${DCU_INK};margin-bottom:6px">You're registered.</div>
  <p style="font-size:15px;color:#444;line-height:1.6;margin:0 0 22px">
    Thanks${m.parent_name ? ", " + m.parent_name : ""} \u2014 your spot is confirmed. Here are the details.</p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse">${facts}</table>
  ${track.note ? `<p style="font-size:14px;color:#444;line-height:1.6;margin:18px 0 0">${track.note}</p>` : ""}
  <div style="height:1px;background:#e5e5e5;margin:22px 0"></div>
  <div style="font-size:12px;font-weight:800;letter-spacing:.1em;color:#888;margin-bottom:8px">PAYMENT</div>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse">${money2}</table>
  ${nInst ? `<p style="font-size:13px;color:#666;line-height:1.6;margin:14px 0 0">
    Installments are charged to the card you used today. All installments are paid in full before the event.</p>` : ""}
  <div style="height:1px;background:#e5e5e5;margin:22px 0"></div>
  <p style="font-size:14px;color:#444;line-height:1.6;margin:0">
    Questions about your registration, or need to change something?
    Email <a href="mailto:support@dcunifieds.com" style="color:${DCU_PINK};font-weight:700">support@dcunifieds.com</a>.</p>
</td></tr>
<tr><td style="padding:18px 28px 24px;background:#fafafa;color:#888;font-size:12px;line-height:1.6">
  DC Unifieds \xB7 ${DCU_VENUE}<br>All sales final. Installment plans must be paid in full prior to the event.
</td></tr>
</table></div>`;
}
async function sendConfirmationEmail(m, pi) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS || !m.email) return;
  const { default: nodemailer } = await import("nodemailer");
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  if (m.brand === "dcu") {
    await transporter.sendMail({
      from: `DC Unifieds <${process.env.SMTP_USER}>`,
      replyTo: "support@dcunifieds.com",
      to: m.email,
      subject: "You're registered \u2014 DC Unifieds 2026",
      html: dcuConfirmationHtml(m, pi)
    });
    return;
  }
  const cc = await ccFor(m.email);
  let details = [];
  try {
    details = await itemDetails(m, pi);
  } catch (e) {
    console.error("item details failed:", e.message);
  }
  await transporter.sendMail({
    from: `NOVAPA <${process.env.SMTP_USER}>`,
    replyTo: "info@novapa.org",
    to: m.email,
    ...cc ? { cc } : {},
    subject: "You're in \u2014 NOVAPA registration confirmed",
    html: confirmationHtml(m, pi, details)
  });
}

// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/reg-webhook.mjs
var INSTALLMENT_PRODUCT_ID = "novapa-summer-2027-installments";
var CLASS_PRODUCT_ID = "novapa-class-monthly";
var DCU_INSTALLMENT_PRODUCT_ID = "dcunifieds-2026-installments";
async function serviceRpc(fn, args) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(args)
  });
  const text = await res.text();
  if (!res.ok) throw new Error(`rpc ${fn} failed ${res.status}: ${text.slice(0, 300)}`);
  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
}
async function ensureProduct(stripe, id, name) {
  try {
    await stripe.products.retrieve(id);
  } catch {
    await stripe.products.create({ id, name });
  }
}
var reg_webhook_default = async (req) => {
  if (req.method !== "POST") return new Response("method not allowed", { status: 405 });
  if (!process.env.STRIPE_SECRET_KEY || !process.env.STRIPE_WEBHOOK_SECRET || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return new Response("not configured", { status: 503 });
  }
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const sig = req.headers.get("stripe-signature");
  const rawBody = await req.text();
  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(rawBody, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("webhook signature verification failed:", err.message);
    return new Response("bad signature", { status: 400 });
  }
  if (event.type !== "payment_intent.succeeded" && event.type !== "setup_intent.succeeded") {
    return new Response("ignored", { status: 200 });
  }
  const pi = event.data.object;
  const m = pi.metadata || {};
  if (m.tix_hold_id) {
    try {
      const { confirmTickets: confirmTickets2 } = await Promise.resolve().then(() => (init_tix_confirm(), tix_confirm_exports));
      await confirmTickets2(pi);
      return new Response("ok", { status: 200 });
    } catch (err) {
      console.error("tix confirm error:", err.message);
      return new Response("error", { status: 500 });
    }
  }
  if (!m.hold_id || !m.plan) return new Response("no metadata", { status: 200 });
  if (m.plan === "subscription") {
    try {
      const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      const hdrs = { apikey: key, Authorization: `Bearer ${key}` };
      const hr = await fetch(`${SUPABASE_URL}/rest/v1/holds?id=eq.${encodeURIComponent(m.hold_id)}&select=items`, { headers: hdrs });
      const holdRows = await hr.json();
      const holdItems = holdRows[0] && holdRows[0].items || [];
      const wanted = holdItems.filter((it) => it.activity_id).map((it) => `${(it.camper || "").toLowerCase()}|${it.activity_id}`);
      if (wanted.length) {
        const or = await fetch(
          `${SUPABASE_URL}/rest/v1/orders?email=ilike.${encodeURIComponent(m.email || "")}&plan=eq.subscription&status=in.(paid,confirmed,complete,succeeded)&select=id,stripe_payment_intent,order_items(camper_name,activity_id)`,
          { headers: hdrs }
        );
        const prior = await or.json() || [];
        const dupe = prior.find(
          (o) => o.stripe_payment_intent !== pi.id && (o.order_items || []).some((oi) => wanted.includes(`${(oi.camper_name || "").toLowerCase()}|${oi.activity_id}`))
        );
        if (dupe) {
          console.log(`duplicate class enrollment ignored: ${pi.id} matches order ${dupe.id}`);
          return new Response("duplicate enrollment ignored", { status: 200 });
        }
      }
    } catch (e) {
      console.error("dupe guard failed:", e.message);
    }
  }
  try {
    const nItems = parseInt(m.n_items || "0", 10) || 0;
    let unitPrices;
    if (m.unit_prices) {
      try {
        unitPrices = JSON.parse(m.unit_prices);
      } catch {
        unitPrices = [];
      }
    } else {
      unitPrices = Array.from({ length: nItems }, () => parseInt(m.unit_cents || "0", 10));
    }
    const orderId = await serviceRpc("confirm_order", {
      p_hold_id: m.hold_id,
      p_email: m.email || "",
      p_parent_name: m.parent_name || null,
      p_plan: m.plan,
      p_amount_today_cents: pi.amount_received ?? pi.amount ?? 0,
      // SetupIntents carry no amount
      p_total_cents: parseInt(m.total_cents || "0", 10),
      p_installment_cents: parseInt(m.installment_cents || "0", 10) || null,
      p_stripe_payment_intent: pi.id,
      p_stripe_customer: typeof pi.customer === "string" ? pi.customer : pi.customer?.id,
      p_unit_prices: unitPrices
    });
    if (m.guest === "1" && m.email) {
      try {
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
        const hdrs = { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" };
        let fam = (await (await fetch(
          `${SUPABASE_URL}/rest/v1/families?or=(email.ilike.${encodeURIComponent(m.email)},cc_email.ilike.${encodeURIComponent(m.email)})&select=id&limit=1`,
          { headers: hdrs }
        )).json())[0];
        if (!fam) {
          const made = await (await fetch(`${SUPABASE_URL}/rest/v1/families`, {
            method: "POST",
            headers: { ...hdrs, Prefer: "return=representation" },
            body: JSON.stringify({ email: m.email, parent_name: m.parent_name || null, source: "web" })
          })).json();
          fam = Array.isArray(made) ? made[0] : null;
        }
        if (fam) {
          const holdRows = await (await fetch(
            `${SUPABASE_URL}/rest/v1/holds?id=eq.${m.hold_id}&select=items&limit=1`,
            { headers: hdrs }
          )).json();
          const names = [...new Set((holdRows?.[0]?.items || []).map((it) => String(it.camper || "").trim()).filter(Boolean))];
          let bdays = {};
          try {
            bdays = JSON.parse(m.kid_bdays || "{}");
          } catch {
          }
          const existing = await (await fetch(
            `${SUPABASE_URL}/rest/v1/campers?family_id=eq.${fam.id}&select=name`,
            { headers: hdrs }
          )).json();
          const have = new Set((existing || []).map((c) => String(c.name).toLowerCase()));
          const fresh = names.filter((n) => !have.has(n.toLowerCase())).map((n) => ({
            family_id: fam.id,
            name: n,
            birthdate: bdays[n] || null,
            source: "web"
          }));
          if (fresh.length) {
            await fetch(`${SUPABASE_URL}/rest/v1/campers`, { method: "POST", headers: hdrs, body: JSON.stringify(fresh) });
          }
        }
      } catch (e) {
        console.error("guest family upsert failed:", e.message);
      }
    }
    if (m.parent_name && m.email) {
      try {
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
        await fetch(`${SUPABASE_URL}/rest/v1/families?or=(email.ilike.${encodeURIComponent(m.email)},cc_email.ilike.${encodeURIComponent(m.email)})`, {
          method: "PATCH",
          headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({ parent_name: m.parent_name })
        });
      } catch (e) {
        console.error("parent_name save failed:", e.message);
      }
    }
    const paymentMethodId = typeof pi.payment_method === "string" ? pi.payment_method : pi.payment_method?.id;
    const customerId = typeof pi.customer === "string" ? pi.customer : pi.customer?.id;
    if (m.plan === "subscription") {
      let monthly = [];
      try {
        monthly = JSON.parse(m.monthly_items || "[]");
      } catch {
      }
      if (monthly.length) {
        await ensureProduct(stripe, CLASS_PRODUCT_ID, "NOVAPA Season Class \u2014 Monthly Tuition");
        const nowUTC = /* @__PURE__ */ new Date();
        const firstOfNextMonth = Math.floor(
          Date.UTC(nowUTC.getUTCFullYear(), nowUTC.getUTCMonth() + 1, 1, 4, 0, 0) / 1e3
        );
        const trialEnd = Math.max(CLASS_BILL_ANCHOR_UTC, firstOfNextMonth);
        const sub = await stripe.subscriptions.create({
          customer: customerId,
          default_payment_method: paymentMethodId || void 0,
          trial_end: trialEnd,
          cancel_at: CLASS_SEASON_END_UTC,
          // season ends after the Jun 1 pull
          proration_behavior: "none",
          items: monthly.map((cents) => ({
            quantity: 1,
            price_data: {
              currency: "usd",
              product: CLASS_PRODUCT_ID,
              recurring: { interval: "month" },
              unit_amount: cents
            }
          })),
          metadata: { order_id: String(orderId), payment_intent: pi.id }
        });
        await serviceRpc("set_order_schedule", { p_order_id: orderId, p_schedule: sub.id });
      }
    }
    if (m.plan === "deposit" && parseInt(m.installment_cents || "0", 10) > 0) {
      const isDcu = m.brand === "dcu";
      const instProductId = isDcu ? DCU_INSTALLMENT_PRODUCT_ID : INSTALLMENT_PRODUCT_ID;
      await ensureProduct(stripe, instProductId, isDcu ? "DC Unifieds 2026 \u2014 Monthly Installment" : "NOVAPA Program \u2014 Monthly Installment");
      const paymentMethod = typeof pi.payment_method === "string" ? pi.payment_method : pi.payment_method?.id;
      const nInst = parseInt(m.n_installments || "0", 10) || 0;
      const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
      if (!nInst || !firstInst) throw new Error("deposit plan missing installment schedule");
      const schedule = await stripe.subscriptionSchedules.create({
        customer: typeof pi.customer === "string" ? pi.customer : pi.customer?.id,
        start_date: firstInst,
        end_behavior: "cancel",
        default_settings: paymentMethod ? {
          default_payment_method: paymentMethod,
          collection_method: "charge_automatically"
        } : void 0,
        metadata: { order_id: String(orderId), payment_intent: pi.id },
        phases: [{
          iterations: nInst,
          proration_behavior: "none",
          items: [{
            quantity: 1,
            price_data: {
              currency: "usd",
              product: instProductId,
              recurring: { interval: "month" },
              unit_amount: parseInt(m.installment_cents, 10)
            }
          }]
        }]
      });
      await serviceRpc("set_order_schedule", {
        p_order_id: orderId,
        p_schedule: schedule.id
      });
    }
    try {
      const holdItems = await serviceRpc("hold_items_admin", { p_hold_id: m.hold_id });
      if (Array.isArray(holdItems) && holdItems.length) {
        await serviceRpc("mark_registered", { p_email: m.email || "", p_items: holdItems });
      }
    } catch (e) {
      console.error("mark_registered failed:", e.message);
    }
    if (m.coupon) {
      try {
        await serviceRpc("redeem_coupon", {
          p_code: m.coupon,
          p_applied_cents: parseInt(m.coupon_cents || "0", 10) || 0
        });
      } catch (e) {
        console.error("coupon redeem failed:", e.message);
      }
    }
    if (m.ref_code && m.ref_referrer && m.email) {
      try {
        const rk = process.env.SUPABASE_SERVICE_ROLE_KEY;
        await fetch(`${SUPABASE_URL}/rest/v1/referral_rewards?on_conflict=referred_email`, {
          method: "POST",
          headers: {
            apikey: rk,
            Authorization: `Bearer ${rk}`,
            "Content-Type": "application/json",
            Prefer: "resolution=ignore-duplicates"
          },
          body: JSON.stringify({
            ref_code: m.ref_code,
            referrer_email: m.ref_referrer,
            referred_email: (m.email || "").toLowerCase()
          })
        });
      } catch (e) {
        console.error("referral reward failed:", e.message);
      }
    }
    try {
      const grants = JSON.parse(m.credit_grants || "[]");
      const redemptions = JSON.parse(m.credit_redeems || "[]");
      if ((grants.length || redemptions.length) && m.email) {
        const rk = process.env.SUPABASE_SERVICE_ROLE_KEY;
        await fetch(`${SUPABASE_URL}/rest/v1/rpc/apply_credit_events`, {
          method: "POST",
          headers: { apikey: rk, Authorization: `Bearer ${rk}`, "Content-Type": "application/json" },
          body: JSON.stringify({ p_pi: pi.id, p_email: m.email, p_detail: { grants, redemptions } })
        });
      }
    } catch (e) {
      console.error("credit events failed:", e.message);
    }
    try {
      const key2 = process.env.SUPABASE_SERVICE_ROLE_KEY;
      const ar = await fetch(`${SUPABASE_URL}/rest/v1/admin_emails?select=email`, {
        headers: { apikey: key2, Authorization: `Bearer ${key2}` }
      });
      const admins = (await ar.json()).map((r) => r.email).filter(Boolean);
      if (admins.length) {
        const { default: nodemailer } = await import("nodemailer");
        const t2 = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 465,
          secure: true,
          auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
        });
        const paid = ((pi.amount_received ?? pi.amount) / 100).toFixed(2);
        const total = ((parseInt(m.total_cents || "0", 10) || 0) / 100).toFixed(2);
        const usd = (c) => "$" + ((parseInt(c || "0", 10) || 0) / 100).toFixed(2);
        let units = [];
        try {
          units = JSON.parse(m.unit_prices || "[]");
        } catch {
        }
        const lines = (m.order_desc || "").split("; ");
        const itemRows = lines.map((ln, i) => `<tr><td style="padding:3px 14px 3px 0">${ln}</td><td align="right">${units[i] != null ? usd(units[i]) : ""}</td></tr>`).join("");
        const subtotalCents = units.reduce((a, b) => a + (b || 0), 0);
        const nInst = parseInt(m.n_installments || "0", 10) || 0;
        const instCents = parseInt(m.installment_cents || "0", 10) || 0;
        const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
        const remaining = Math.max(0, (parseInt(m.total_cents || "0", 10) || 0) - Math.round(parseFloat(paid) * 100));
        const moneyRows = [
          [`Subtotal`, usd(subtotalCents)],
          m.coupon ? [`Coupon ${m.coupon}`, "\u2212" + usd(m.coupon_cents)] : null,
          parseInt(m.plan_fee_cents || "0", 10) || 0 ? [`Payment plan fee (5%)`, usd(m.plan_fee_cents)] : null,
          m.insured === "1" ? [`Tuition insurance`, usd(m.insurance_cents)] : null,
          [`<b>Order total</b>`, `<b>${usd(m.total_cents)}</b>`],
          [`Paid today`, `$${paid}`],
          remaining ? [`Remaining balance`, usd(remaining)] : null,
          nInst ? [`Schedule`, `${nInst} \xD7 ${usd(instCents)} monthly, first ${new Date(firstInst * 1e3).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })}`] : null,
          m.first_month_free === "1" ? [`First month free`, "card saved, billing starts Oct 1"] : null,
          [`FSA eligible`, m.fsa_eligible === "1" ? "yes" : "no"]
        ].filter(Boolean).map(([k, v]) => `<tr><td style="padding:3px 14px 3px 0;color:#555">${k}</td><td align="right">${v}</td></tr>`).join("");
        await t2.sendMail({
          from: `NOVAPA Registrations <${process.env.SMTP_USER}>`,
          to: admins.join(", "),
          subject: `${m.brand === "dcu" ? "DC Unifieds" : "New"} registration: ${m.parent_name || m.email} \u2014 $${paid} (${m.plan})`,
          html: [
            `<b>${m.parent_name || "(no name)"}</b> &lt;${m.email}&gt;${m.phone ? ` \xB7 ${m.phone}` : ""} \xB7 plan: <b>${m.plan}</b>`,
            `<table style="border-collapse:collapse;font-size:14px">${itemRows}<tr><td colspan="2" style="border-top:1px solid #ddd;padding:0;height:6px"></td></tr>${moneyRows}</table>`,
            `<a href="https://dashboard.stripe.com/payments/${pi.id}">View payment in Stripe</a> \xB7 <a href="https://www.northernvirginiaperformingarts.org/register/admin/">Admin dashboard</a>`
          ].join("<br><br>")
        });
      }
    } catch (e) {
      console.error("admin notify failed:", e.message);
    }
    try {
      await sendConfirmationEmail(m, pi);
    } catch (e) {
      console.error("confirmation email failed:", e.message);
    }
    return new Response("ok", { status: 200 });
  } catch (err) {
    console.error("reg-webhook error:", err.message);
    try {
      if (process.env.SMTP_USER && process.env.SMTP_PASS) {
        {
          const { default: nodemailer } = await import("nodemailer");
          const t = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 465,
            secure: true,
            auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          });
          const md = pi && pi.metadata || {};
          await t.sendMail({
            from: `NOVAPA Alerts <${process.env.SMTP_USER}>`,
            to: "jason@novapa.org",
            subject: `WEBHOOK FAILED: payment without order \u2014 ${md.email || "unknown"}`,
            html: [
              `A Stripe event was received but order creation FAILED. The customer paid (or saved a card) and got nothing.`,
              `<b>Error:</b> ${String(err.message || err).slice(0, 300)}`,
              `<b>Customer:</b> ${md.email || "?"} \xB7 <b>plan:</b> ${md.plan || "?"} \xB7 <b>desc:</b> ${md.order_desc || "?"}`,
              `<b>Payment intent:</b> ${pi ? pi.id : "?"} \u2014 <a href="https://dashboard.stripe.com/payments/${pi ? pi.id : ""}">open in Stripe</a>`,
              `Stripe will auto-retry for up to 3 days; if this alert repeats for the same intent, the failure is persistent and needs a code/data fix before the retries run out.`
            ].join("<br><br>")
          });
        }
      }
    } catch (mailErr) {
      console.error("failure alert email failed:", mailErr.message);
    }
    return new Response("error", { status: 500 });
  }
};
var config = { path: "/api/reg-webhook" };
export {
  config,
  reg_webhook_default as default
};
