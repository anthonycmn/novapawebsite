
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/sweeney-db.mjs
import { getStore } from "@netlify/blobs";
var GATE = process.env.SWEENEY_GATE_WORD || "fleet";
var SB_URL = process.env.SWEENEY_SUPABASE_URL;
var SB_KEY = process.env.SWEENEY_SUPABASE_SERVICE_ROLE_KEY;
var USE_SUPABASE = !!(SB_URL && SB_KEY);
var S = (v) => (v == null ? "" : String(v)).slice(0, 4e3);
var I = (v) => {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : 0;
};
var B = (v) => v === true || v === "true";
var D = (v) => {
  const s = S(v).slice(0, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : null;
};
var MAX_LINKS = 12;
var URLS = (list, one) => {
  const raw = Array.isArray(list) && list.length ? list : one ? [one] : [];
  const out = [], seen = /* @__PURE__ */ new Set();
  for (const x of raw) {
    const src = typeof x === "string" ? { u: x } : x || {};
    const u = S(src.u ?? src.url ?? src.link).trim();
    if (!/^https?:\/\//i.test(u) || seen.has(u)) continue;
    seen.add(u);
    out.push({ u, p: Math.max(0, I(src.p)), q: Math.max(1, I(src.q) || 1) });
    if (out.length >= MAX_LINKS) break;
  }
  return out;
};
var _store = null;
var _strong = true;
function store() {
  if (!_store) _store = getStore(_strong ? { name: "sweeney", consistency: "strong" } : { name: "sweeney" });
  return _store;
}
function downgrade(e) {
  if (_strong && /consistency|uncachedEdgeURL/i.test(String(e && e.message || e))) {
    _strong = false;
    _store = null;
    return true;
  }
  return false;
}
async function withStore(fn) {
  try {
    return await fn(store());
  } catch (e) {
    if (downgrade(e)) return await fn(store());
    throw e;
  }
}
async function readDoc(key) {
  try {
    const r = await withStore((s) => s.getWithMetadata(key, { type: "json" }));
    return { data: r && r.data || {}, etag: r && r.etag };
  } catch {
    return { data: {}, etag: void 0 };
  }
}
async function mutate(key, apply, tries = 8) {
  for (let i = 0; i < tries; i++) {
    const { data: data2, etag } = await readDoc(key);
    const next = apply({ ...data2 });
    const res = await withStore((s) => s.setJSON(key, next, etag ? { onlyIfMatch: etag } : { onlyIfNew: true }));
    if (res && res.modified) return true;
    await new Promise((r) => setTimeout(r, 8 + Math.floor(Math.random() * 25)));
  }
  const { data } = await readDoc(key);
  await withStore((s) => s.setJSON(key, apply({ ...data })));
  return true;
}
var asRows = (obj, map) => Object.keys(obj || {}).map((k) => map(k, obj[k]));
var BLOBS = {
  progress_list: async () => asRows(
    (await readDoc("progress")).data,
    (k, v) => ({ block_id: k, done: !!v.done, done_by: v.by || "", done_at: v.at || null })
  ).filter((r) => r.done),
  progress_set: async (a) => mutate("progress", (d) => {
    if (B(a.done)) d[S(a.block_id)] = { done: true, by: S(a.by), at: (/* @__PURE__ */ new Date()).toISOString() };
    else delete d[S(a.block_id)];
    return d;
  }),
  items_list: async () => asRows(
    (await readDoc("items")).data,
    (k, v) => ({
      item_id: k,
      status: v.status || "todo",
      vendor: v.vendor || "",
      link: v.link || "",
      // Items written before multiple links existed have only `link`.
      links: URLS(v.links, v.link),
      price_cents: v.price_cents || 0,
      qty: v.qty || 1,
      updated_by: v.by || "",
      updated_at: v.at || null,
      // Set once the item has been emailed to Todd. Its presence is
      // what stops the next email carrying the same thing again.
      sent_at: v.sent_at || null,
      sent_by: v.sent_by || ""
    })
  ),
  // `at` is stamped server-side. The rehearsal report asks "what was sourced
  // today", and a client clock is the wrong thing to answer that with.
  item_set: async (a) => mutate("items", (d) => {
    const links = URLS(a.links, a.link);
    d[S(a.item_id)] = {
      status: S(a.status) || "todo",
      vendor: S(a.vendor),
      // `link` stays the head of the list so anything still
      // reading the single field gets the primary source.
      link: links.length ? links[0].u : "",
      links,
      price_cents: I(a.price_cents),
      qty: I(a.qty) || 1,
      by: S(a.by),
      at: (/* @__PURE__ */ new Date()).toISOString(),
      // Empty clears it — that is the unlock path, and it has
      // to be able to travel or an unlock on one phone would
      // never reach the others.
      sent_at: S(a.sent_at) || null,
      sent_by: S(a.sent_by)
    };
    return d;
  }),
  roster_list: async () => asRows(
    (await readDoc("roster")).data,
    (k, v) => ({
      person_id: k,
      name: v.name || "",
      role: v.role || "",
      kind: v.kind || "cast",
      sort: v.sort == null ? 100 : v.sort
    })
  ).sort((x, y) => x.sort - y.sort || x.person_id.localeCompare(y.person_id)),
  roster_set: async (a) => mutate("roster", (d) => {
    if (a.active === false) delete d[S(a.person_id)];
    else d[S(a.person_id)] = {
      name: S(a.name),
      role: S(a.role),
      kind: S(a.kind) || "cast",
      sort: I(a.sort) || 100
    };
    return d;
  }),
  attendance_list: async (a) => {
    const day = D(a.day);
    if (!day) return [];
    return asRows(
      (await readDoc(`attendance/${day}`)).data,
      (k, v) => ({
        day,
        person_id: k,
        status: v.status || "present",
        note: v.note || "",
        updated_by: v.by || ""
      })
    );
  },
  attendance_set: async (a) => {
    const day = D(a.day);
    if (!day) return false;
    return mutate(`attendance/${day}`, (d) => {
      d[S(a.person_id)] = { status: S(a.status) || "present", note: S(a.note), by: S(a.by) };
      return d;
    });
  },
  notes_list: async (a) => {
    const day = D(a.day);
    if (!day) return [];
    return asRows(
      (await readDoc(`notes/${day}`)).data,
      (k, v) => ({
        note_id: k,
        day,
        dept: v.dept || "general",
        body: v.body || "",
        author: v.author || "",
        created_at: v.created_at || null
      })
    ).sort((x, y) => String(x.created_at).localeCompare(String(y.created_at)));
  },
  note_add: async (a) => {
    const day = D(a.day);
    if (!day) return false;
    return mutate(`notes/${day}`, (d) => {
      d[S(a.note_id)] = {
        dept: S(a.dept) || "general",
        body: S(a.body),
        author: S(a.author),
        created_at: (/* @__PURE__ */ new Date()).toISOString()
      };
      return d;
    });
  },
  // The note id carries its own day, so the document can be found without
  // the client having to send it again.
  note_delete: async (a) => {
    const id = S(a.note_id), day = D(id.split("|")[0]);
    if (!day) return false;
    return mutate(`notes/${day}`, (d) => {
      delete d[id];
      return d;
    });
  },
  // Strike: one row per job, with whose name is against it. Shared, because
  // the whole point is that everyone is looking at the same list on the night.
  strike_list: async () => asRows(
    (await readDoc("strike")).data,
    (k, v) => ({
      task_id: k,
      area: v.area || "set",
      body: v.body || "",
      who: v.who || "",
      done: !!v.done,
      done_by: v.done_by || "",
      sort: v.sort == null ? 0 : v.sort
    })
  ).sort((x, y) => x.sort - y.sort || x.task_id.localeCompare(y.task_id)),
  strike_set: async (a) => mutate("strike", (d) => {
    d[S(a.task_id)] = {
      area: S(a.area) || "set",
      body: S(a.body),
      who: S(a.who),
      done: B(a.done),
      done_by: S(a.done_by),
      sort: I(a.sort)
    };
    return d;
  }),
  strike_delete: async (a) => mutate("strike", (d) => {
    delete d[S(a.task_id)];
    return d;
  }),
  reports_list: async () => asRows(
    (await readDoc("reports")).data,
    (k, v) => ({ day: k, sent_at: v.at || null, sent_by: v.by || "", sent_to: v.to || "" })
  ),
  report_log: async (a) => {
    const day = D(a.day);
    if (!day) return false;
    return mutate("reports", (d) => {
      d[day] = { at: (/* @__PURE__ */ new Date()).toISOString(), by: S(a.by), to: S(a.to) };
      return d;
    });
  }
};
var RPC = {
  progress_list: ["deh_progress_list", () => ({})],
  progress_set: ["deh_progress_set", (a) => ({ p_block_id: S(a.block_id), p_done: B(a.done), p_by: S(a.by) })],
  items_list: ["deh_items_list", () => ({})],
  item_set: ["deh_item_set", (a) => {
    const l = URLS(a.links, a.link);
    return { p_item_id: S(a.item_id), p_status: S(a.status), p_vendor: S(a.vendor), p_link: l.length ? l[0].u : "", p_links: JSON.stringify(l), p_price_cents: I(a.price_cents), p_qty: I(a.qty) || 1, p_sent_at: S(a.sent_at) || null, p_sent_by: S(a.sent_by), p_by: S(a.by) };
  }],
  roster_list: ["deh_roster_list", () => ({})],
  roster_set: ["deh_roster_set", (a) => ({ p_person_id: S(a.person_id), p_name: S(a.name), p_role: S(a.role), p_kind: S(a.kind) || "cast", p_sort: I(a.sort) || 100, p_active: a.active !== false })],
  attendance_list: ["deh_attendance_list", (a) => ({ p_day: D(a.day) })],
  attendance_set: ["deh_attendance_set", (a) => ({ p_day: D(a.day), p_person_id: S(a.person_id), p_status: S(a.status) || "present", p_note: S(a.note), p_by: S(a.by) })],
  notes_list: ["deh_notes_list", (a) => ({ p_day: D(a.day) })],
  note_add: ["deh_note_add", (a) => ({ p_note_id: S(a.note_id), p_day: D(a.day), p_dept: S(a.dept) || "general", p_body: S(a.body), p_author: S(a.author) })],
  note_delete: ["deh_note_delete", (a) => ({ p_note_id: S(a.note_id) })],
  strike_list: ["deh_strike_list", () => ({})],
  strike_set: ["deh_strike_set", (a) => ({ p_task_id: S(a.task_id), p_area: S(a.area) || "set", p_body: S(a.body), p_who: S(a.who), p_done: B(a.done), p_done_by: S(a.done_by), p_sort: I(a.sort) })],
  strike_delete: ["deh_strike_delete", (a) => ({ p_task_id: S(a.task_id) })],
  reports_list: ["deh_reports_list", () => ({})],
  report_log: ["deh_report_log", (a) => ({ p_day: D(a.day), p_by: S(a.by), p_to: S(a.to), p_summary: a.summary && typeof a.summary === "object" ? a.summary : {} })]
};
async function viaSupabase(op, args) {
  const [fn, build] = RPC[op];
  const res = await fetch(`${SB_URL}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: SB_KEY, Authorization: `Bearer ${SB_KEY}` },
    body: JSON.stringify(build(args))
  });
  if (!res.ok) throw new Error(`db-${res.status}`);
  const t = await res.text();
  try {
    return t ? JSON.parse(t) : null;
  } catch {
    return null;
  }
}
function wordOk(given) {
  const a = String(given || "").trim().toLowerCase();
  const b = String(GATE).trim().toLowerCase();
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
var PORTAL_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
async function budgetGet() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) return null;
  const H = { apikey: key, Authorization: `Bearer ${key}`, "Accept-Profile": "staff_portal" };
  const pr = await fetch(`${PORTAL_URL}/rest/v1/productions?title=eq.${encodeURIComponent("Sweeney Todd: School Edition")}&select=id`, { headers: H });
  if (!pr.ok) return null;
  const prods = await pr.json();
  if (!prods.length) return null;
  const lr = await fetch(`${PORTAL_URL}/rest/v1/show_budget_lines?production_id=eq.${prods[0].id}&kind=eq.expense&select=section,budget_amount`, { headers: H });
  if (!lr.ok) return null;
  const lines = await lr.json();
  const MAP = { SETS: "set", PROPS: "prop", COSTUMES: "costume" };
  const out = { set: 0, prop: 0, costume: 0 };
  for (const l of lines) {
    const k = MAP[String(l.section || "").toUpperCase()];
    const n = Number(l.budget_amount);
    if (k && Number.isFinite(n)) out[k] += Math.round(n * 100);
  }
  return out.set || out.prop || out.costume ? out : null;
}
var sweeney_db_default = async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  let body;
  try {
    body = await req.json();
  } catch {
    return new Response("Bad JSON", { status: 400 });
  }
  if (!wordOk(body.word)) return Response.json({ ok: false, error: "not-authorised" }, { status: 403 });
  if (body.op === "budget_get") {
    try {
      return Response.json({ ok: true, data: await budgetGet() });
    } catch {
      return Response.json({ ok: true, data: null });
    }
  }
  if (!BLOBS[body.op]) return Response.json({ ok: false, error: "unknown-op" }, { status: 400 });
  try {
    const data = USE_SUPABASE ? await viaSupabase(body.op, body.args || {}) : await BLOBS[body.op](body.args || {});
    return Response.json({ ok: true, data, store: USE_SUPABASE ? "supabase" : "blobs" });
  } catch (e) {
    return Response.json(
      { ok: false, error: String(e && e.message || "store-error").slice(0, 80) },
      { status: 502 }
    );
  }
};
var config = { path: "/api/sweeney-db" };
export {
  config,
  sweeney_db_default as default
};
