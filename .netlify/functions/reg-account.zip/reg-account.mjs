
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reg-config.mjs
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;
var SHOWS = {
  httyd: "How to Train Your Dragon JR.",
  charlie: "Charlie and the Chocolate Factory JR.",
  trolls: "Trolls The Musical JR."
};
var CAMP_START = {
  httyd: "2027-07-05",
  charlie: "2027-07-19",
  trolls: "2027-08-02"
};

// netlify/functions/reg-account.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
async function svc(path) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: { apikey: key, Authorization: `Bearer ${key}` }
  });
  if (!r.ok) throw new Error(`db ${r.status}`);
  return r.json();
}
async function svcPatch(path, body) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method: "PATCH",
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      Prefer: "return=representation"
    },
    body: JSON.stringify(body)
  });
  if (!r.ok) throw new Error(`db ${r.status}`);
  return r.json();
}
async function paymentsFor(email) {
  const key = process.env.STRIPE_READ_KEY;
  if (!key) return null;
  const stripe = async (path) => {
    const r = await fetch(`https://api.stripe.com/v1/${path}`, {
      headers: { Authorization: `Bearer ${key}` }
    });
    if (!r.ok) throw new Error(`stripe ${r.status} ${path.split("?")[0]}`);
    return r.json();
  };
  try {
    const search = await stripe(
      `customers/search?query=${encodeURIComponent(`email:'${email.replace(/'/g, "")}'`)}&limit=5`
    );
    const customers = search.data || [];
    const upcoming = [], history = [];
    const pretty = (d) => d && /payment plan/i.test(d) ? "Payment plan" : d;
    const invDesc = {};
    const descOf = async (invId) => {
      if (!invId) return null;
      if (!(invId in invDesc)) {
        try {
          const inv = await stripe(`invoices/${invId}`);
          invDesc[invId] = pretty((inv.lines?.data?.[0]?.description || "").replace(/^1 × /, "").replace(/\s*\(at .*\)$/, "")) || null;
        } catch (e) {
          invDesc[invId] = null;
        }
      }
      return invDesc[invId];
    };
    for (const c of customers) {
      const subs = await stripe(`subscriptions?customer=${c.id}&status=active&limit=10`);
      for (const s of subs.data || []) {
        const itemList = s.items?.data || [];
        const nextTs = itemList[0]?.current_period_end || s.current_period_end;
        if (!nextTs) continue;
        if (s.cancel_at && s.cancel_at <= nextTs) continue;
        const amount = itemList.reduce((n, x) => n + (x.price?.unit_amount || 0) * (x.quantity || 1), 0);
        const desc = await descOf(s.latest_invoice) || s.description || "Payment plan";
        if (s.cancel_at) {
          let d = new Date(nextTs * 1e3);
          for (let i = 0; d.getTime() < s.cancel_at * 1e3 && i < 24; i++) {
            upcoming.push({ date: d.getTime(), amount_cents: amount, desc, ends: s.cancel_at * 1e3 });
            d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes()));
          }
        } else if (s.schedule) {
          let listed = false;
          try {
            const sch = await stripe(`subscription_schedules/${s.schedule}`);
            const phases = (sch.phases || []).filter((p) => p.end_date);
            if (sch.end_behavior === "cancel" && phases.length) {
              const endAll = phases[phases.length - 1].end_date;
              const amtCache = {
                price_1U6CmTGWP2ZbtaszBGFK2QN0: 5650,
                price_1U6CmTGWP2ZbtaszDlvrhumq: 20434,
                // Surla TC restructure (Aug 21): Sep 1 $201.85, Oct-Feb $201.83
                price_1U6zSwGWP2ZbtaszOukbSGyT: 20185,
                price_1U6zSwGWP2ZbtaszHBcqIreW: 20183
              };
              let d = new Date(nextTs * 1e3);
              for (let i = 0; d.getTime() / 1e3 + 43200 < endAll && i < 24; i++) {
                const t = d.getTime() / 1e3, probe = t + 43200;
                const ph = phases.find((p) => probe >= p.start_date && probe < p.end_date) || phases[phases.length - 1];
                const pid = ph.items?.[0]?.price;
                if (pid && !(pid in amtCache)) {
                  try {
                    amtCache[pid] = (await stripe(`prices/${pid}`)).unit_amount;
                  } catch (e) {
                    amtCache[pid] = amount;
                  }
                }
                upcoming.push({ date: d.getTime(), amount_cents: pid && amtCache[pid] || amount, desc, ends: endAll * 1e3 });
                listed = true;
                d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), d.getUTCHours(), d.getUTCMinutes()));
              }
            }
          } catch (e) {
          }
          if (!listed) upcoming.push({ date: nextTs * 1e3, amount_cents: amount, desc, ends: null, renews: true });
        } else {
          upcoming.push({ date: nextTs * 1e3, amount_cents: amount, desc, ends: null, renews: true });
        }
      }
      const invoices = await stripe(`invoices?customer=${c.id}&status=paid&limit=10`);
      for (const inv of invoices.data || []) {
        invDesc[inv.id] = pretty((inv.lines?.data?.[0]?.description || "").replace(/^1 × /, "").replace(/\s*\(at .*\)$/, "")) || null;
        history.push({
          date: (inv.status_transitions?.paid_at || inv.created) * 1e3,
          amount_cents: inv.amount_paid,
          desc: invDesc[inv.id] || "Payment plan",
          last4: null,
          _inv: true
        });
      }
      const charges = await stripe(`charges?customer=${c.id}&limit=10`);
      for (const ch of charges.data || []) {
        if (ch.status !== "succeeded" || ch.refunded) continue;
        const twin = history.find((h) => h._inv && h.amount_cents === ch.amount && Math.abs(h.date - ch.created * 1e3) < 36e5);
        if (twin) {
          twin.last4 = ch.payment_method_details?.card?.last4 || null;
          continue;
        }
        history.push({
          date: ch.created * 1e3,
          amount_cents: ch.amount,
          desc: ch.description || ch.calculated_statement_descriptor || "Payment",
          last4: ch.payment_method_details?.card?.last4 || null
        });
      }
    }
    for (const h of history) delete h._inv;
    upcoming.sort((a, b) => a.date - b.date);
    history.sort((a, b) => b.date - a.date);
    return { upcoming, history: history.slice(0, 12) };
  } catch (e) {
    console.error("reg-account payments", e.message);
    return null;
  }
}
async function rewardsFor(email) {
  const enc = encodeURIComponent(email);
  const rows = await svc(
    `referral_rewards?select=*&status=eq.earned&or=(referrer_email.ilike.${enc},referred_email.ilike.${enc})&order=created_at.desc`
  );
  const others = [...new Set(rows.map(
    (r) => r.referrer_email.toLowerCase() === email ? r.referred_email : r.referrer_email
  ))];
  const fams = others.length ? await svc(`families?select=email,parent_name&email=in.(${others.map(encodeURIComponent).join(",")})`) : [];
  const nameOf = Object.fromEntries(fams.map((f) => [f.email.toLowerCase(), f.parent_name]));
  return rows.map((r) => {
    const side = r.referrer_email.toLowerCase() === email ? "referrer" : "referred";
    const other = side === "referrer" ? r.referred_email : r.referrer_email;
    return {
      id: r.id,
      side,
      other_name: nameOf[other.toLowerCase()] || other,
      redeemed_at: side === "referrer" ? r.referrer_redeemed_at : r.referred_redeemed_at,
      created_at: r.created_at
    };
  });
}
async function ticketsFor(email) {
  try {
    const orders = await svc(
      `tix_orders?select=id,code,total_cents,created_at,performance_id,tix_performances(starts_at,label,tix_shows(title)),tix_tickets(seat_id,tix_seats(section,row_label,seat_no))&email=eq.${encodeURIComponent(email.toLowerCase())}&status=eq.paid&order=created_at.desc`
    );
    return (orders || []).map((o) => ({
      code: o.code,
      show: o.tix_performances?.tix_shows?.title || "Performance",
      starts_at: o.tix_performances?.starts_at || null,
      seats: (o.tix_tickets || []).map((t) => `${t.tix_seats.section === "HL" ? "L" : "R"} ${t.tix_seats.row_label}${t.tix_seats.seat_no}`)
    }));
  } catch (e) {
    console.error("ticketsFor:", e.message);
    return [];
  }
}
var fmtDate = (iso) => {
  const [y, m, d] = iso.split("-").map(Number);
  const MO = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${MO[m - 1]} ${d}, ${y}`;
};
var MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
function isPast(text) {
  if (!text) return false;
  let max = null;
  for (const m of text.matchAll(/([A-Za-z]{3,9})\.?,? (\d{1,2}),? (\d{4})/g)) {
    const mo = MONTHS[m[1].slice(0, 3).toLowerCase()];
    if (mo == null) continue;
    const d = new Date(Date.UTC(+m[3], mo, +m[2]));
    if (!max || d > max) max = d;
  }
  for (const m of text.matchAll(/(\d{1,2})\/(\d{1,2})\/(\d{4})/g)) {
    const d = new Date(Date.UTC(+m[3], +m[1] - 1, +m[2]));
    if (!max || d > max) max = d;
  }
  return max ? max < /* @__PURE__ */ new Date() : false;
}
var reg_account_default = async (req) => {
  if (req.method !== "POST") return new Response("POST only", { status: 405 });
  let email = "";
  let body = {};
  try {
    body = await req.json();
  } catch {
  }
  if (body.action === "probe") {
    const probeEmail = String(body.email || "").trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(probeEmail))
      return Response.json({ error: "bad email" }, { status: 400 });
    try {
      const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/auth_probe`, {
        method: "POST",
        headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({ p_email: probeEmail })
      });
      if (!r.ok) throw new Error(`probe ${r.status}`);
      return Response.json(await r.json());
    } catch (e) {
      console.error("reg-account probe", e);
      return Response.json({ error: "server error" }, { status: 500 });
    }
  }
  if (body.portal_token && /^[0-9a-f-]{36}$/.test(body.portal_token)) {
    const fams = await svc(`families?select=email&portal_token=eq.${body.portal_token}&limit=1`);
    email = (fams[0]?.email || "").toLowerCase();
    if (!email) return Response.json({ error: "link not recognized" }, { status: 401 });
  } else {
    const token = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
    if (!token) return Response.json({ error: "sign in required" }, { status: 401 });
    const who = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { apikey: ANON_KEY, Authorization: `Bearer ${token}` }
    });
    if (!who.ok) return Response.json({ error: "sign in required" }, { status: 401 });
    email = ((await who.json()).email || "").toLowerCase();
    if (!email) return Response.json({ error: "sign in required" }, { status: 401 });
  }
  if (body.action === "redeem_referral") {
    const id = String(body.reward_id || "");
    if (!/^[0-9a-f-]{36}$/.test(id)) return Response.json({ error: "bad reward" }, { status: 400 });
    try {
      const rw = (await svc(`referral_rewards?select=*&id=eq.${id}&limit=1`))[0];
      if (!rw) return Response.json({ error: "reward not found" }, { status: 404 });
      const side = rw.referrer_email.toLowerCase() === email ? "referrer" : rw.referred_email.toLowerCase() === email ? "referred" : null;
      if (!side) return Response.json({ error: "not your reward" }, { status: 403 });
      const col = side === "referrer" ? "referrer_redeemed_at" : "referred_redeemed_at";
      if (rw[col]) return Response.json({ error: "already redeemed" }, { status: 409 });
      const upd = await svcPatch(
        `referral_rewards?id=eq.${id}&${col}=is.null`,
        { [col]: (/* @__PURE__ */ new Date()).toISOString() }
      );
      if (!upd.length) return Response.json({ error: "already redeemed" }, { status: 409 });
      return Response.json({ ok: true, redeemed_at: upd[0][col] });
    } catch (e) {
      console.error("reg-account redeem", e);
      return Response.json({ error: "server error" }, { status: 500 });
    }
  }
  try {
    const enc = encodeURIComponent(email);
    const famRows = await svc(`families?select=id,parent_name,email,cc_email&or=(email.ilike.${enc},cc_email.ilike.${enc})`);
    const fam = famRows.find((f) => (f.email || "").toLowerCase() === email) || famRows[0] || null;
    const famEmails = [...new Set(
      famRows.flatMap((f) => [f.email, f.cc_email]).filter(Boolean).map((e) => e.toLowerCase()).concat([email])
    )];
    const emailList = famEmails.map(encodeURIComponent).join(",");
    let campers = [];
    if (famRows.length) {
      const all = await svc(`campers?select=name,day_camp_credits,snow_day_credits&family_id=in.(${famRows.map((f) => f.id).join(",")})&order=name`);
      const seen = /* @__PURE__ */ new Set();
      for (const c of all) {
        const k = c.name.trim().toLowerCase();
        if (seen.has(k)) continue;
        seen.add(k);
        campers.push(c);
      }
    }
    const orders = await svc(`orders?select=id&email=in.(${emailList})&status=in.(paid,confirmed,complete,succeeded)`);
    let items = [];
    if (orders.length) {
      const ids = orders.map((o) => o.id).join(",");
      items = await svc(`order_items?select=show,band,camper_name,activity_id&order_id=in.(${ids})`);
    }
    const actIds = [...new Set(items.map((i) => i.activity_id).filter(Boolean))];
    const acts = actIds.length ? await svc(`activities?select=id,name&id=in.(${actIds.join(",")})`) : [];
    const actName = Object.fromEntries(acts.map((a) => [a.id, a.name]));
    const names = campers.map((c) => `"${c.name.replace(/"/g, "")}"`);
    const orClauses = [`email.in.(${emailList})`];
    if (names.length) orClauses.push(`camper_name.in.(${names.join(",")})`);
    const legacy = await svc(`legacy_enrollments?select=camper_name,activity_text,dates&or=(${orClauses.join(",")})`);
    const byCamper = {};
    const add = (camper, title, dates) => {
      const key = camper || "Your family";
      byCamper[key] = byCamper[key] || [];
      if (!byCamper[key].some((x) => x.title === title))
        byCamper[key].push({ title, dates: dates || "", past: isPast(dates) });
    };
    for (const it of items) {
      if (it.show) {
        const title = `${SHOWS[it.show] || it.show}${it.band && it.band !== "tech" ? ` (Ages ${it.band})` : it.band === "tech" ? " (Tech Crew)" : ""}`;
        add(it.camper_name, title, CAMP_START[it.show] ? `Starts ${fmtDate(CAMP_START[it.show])}` : "");
      } else if (it.activity_id && actName[it.activity_id]) {
        add(it.camper_name, actName[it.activity_id], "");
      }
    }
    for (const le of legacy) add(le.camper_name, le.activity_text, le.dates);
    const credits = campers.map((c) => ({ name: c.name, day: c.day_camp_credits || 0, snow: c.snow_day_credits || 0 })).filter((c) => c.day > 0 || c.snow > 0);
    let dayCamps = [];
    if (credits.length) {
      const rows = await svc(
        `activities?select=id,name,price_cents,capacity,sold,booked_offline&active=is.true&bookable=is.true&hidden=is.false&name=ilike.*day camp*&order=name`
      );
      dayCamps = rows.map((a) => ({
        id: a.id,
        name: a.name,
        remaining: a.capacity == null ? null : Math.max(0, a.capacity - (a.sold || 0) - (a.booked_offline || 0)),
        // "Ages 5–9 Day Camp · Mar 22, 2027" -> the date half, for sorting
        when: (a.name.split("\xB7")[1] || "").trim()
      })).filter((a) => a.remaining === null || a.remaining > 0).sort((a, b) => (Date.parse(a.when) || 0) - (Date.parse(b.when) || 0));
    }
    return Response.json({
      family: fam ? { parent_name: fam.parent_name, email: fam.email } : { email },
      campers: Object.entries(byCamper).map(([name, its]) => ({ name, items: its })),
      rewards: await rewardsFor(email),
      tickets: await ticketsFor(email),
      credits,
      dayCamps,
      payments: await paymentsFor(email)
    });
  } catch (e) {
    console.error("reg-account", e);
    return Response.json({ error: "server error" }, { status: 500 });
  }
};
var config = { path: "/api/reg-account" };
export {
  config,
  reg_account_default as default
};
