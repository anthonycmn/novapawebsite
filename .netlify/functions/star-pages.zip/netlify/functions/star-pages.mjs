
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/star-pages.mjs
import Stripe from "stripe";

// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/star-pages.mjs
var SHOW = "deh";
var PRICES = { full: 15e3, half: 9e3, quarter: 6e3 };
var SIZE_LABEL = { full: "Full Page", half: "Half Page", quarter: "Quarter Page" };
var SITE = "https://www.northernvirginiaperformingarts.org";
var MAX_MESSAGE = 600;
function svc(extra = {}) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return { apikey: key, Authorization: `Bearer ${key}`, ...extra };
}
async function db(path, init = {}) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { ...init, headers: svc({ "Content-Type": "application/json", ...init.headers || {} }) });
  const t = await r.text();
  if (!r.ok) throw new Error(`${r.status} ${t.slice(0, 200)}`);
  try {
    return JSON.parse(t);
  } catch {
    return null;
  }
}
var json = (status, body) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
async function handler(req) {
  if (req.method !== "POST") return json(405, { error: "POST only" });
  let body;
  try {
    body = await req.json();
  } catch {
    return json(400, { error: "bad json" });
  }
  const email = String(body.email || "").trim().toLowerCase();
  try {
    if (body.action === "upload_url") {
      const clean = String(body.filename || "photo.jpg").replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
      const path = `${SHOW}/${crypto.randomUUID()}-${clean}`;
      const r = await fetch(`${SUPABASE_URL}/storage/v1/object/upload/sign/star-pages/${path}`, {
        method: "POST",
        headers: svc({ "Content-Type": "application/json" }),
        body: "{}"
      });
      const t = await r.json();
      if (!r.ok || !t.url) return json(500, { error: "upload url failed" });
      return json(200, { path, url: `${SUPABASE_URL}/storage/v1${t.url}` });
    }
    if (body.action === "create_order") {
      if (!email || email.indexOf("@") < 0) return json(400, { error: "valid email required" });
      const size = String(body.size || "");
      if (!PRICES[size]) return json(400, { error: "bad size" });
      const performer = String(body.performer || "").trim().slice(0, 120);
      const message = String(body.message || "").trim().slice(0, MAX_MESSAGE);
      if (!performer || !message) return json(400, { error: "performer and message required" });
      if (!body.photo_path) return json(400, { error: "photo required" });
      const [row] = await db("star_page_ads", {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify({
          show: SHOW,
          family_email: email,
          performer_name: performer,
          message,
          photo_path: String(body.photo_path),
          size,
          amount_cents: PRICES[size]
        })
      });
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      const session = await stripe.checkout.sessions.create({
        mode: "payment",
        customer_email: email,
        line_items: [{
          quantity: 1,
          price_data: {
            currency: "usd",
            unit_amount: PRICES[size],
            product_data: {
              name: `Star Page Ad \u2014 ${SIZE_LABEL[size]}`,
              description: `Dear Evan Hansen playbill \xB7 for ${performer}`
            }
          }
        }],
        metadata: { star_id: row.id, show: SHOW },
        success_url: `${SITE}/star-pages?done=1&sid={CHECKOUT_SESSION_ID}`,
        cancel_url: `${SITE}/star-pages?canceled=1`
      });
      await db(`star_page_ads?id=eq.${row.id}`, { method: "PATCH", body: JSON.stringify({ stripe_session: session.id }) });
      return json(200, { url: session.url });
    }
    if (body.action === "verify") {
      const sid = String(body.session_id || "");
      if (!sid) return json(400, { error: "session_id required" });
      const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
      const session = await stripe.checkout.sessions.retrieve(sid);
      const paid = session && session.payment_status === "paid";
      if (paid && session.metadata && session.metadata.star_id) {
        await db(`star_page_ads?id=eq.${session.metadata.star_id}&status=eq.pending`, {
          method: "PATCH",
          body: JSON.stringify({ status: "paid" })
        });
        const [row] = await db(`star_page_ads?id=eq.${session.metadata.star_id}&select=performer_name,size`);
        return json(200, { paid: true, performer: row?.performer_name, size: SIZE_LABEL[row?.size] || row?.size });
      }
      return json(200, { paid: false });
    }
    if (body.action === "admin_list") {
      const auth = req.headers.get("authorization") || "";
      const userToken = auth.replace(/^Bearer\s+/i, "");
      const chk = await fetch(`${SUPABASE_URL}/rest/v1/rpc/is_admin`, {
        method: "POST",
        headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${userToken}`, "Content-Type": "application/json" },
        body: "{}"
      });
      if (!chk.ok || (await chk.text()).trim() !== "true") return json(403, { error: "admins only" });
      const rows = await db("star_page_ads?select=*&order=created_at.desc");
      for (const r of rows) {
        if (!r.photo_path) continue;
        const s = await fetch(`${SUPABASE_URL}/storage/v1/object/sign/star-pages/${r.photo_path}`, {
          method: "POST",
          headers: svc({ "Content-Type": "application/json" }),
          body: JSON.stringify({ expiresIn: 3600 })
        });
        const t = await s.json().catch(() => null);
        r.photo_url = t && t.signedURL ? `${SUPABASE_URL}/storage/v1${t.signedURL}` : null;
      }
      return json(200, { ads: rows });
    }
    return json(400, { error: "unknown action" });
  } catch (e) {
    return json(500, { error: String(e.message || e).slice(0, 200) });
  }
}
var config = { path: "/api/star-pages" };
export {
  config,
  handler as default
};
