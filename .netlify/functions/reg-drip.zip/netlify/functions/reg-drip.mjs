
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/reg-drip.mjs
var SITE = "https://www.northernvirginiaperformingarts.org";
var MAX_SENDS_PER_RUN = 25;
var LINKEXPIRED_EPOCH = Date.parse("2026-07-22T22:00:00Z");
var SHOW_TITLES = {
  httyd: "How to Train Your Dragon JR.",
  charlie: "Charlie and the Chocolate Factory JR.",
  trolls: "Trolls The Musical JR."
};
function svcHeaders() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" };
}
async function svc(path, opts = {}) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, { headers: { ...svcHeaders(), ...opts.headers || {} }, method: opts.method || "GET", body: opts.body });
  if (!r.ok) throw new Error(`db ${path} ${r.status}: ${(await r.text()).slice(0, 200)}`);
  const t = await r.text();
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}
async function svcAll(path) {
  const all = [];
  for (let offset = 0; ; offset += 1e3) {
    const page = await svc(`${path}&limit=1000&offset=${offset}`);
    if (!Array.isArray(page)) break;
    all.push(...page);
    if (page.length < 1e3) break;
  }
  return all;
}
function joinNames(arr) {
  const a = [...new Set(arr.filter(Boolean))];
  if (!a.length) return "";
  if (a.length === 1) return a[0];
  return a.slice(0, -1).join(", ") + " and " + a[a.length - 1];
}
function firstName(s) {
  return String(s || "").trim().split(/\s+/)[0] || "";
}
function render(tpl, vars) {
  return tpl.replace(/\{(\w+)\}/g, (m, k) => vars[k] != null ? vars[k] : m);
}
async function sendMail({ to, subject, html, refs }) {
  const { default: nodemailer } = await import("nodemailer");
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  const headers = {};
  if (refs && refs.length) {
    headers["In-Reply-To"] = refs[refs.length - 1];
    headers["References"] = refs.join(" ");
  }
  const info = await transporter.sendMail({
    from: `Jason from Broadway Bound <${process.env.SMTP_USER}>`,
    replyTo: "info@novapa.org",
    to,
    subject,
    headers,
    html: html.replace(/\n/g, "<br>")
  });
  return info.messageId;
}
function normEmail(e) {
  let [local, domain] = String(e || "").toLowerCase().trim().split("@");
  if (!domain) return String(e || "").toLowerCase().trim();
  local = local.split("+")[0];
  if (domain === "googlemail.com") domain = "gmail.com";
  if (domain === "gmail.com") local = local.replace(/\./g, "");
  return local + "@" + domain;
}
async function stopRepliers(states) {
  const active = states.filter((s) => s.status === "active");
  if (!active.length) return 0;
  const senders = /* @__PURE__ */ new Set();
  const referenced = /* @__PURE__ */ new Set();
  try {
    const { ImapFlow } = await import("imapflow");
    const client = new ImapFlow({
      host: "imap.gmail.com",
      port: 993,
      secure: true,
      auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      logger: false
    });
    await client.connect();
    const lock = await client.getMailboxLock("INBOX");
    try {
      const since = new Date(Date.now() - 5 * 24 * 3600 * 1e3);
      for await (const msg of client.fetch({ since }, { envelope: true, headers: ["references", "in-reply-to"] })) {
        for (const a of msg.envelope?.from || []) senders.add(normEmail(a.address));
        if (msg.envelope?.inReplyTo) referenced.add(msg.envelope.inReplyTo.trim());
        const h = msg.headers ? msg.headers.toString() : "";
        for (const id of h.match(/<[^<>\s]+>/g) || []) referenced.add(id);
      }
    } finally {
      lock.release();
    }
    await client.logout();
  } catch (e) {
    console.error("imap reply check failed:", e.message);
    return 0;
  }
  let stopped = 0;
  for (const s of active) {
    const refs = Array.isArray(s.msg_refs) ? s.msg_refs : [];
    const threadReplied = refs.some((r) => referenced.has(r));
    if (!threadReplied && !senders.has(normEmail(s.email))) continue;
    const rows = await svc(
      `retarget_state?email=eq.${encodeURIComponent(s.email)}&status=eq.active`,
      { method: "PATCH", headers: { Prefer: "return=representation" }, body: JSON.stringify({ status: "stopped" }) }
    );
    if (Array.isArray(rows) && rows.length) {
      stopped++;
      s.status = "stopped";
    }
  }
  return stopped;
}
var reg_drip_default = async () => {
  if (String(process.env.DRIP_ENABLED || "").toLowerCase() !== "on") {
    return new Response("drip disabled", { status: 200 });
  }
  if (process.env.CONTEXT && process.env.CONTEXT !== "production") {
    return new Response("skipped: non-production context", { status: 200 });
  }
  const now = Date.now();
  let steps;
  try {
    steps = await svc("email_sequences?select=*&enabled=eq.true&order=seq,step");
  } catch (e) {
    console.error("sequences missing:", e.message);
    return new Response("no sequences", { status: 200 });
  }
  const stepsBySeq = {};
  for (const s of steps) (stepsBySeq[s.seq] = stepsBySeq[s.seq] || []).push(s);
  const [orders, holds, families, activities, suppressions] = await Promise.all([
    svcAll("orders?select=email,created_at&order=created_at"),
    svc("holds?select=email,items,created_at,expires_at&order=created_at.desc&limit=1000"),
    svcAll("families?select=email,parent_name&order=email"),
    svcAll("activities?select=id,name&order=id"),
    svcAll("email_suppressions?select=email,scope&order=email")
  ]);
  const purchased = new Set(orders.map((o) => String(o.email || "").toLowerCase()));
  const suppressed = new Set(suppressions.map((s) => String(s.email || "").toLowerCase()));
  const actNameById = {};
  for (const a of activities) actNameById[a.id] = a.name || "";
  const prettyActName = (raw) => {
    const n = String(raw || "");
    if (/mean girls/i.test(n)) return "Mean Girls";
    if (/frozen/i.test(n)) return "Frozen";
    if (/mermaid/i.test(n)) return "The Little Mermaid JR.";
    return n.split("|").pop().trim() || n.trim();
  };
  const itemTitle = (it) => it.show ? SHOW_TITLES[it.show] : it.activity_id != null ? prettyActName(actNameById[it.activity_id]) : null;
  const parentByEmail = {};
  for (const f of families) parentByEmail[String(f.email).toLowerCase()] = f.parent_name || "";
  const holdsByEmail = {};
  for (const h of holds) {
    const e = String(h.email || "").toLowerCase();
    (holdsByEmail[e] = holdsByEmail[e] || []).push(h);
  }
  const users = [];
  for (let page = 1; page <= 10; page++) {
    const r = await fetch(`${SUPABASE_URL}/auth/v1/admin/users?page=${page}&per_page=200`, { headers: svcHeaders() });
    if (!r.ok) break;
    const j = await r.json();
    const batch = j.users || j;
    if (!Array.isArray(batch) || !batch.length) break;
    users.push(...batch);
    if (batch.length < 200) break;
  }
  const known = new Set(users.map((u) => String(u.email || "").toLowerCase()));
  for (const h of holds) {
    const e = String(h.email || "").toLowerCase();
    if (e && !known.has(e)) {
      known.add(e);
      users.push({ email: e, last_sign_in_at: h.created_at });
    }
  }
  const states = await svcAll("retarget_state?select=*&order=email");
  const stateByEmail = {};
  for (const s of states) stateByEmail[s.email] = s;
  const log = { enrolled: 0, reset: 0, sent: 0, purchased_out: 0, replied_stop: 0 };
  log.replied_stop = await stopRepliers(states);
  for (const u of users) {
    const email = String(u.email || "").toLowerCase();
    if (!email || !u.last_sign_in_at) continue;
    const signIn = new Date(u.last_sign_in_at).getTime();
    if (now - signIn > 7 * 864e5) continue;
    const st = stateByEmail[email];
    if (suppressed.has(email)) continue;
    if (purchased.has(email)) {
      if (st && st.status === "active") {
        await svc(`retarget_state?email=eq.${encodeURIComponent(email)}`, { method: "PATCH", body: JSON.stringify({ status: "purchased", updated_at: (/* @__PURE__ */ new Date()).toISOString() }) });
        log.purchased_out++;
      }
      continue;
    }
    if (!st) {
      const hs = holdsByEmail[email] || [];
      const items = hs.length ? hs[0].items || [] : [];
      const campTitles = [...new Set(items.map(itemTitle).filter(Boolean))];
      const campers = [...new Set(items.map((it) => firstName(it.camper)).filter(Boolean))];
      const parent = firstName(parentByEmail[email]);
      await svc("retarget_state", {
        method: "POST",
        headers: { Prefer: "resolution=ignore-duplicates" },
        body: JSON.stringify({
          email,
          seq: "abandoned",
          stage: 0,
          status: "active",
          anchor_at: new Date(signIn).toISOString(),
          ctx: { parent, campers, camps: campTitles }
        })
      });
      log.enrolled++;
    } else if (st.status === "active" && st.stage === 0 && signIn > new Date(st.anchor_at).getTime()) {
      await svc(`retarget_state?email=eq.${encodeURIComponent(email)}`, { method: "PATCH", body: JSON.stringify({ anchor_at: new Date(signIn).toISOString(), updated_at: (/* @__PURE__ */ new Date()).toISOString() }) });
      log.reset++;
    }
  }
  const states2 = await svcAll("retarget_state?select=*&status=eq.active&order=email");
  for (const st of states2) {
    if (log.sent >= MAX_SENDS_PER_RUN) break;
    const email = st.email;
    if (suppressed.has(email)) continue;
    if (purchased.has(email)) {
      await svc(`retarget_state?email=eq.${encodeURIComponent(email)}`, { method: "PATCH", body: JSON.stringify({ status: "purchased", updated_at: (/* @__PURE__ */ new Date()).toISOString() }) });
      log.purchased_out++;
      continue;
    }
    const seqSteps = stepsBySeq[st.seq] || [];
    const next = seqSteps.find((s) => s.step === st.stage + 1);
    if (!next) {
      if (st.stage > 0) await svc(`retarget_state?email=eq.${encodeURIComponent(email)}`, { method: "PATCH", body: JSON.stringify({ status: "done", updated_at: (/* @__PURE__ */ new Date()).toISOString() }) });
      continue;
    }
    const base = st.stage === 0 ? new Date(st.anchor_at).getTime() : new Date(st.last_sent_at || st.anchor_at).getTime();
    if (now - base < next.delay_minutes * 6e4) continue;
    if (st.seq === "abandoned") {
      const hs = holdsByEmail[email] || [];
      const active = hs.some((h) => h.expires_at && new Date(h.expires_at).getTime() > now);
      if (active) continue;
    }
    const ctx = st.ctx || {};
    const latestItems = (holdsByEmail[email] || [])[0]?.items || [];
    const liveCamps = [...new Set(latestItems.map(itemTitle).filter(Boolean))];
    const liveCampers = [...new Set(latestItems.map((it) => firstName(it.camper)).filter(Boolean))];
    const campers = liveCampers.length ? liveCampers : ctx.campers || [];
    const camps = liveCamps.length ? liveCamps : ctx.camps && ctx.camps.length ? ctx.camps : ["Summer 2027"];
    const actIds = [...new Set(latestItems.map((it) => it.activity_id).filter((v) => v != null))];
    const entry = actIds.length ? `activity=${actIds.join(",")}` : "go=1";
    const vars = {
      parentName: ctx.parent || "there",
      parentComma: ctx.parent ? " " + ctx.parent : "",
      camperName: campers[0] || "your student",
      camperNames: joinNames(campers) || "your student",
      camp: camps[0],
      campName: camps[0],
      camps: joinNames(camps),
      link: `${SITE}/register/?${entry}&utm_source=retarget&utm_campaign=${st.seq}_${next.step}`
    };
    const claim = await fetch(`${SUPABASE_URL}/rest/v1/retarget_state?email=eq.${encodeURIComponent(email)}&stage=eq.${st.stage}&status=eq.active`, {
      method: "PATCH",
      headers: { ...svcHeaders(), Prefer: "return=representation" },
      body: JSON.stringify({ stage: next.step, updated_at: (/* @__PURE__ */ new Date()).toISOString() })
    });
    let claimedRows = [];
    try {
      claimedRows = await claim.json();
    } catch {
    }
    if (!Array.isArray(claimedRows) || !claimedRows.length) continue;
    try {
      const refs = Array.isArray(st.msg_refs) ? st.msg_refs : [];
      const msgId = await sendMail({
        to: email,
        subject: render(next.subject, vars),
        html: render(next.body, vars),
        refs: next.step > 2 ? refs : []
        // step 3 threads onto step 2
      });
      refs.push(msgId);
      await svc(`retarget_state?email=eq.${encodeURIComponent(email)}`, {
        method: "PATCH",
        body: JSON.stringify({ last_sent_at: (/* @__PURE__ */ new Date()).toISOString(), msg_refs: refs, updated_at: (/* @__PURE__ */ new Date()).toISOString() })
      });
      log.sent++;
    } catch (e) {
      console.error(`send failed ${email} (step claimed, not retried):`, e.message);
    }
  }
  const lxSteps = stepsBySeq["linkexpired"] || [];
  if (lxSteps.length) {
    for (const u of users) {
      if (log.sent >= MAX_SENDS_PER_RUN) break;
      const email = String(u.email || "").toLowerCase();
      if (!email || u.last_sign_in_at) continue;
      if (suppressed.has(email) || purchased.has(email) || stateByEmail[email]) continue;
      const linkStamps = [u.confirmation_sent_at, u.recovery_sent_at, u.email_change_sent_at].filter(Boolean);
      if (!linkStamps.length) continue;
      const lastLink = Math.max(...linkStamps.map((t) => new Date(t).getTime()));
      if (lastLink < LINKEXPIRED_EPOCH) continue;
      if (now - lastLink < lxSteps[0].delay_minutes * 6e4) continue;
      if (now - lastLink > 2 * 864e5) continue;
      const parent = firstName(parentByEmail[email]);
      const vars = {
        parentName: parent || "there",
        parentComma: parent ? " " + parent : "",
        link: `${SITE}/register/?go=1&utm_source=retarget&utm_campaign=linkexpired`
      };
      try {
        const ins = await fetch(`${SUPABASE_URL}/rest/v1/retarget_state`, {
          method: "POST",
          headers: { ...svcHeaders(), Prefer: "resolution=ignore-duplicates,return=representation" },
          body: JSON.stringify({ email, seq: "linkexpired", stage: 1, status: "done", ctx: { parent } })
        });
        let insRows = [];
        try {
          insRows = await ins.json();
        } catch {
        }
        if (!Array.isArray(insRows) || !insRows.length) continue;
        const msgId = await sendMail({ to: email, subject: render(lxSteps[0].subject, vars), html: render(lxSteps[0].body, vars) });
        await svc(`retarget_state?email=eq.${encodeURIComponent(email)}`, {
          method: "PATCH",
          body: JSON.stringify({ last_sent_at: (/* @__PURE__ */ new Date()).toISOString(), msg_refs: [msgId], updated_at: (/* @__PURE__ */ new Date()).toISOString() })
        });
        log.sent++;
      } catch (e) {
        console.error(`linkexpired send failed ${email}:`, e.message);
      }
    }
  }
  console.log("drip:", JSON.stringify(log));
  return new Response(JSON.stringify(log), { status: 200 });
};
var config = { schedule: "*/15 * * * *" };
export {
  config,
  reg_drip_default as default
};
