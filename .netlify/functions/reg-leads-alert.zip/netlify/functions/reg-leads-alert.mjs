
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/reg-leads-alert.mjs
import { getStore } from "@netlify/blobs";

// netlify/functions/reg-lead-email.mjs
var BUCKET = {
  reach: { label: "Reach", bg: "#F4E3E4", fg: "#8A2A31" },
  target: { label: "Target", bg: "#E3EDE5", fg: "#1F5C2E" },
  likely: { label: "Likely", bg: "#E4EAF4", fg: "#26406E" }
};
function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}
function safeUrl(u) {
  const s = String(u || "");
  return /^https?:\/\//i.test(s) ? s : "";
}
function schoolCard(m, i) {
  const b = BUCKET[String(m.bucket || "").toLowerCase()] || null;
  const chip = b ? `<span style="background:${b.bg};color:${b.fg};font:700 11px/1 Helvetica,Arial,sans-serif;padding:4px 9px;border-radius:99px;margin-left:8px;white-space:nowrap">${b.label}</span>` : "";
  const place = [m.city, m.state].filter(Boolean).join(", ");
  const prog = [m.degree, m.major, m.track].filter(Boolean).join(" ");
  const reasons = Array.isArray(m.reasons) ? m.reasons.filter(Boolean) : [];
  const url = safeUrl(m.websiteUrl);
  const flags = [];
  if (m.prescreenRequired) flags.push("Prescreen video required");
  if (m.danceRequired) flags.push("Dance evaluated");
  return `<tr><td style="padding:16px 0;border-bottom:1px solid #E4E7ED">
  <div style="font:700 16px/1.35 Helvetica,Arial,sans-serif;color:#0B1422">
    <span style="color:#B07B1E">${i + 1}.</span> ${esc(m.school)}${chip}</div>
  <div style="font:14px/1.6 Helvetica,Arial,sans-serif;color:#0B1422;margin-top:3px">${esc(prog)}</div>
  ${place ? `<div style="font:13px/1.6 Helvetica,Arial,sans-serif;color:#5B6472">${esc(place)}</div>` : ""}
  ${reasons.length ? `<div style="font:13px/1.7 Helvetica,Arial,sans-serif;color:#5B6472;margin-top:6px">${reasons.map(esc).join(" &middot; ")}</div>` : ""}
  ${flags.length ? `<div style="font:700 12px/1.6 Helvetica,Arial,sans-serif;color:#8A2A31;margin-top:6px">${flags.map(esc).join(" &middot; ")}</div>` : ""}
  ${url ? `<div style="font:13px/1.6 Helvetica,Arial,sans-serif;margin-top:7px"><a href="${esc(url)}" style="color:#26406E">Audition requirements &rarr;</a></div>` : ""}
</td></tr>`;
}
function isTestAddress(email) {
  const e = String(email || "").trim().toLowerCase();
  if (!e || !e.includes("@")) return true;
  if (e.endsWith("@novapa.org") || e.endsWith("@dcunifieds.test")) return true;
  if (e.endsWith("@stacksindustries.com")) return true;
  if (e.includes("+test") || e.includes("+rlstest") || e.includes("rlstest")) return true;
  if (e === "x@x.com") return true;
  return false;
}
function resultsEmail(lead) {
  const matches = (() => {
    if (Array.isArray(lead.matches)) return lead.matches;
    try {
      return JSON.parse(lead.matches || "[]");
    } catch {
      return [];
    }
  })();
  const answers = (() => {
    if (lead.answers && typeof lead.answers === "object") return lead.answers;
    try {
      return JSON.parse(lead.answers || "{}");
    } catch {
      return {};
    }
  })();
  const first = String(lead.name || "").trim().split(/\s+/)[0] || "there";
  const focus = answers.dream === "Acting" ? "acting" : "musical theatre";
  const anyPrescreen = matches.some((m) => m.prescreenRequired);
  const isParent = String(lead.role || "").toLowerCase() === "parent";
  const subject = isParent ? `${first}, the five ${focus} programs we matched` : `${first}, here are your five ${focus} programs`;
  const opener = isParent ? `here are the five programs we matched from the Find Your 5 quiz, so you still have the list next week.` : `here's the list from your Find Your 5 quiz, so you still have it next week.`;
  const html = `<div style="max-width:600px;margin:0 auto;padding:30px 22px;font-family:Helvetica,Arial,sans-serif;color:#0B1422">
<div style="font:700 24px/1.25 Helvetica,Arial,sans-serif;letter-spacing:-0.02em">Your five programs</div>
<div style="font:15px/1.7 Helvetica,Arial,sans-serif;color:#5B6472;margin-top:10px">
Hi ${esc(first)} &mdash; ${opener}
Each one auditions at DC Unifieds, and each links straight to its official audition requirements.</div>

<table style="width:100%;border-collapse:collapse;margin-top:14px">
${matches.map(schoolCard).join("")}
</table>

${anyPrescreen ? `<div style="font:14px/1.7 Helvetica,Arial,sans-serif;color:#0B1422;margin-top:22px;padding:15px 17px;background:#FDF6E7;border-radius:9px">
<b>One thing worth doing early.</b> Most of these want a prescreen video before they'll offer a live audition, and those windows tend to close in the fall &mdash; earlier than families expect, and often before applications feel urgent.
Check each school's requirements page above for this year's exact dates, since they move every cycle.</div>` : ""}

<div style="margin-top:24px;padding:20px;background:#0B1422;border-radius:12px">
<div style="font:700 11px/1 Helvetica,Arial,sans-serif;color:#FFC866;letter-spacing:0.08em">DC UNIFIEDS &middot; OCT 15&ndash;18 &middot; LEESBURG, VA</div>
<div style="font:700 19px/1.3 Helvetica,Arial,sans-serif;color:#fff;margin-top:9px;letter-spacing:-0.01em">
Audition for all five in one weekend.</div>
<div style="font:14px/1.7 Helvetica,Arial,sans-serif;color:rgba(255,255,255,0.75);margin-top:9px">
One registration covers auditions with every college attending, plus workshops and callbacks, in one building &mdash; with application and audition fees waived.</div>
<div style="margin-top:15px">
<a href="https://dcunifieds.com/one-weekend?utm_source=email&utm_medium=lead&utm_campaign=findyour5-results"
   style="display:inline-block;background:#FFC866;color:#0B1422;font:700 15px/1 Helvetica,Arial,sans-serif;padding:13px 26px;border-radius:99px;text-decoration:none">See the weekend</a></div>
</div>

<div style="font:14px/1.7 Helvetica,Arial,sans-serif;color:#5B6472;margin-top:22px">
Questions about any of these programs? Just reply to this email &mdash; a coach will read it.</div>

<div style="font:11.5px/1.9 Helvetica,Arial,sans-serif;color:#9AA1AC;margin-top:26px;border-top:1px solid #E4E7ED;padding-top:14px">
You're getting this because you took the Find Your 5 quiz at findyour5.dcunifieds.com.<br>
Northern Virginia Performing Arts &middot; 18945 Conference Center Drive, Plaza C, Leesburg VA 20176</div>
</div>`;
  return { subject, html };
}

// netlify/functions/reg-leads-alert.mjs
var FROM = "NOVAPA Leads <leads@mail.novapa.org>";
var LEAD_FROM = "DC Unifieds <leads@mail.novapa.org>";
var STORE = "lead-alerts";
var KEY = "dcu-watermark";
var SENT_KEY = "results-emailed";
async function sendMail(resend, payload) {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${resend}`, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  return r.ok;
}
async function emailLeads(store, resend, rows) {
  if (String(process.env.LEAD_RESULTS_EMAIL || "").toLowerCase() !== "on") {
    return { sent: 0, skipped: "disabled" };
  }
  let sentIds = [];
  try {
    sentIds = JSON.parse(await store.get(SENT_KEY) || "[]");
  } catch {
  }
  const already = new Set(sentIds);
  let sent = 0;
  for (const lead of rows) {
    if (already.has(lead.id) || isTestAddress(lead.email)) continue;
    const { subject, html } = resultsEmail(lead);
    const ok = await sendMail(resend, { from: LEAD_FROM, to: [lead.email], subject, html });
    if (ok) {
      already.add(lead.id);
      sent++;
    }
  }
  await store.set(SENT_KEY, JSON.stringify([...already].slice(-2e3)));
  return { sent };
}
function esc2(s) {
  return String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}
function card(x) {
  const a = (() => {
    try {
      return JSON.parse(x.answers || "{}");
    } catch {
      return {};
    }
  })();
  const m = (() => {
    try {
      return JSON.parse(x.matches || "[]");
    } catch {
      return [];
    }
  })();
  const hot = a.certainty === "locked" && a.prescreen === "filmed";
  const pill = hot ? '<span style="background:#1F7A38;color:#fff;font-size:11px;font-weight:700;padding:2px 8px;border-radius:99px;margin-left:8px">HOT</span>' : "";
  return `<tr><td style="padding:16px 0;border-bottom:1px solid #E4E7ED">
<div style="font:700 17px/1.3 Helvetica,Arial,sans-serif;color:#0B1422">${esc2(x.name)}${pill}</div>
<div style="font:14px/1.6 Helvetica,Arial,sans-serif;margin-top:4px">
<a href="mailto:${esc2(x.email)}" style="color:#0B1422">${esc2(x.email)}</a> &middot;
<a href="tel:${esc2(x.phone)}" style="color:#0B1422">${esc2(x.phone)}</a></div>
<div style="font:13px/1.7 Helvetica,Arial,sans-serif;color:#5B6472;margin-top:6px">
${esc2(x.role)} &middot; class of ${esc2(x.grad_year)} &middot; ${esc2(a.homeState || "?")}<br>
Wants <b>${esc2(a.dream || "?")}</b>, ${esc2(a.structure || "?")} &middot; dance ${esc2(a.dance || "?")} &middot; GPA ${esc2(a.gpa || "?")}<br>
Prescreens <b>${esc2(a.prescreen || "?")}</b> &middot; decision <b>${esc2(a.certainty || "?")}</b> &middot; aid ${esc2(a.budget || "?")}</div>
<div style="font:12px/1.6 Helvetica,Arial,sans-serif;color:#5B6472;margin-top:6px">
<b>Top 5:</b> ${esc2(m.map((s) => s.school).filter(Boolean).join(", "))}</div></td></tr>`;
}
var reg_leads_alert_default = async () => {
  const base = process.env.DCU_SUPABASE_URL;
  const key = process.env.DCU_SERVICE_KEY;
  const resend = process.env.RESEND_API_KEY;
  if (!base || !key || !resend) {
    return new Response(JSON.stringify({ skipped: "not_configured" }), { status: 200 });
  }
  const store = getStore(STORE);
  let since = await store.get(KEY);
  if (!since) {
    since = process.env.LEADS_ALERT_SINCE || (/* @__PURE__ */ new Date()).toISOString();
    await store.set(KEY, since);
  }
  const url = `${base}/rest/v1/funnel_leads_ro?select=*&updated_at=gt.${encodeURIComponent(since)}&order=updated_at.asc&limit=50`;
  const r = await fetch(url, {
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Accept-Profile": "leads_api" }
  });
  if (!r.ok) {
    return new Response(JSON.stringify({ error: `${r.status} ${(await r.text()).slice(0, 200)}` }), { status: 200 });
  }
  const rows = await r.json();
  if (!rows.length) return new Response(JSON.stringify({ new: 0 }), { status: 200 });
  const to = (process.env.LEADS_ALERT_TO || "jason@novapa.org").split(",").map((s) => s.trim()).filter(Boolean);
  const hotCount = rows.filter((x) => {
    try {
      const a = JSON.parse(x.answers || "{}");
      return a.certainty === "locked" && a.prescreen === "filmed";
    } catch {
      return false;
    }
  }).length;
  const subject = rows.length === 1 ? `Find Your 5 lead: ${rows[0].name}${hotCount ? " (hot)" : ""}` : `${rows.length} Find Your 5 leads${hotCount ? ` (${hotCount} hot)` : ""}`;
  const html = `<div style="max-width:620px;margin:0 auto;padding:26px 22px;font-family:Helvetica,Arial,sans-serif">
<div style="font:700 21px/1.2 Helvetica,Arial,sans-serif;color:#0B1422;letter-spacing:-0.02em">${esc2(subject)}</div>
<table style="width:100%;border-collapse:collapse;margin-top:10px">${rows.map(card).join("")}</table>
<div style="font:12px/1.6 Helvetica,Arial,sans-serif;color:#5B6472;margin-top:18px">
Full list in the NOVAPA admin dashboard under Leads.</div></div>`;
  const leadRes = await emailLeads(store, resend, rows);
  const ok = await sendMail(resend, { from: FROM, to, subject, html });
  if (!ok) {
    return new Response(JSON.stringify({ error: "resend failed", leads: leadRes }), { status: 200 });
  }
  await store.set(KEY, rows[rows.length - 1].updated_at);
  return new Response(JSON.stringify({ alerted: rows.length, hot: hotCount, leads: leadRes }), { status: 200 });
};
var config = { schedule: "*/15 * * * *" };
export {
  config,
  reg_leads_alert_default as default
};
