
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// netlify/functions/tix-confirm.mjs
var tix_confirm_exports = {};
__export(tix_confirm_exports, {
  confirmTickets: () => confirmTickets
});
async function svcRpc(fn, args) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify(args)
  });
  const t = await r.text();
  if (!r.ok) throw new Error(`${fn} ${r.status}: ${t.slice(0, 250)}`);
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}
async function confirmTickets(pi) {
  const m = pi.metadata || {};
  const res = await svcRpc("tix_confirm", {
    p_hold_id: m.tix_hold_id,
    p_email: m.email || "",
    p_buyer_name: m.buyer_name || null,
    p_total_cents: parseInt(m.total_cents || "0", 10),
    p_stripe_payment_intent: pi.id
  });
  if (!res.duplicate) {
    if (m.reward_id && m.reward_side && m.reward_email) {
      try {
        const col = m.reward_side === "referrer" ? "referrer_redeemed_at" : "referred_redeemed_at";
        const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
        await fetch(`${SUPABASE_URL}/rest/v1/referral_rewards?id=eq.${m.reward_id}&${col}=is.null`, {
          method: "PATCH",
          headers: { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
          body: JSON.stringify({ [col]: (/* @__PURE__ */ new Date()).toISOString() })
        });
      } catch (e) {
        console.error("reward settle failed:", e.message);
      }
    }
    if (m.coupon && parseInt(m.coupon_cents || "0", 10) > 0) {
      try {
        await svcRpc("redeem_coupon", {
          p_code: m.coupon,
          p_applied_cents: parseInt(m.coupon_cents, 10)
        });
      } catch (e) {
        console.error("ticket coupon settle failed:", e.message);
      }
    }
    try {
      await sendTicketEmail(m, res.code);
    } catch (e) {
      console.error("ticket email failed:", e.message);
    }
  }
  return res;
}
async function sendTicketEmail(m, code) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS || !m.email) return;
  const { default: nodemailer } = await import("nodemailer");
  const t = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  const GOLD = "#C8892A";
  const seats = (m.seats || "").split(", ").filter(Boolean);
  const usd = (c) => "$" + ((parseInt(c || "0", 10) || 0) / 100).toFixed(2);
  await t.sendMail({
    from: `NOVAPA Box Office <${process.env.SMTP_USER}>`,
    replyTo: "info@novapa.org",
    to: m.email,
    subject: `Your tickets \u2014 ${m.show_title}, ${m.performance_when}`,
    html: `
<div style="font-family:Georgia,serif;background:#f5f2ec;padding:28px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden">
<tr><td style="background:#0F1E36;padding:24px 28px">
  <div style="color:#fff;font-size:20px;font-weight:700">NOVAPA</div>
  <div style="color:${GOLD};font-size:13px;letter-spacing:.12em;margin-top:4px">BOX OFFICE</div>
</td></tr>
<tr><td style="padding:28px">
  <div style="font-size:12px;letter-spacing:.14em;color:#888">THIS IS YOUR TICKET</div>
  <div style="font-size:22px;font-weight:700;color:#1a1a1a;margin-top:6px">${m.show_title}</div>
  <div style="font-size:15px;color:#444;margin-top:4px">${m.performance_when} \xB7 Loudoun Auditorium</div>
  <div style="font-size:13.5px;color:#666;margin-top:6px">Show this email at the door. No printing needed.</div>
  <div style="margin:22px 0;padding:18px;background:#f8f5ef;border-radius:10px;text-align:center">
    <div style="font-size:12px;letter-spacing:.14em;color:#888">ORDER CODE</div>
    <div style="font-size:32px;font-weight:800;letter-spacing:.18em;color:#0F1E36;margin-top:4px">${code}</div>
    <div style="font-size:12.5px;color:#666;margin-top:6px">Give this code and your name at the door.</div>
  </div>
  <div style="font-size:12px;letter-spacing:.1em;color:#888;margin-bottom:6px">YOUR SEATS (${seats.length})</div>
  ${seats.map((s) => `<div style="padding:8px 0;border-bottom:1px solid #eee;font-size:15px;color:#1a1a1a">${s}</div>`).join("")}
  ${m.reward_cents ? `<div style="padding:8px 0;font-size:14px;color:#2e7d4f">Referral reward \u2014 2 free tickets: \u2212${usd(m.reward_cents)}</div>` : ""}
  ${m.coupon_cents ? `<div style="padding:8px 0;font-size:14px;color:#2e7d4f">Credit ${m.coupon || ""}: \u2212${usd(m.coupon_cents)}</div>` : ""}
  <div style="padding:12px 0;font-size:15px"><b>Total paid: ${usd(m.total_cents)}</b></div>
  <p style="font-size:13px;color:#666;line-height:1.6;margin-top:16px">
    The auditorium is between the ballroom and the hotel lobby at the Northern Virginia Conference Center,
    18980 West Belmont Place, Leesburg. Park in the garage. House opens 15 minutes before curtain.
    All sales are final; tickets are non-refundable and non-transferable.</p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="margin:18px auto 0"><tr><td
    style="background:${GOLD};border-radius:8px">
    <a href="https://www.northernvirginiaperformingarts.org/register/account.html"
       style="display:inline-block;padding:12px 26px;color:#fff;text-decoration:none;font-weight:700;font-size:14px">
      View in My NOVAPA</a></td></tr></table>
  <p style="font-size:12px;color:#999;text-align:center;margin-top:8px">
    Your tickets are always available in your account.</p>
</td></tr>
</table></div>`
  });
}
var SUPABASE_URL;
var init_tix_confirm = __esm({
  "netlify/functions/tix-confirm.mjs"() {
    SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
  }
});

// netlify/functions/tix-pay.mjs
import Stripe from "stripe";
var SUPABASE_URL2 = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
function svcHeaders() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" };
}
async function emailFromJwt(req) {
  const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!jwt) return null;
  const r = await fetch(`${SUPABASE_URL2}/auth/v1/user`, {
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${jwt}` }
  });
  if (!r.ok) return null;
  const u = await r.json();
  return (u.email || "").toLowerCase() || null;
}
async function rewardFor(email) {
  const enc = encodeURIComponent(email);
  const rows = await (await fetch(
    `${SUPABASE_URL2}/rest/v1/referral_rewards?select=*&status=eq.earned&or=(referrer_email.ilike.${enc},referred_email.ilike.${enc})&order=created_at`,
    { headers: svcHeaders() }
  )).json();
  for (const r of rows || []) {
    if (r.referrer_email?.toLowerCase() === email && !r.referrer_redeemed_at) {
      return { id: r.id, side: "referrer" };
    }
    if (r.referred_email?.toLowerCase() === email && !r.referred_redeemed_at) {
      return { id: r.id, side: "referred" };
    }
  }
  return null;
}
async function rpc(fn, args) {
  const r = await fetch(`${SUPABASE_URL2}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: svcHeaders(),
    body: JSON.stringify(args)
  });
  const t = await r.text();
  if (!r.ok) throw new Error(`${fn} ${r.status}: ${t.slice(0, 200)}`);
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}
var clean = (v, n) => String(v == null ? "" : v).trim().slice(0, n);
var tix_pay_default = async (req) => {
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return Response.json({ error: "not_configured" }, { status: 503 });
  }
  if (req.method === "GET") {
    const u = new URL(req.url);
    const slug = u.searchParams.get("show");
    const perf2 = parseInt(u.searchParams.get("performance") || "0", 10);
    try {
      if (u.searchParams.get("credits")) {
        const email2 = await emailFromJwt(req);
        if (!email2) return Response.json({ free_tickets: 0 });
        const reward2 = await rewardFor(email2);
        return Response.json({ email: email2, free_tickets: reward2 ? 2 : 0 });
      }
      if (slug) {
        const show = await rpc("tix_show", { p_slug: clean(slug, 60) });
        if (!show) return Response.json({ error: "not_found" }, { status: 404 });
        return Response.json(show);
      }
      if (perf2) return Response.json({ seats: await rpc("tix_seatmap", { p_performance_id: perf2 }) });
    } catch (e) {
      console.error("tix-pay GET:", e.message);
      return Response.json({ error: "server_error" }, { status: 500 });
    }
    return Response.json({ error: "bad_request" }, { status: 400 });
  }
  if (req.method !== "POST") return Response.json({ error: "method_not_allowed" }, { status: 405 });
  if (!process.env.STRIPE_SECRET_KEY) return Response.json({ error: "payments_not_configured" }, { status: 503 });
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "bad_json" }, { status: 400 });
  }
  const performanceId = parseInt(body.performance_id, 10);
  const seatIds = Array.isArray(body.seat_ids) ? body.seat_ids.map(Number).filter(Boolean) : [];
  const email = clean(body.email, 200).toLowerCase();
  const buyerName = clean(body.buyer_name, 100);
  if (!performanceId || !seatIds.length || seatIds.length > 12) {
    return Response.json({ error: "bad_request" }, { status: 400 });
  }
  if (!/^[^@\s]+@[^@\s.]+\.[^@\s]+$/.test(email)) return Response.json({ error: "bad_email" }, { status: 400 });
  if (!buyerName) return Response.json({ error: "missing_name" }, { status: 400 });
  const rows = await (await fetch(
    `${SUPABASE_URL2}/rest/v1/tix_seats?id=in.(${seatIds.join(",")})&select=id,tier,row_label,seat_no,section`,
    { headers: svcHeaders() }
  )).json();
  if (!Array.isArray(rows) || rows.length !== seatIds.length) {
    return Response.json({ error: "unknown_seat" }, { status: 400 });
  }
  const perfRows = await (await fetch(
    `${SUPABASE_URL2}/rest/v1/tix_performances?id=eq.${performanceId}&select=id,status,starts_at,show_id,tix_shows(slug,title,on_sale)`,
    { headers: svcHeaders() }
  )).json();
  const perf = perfRows[0];
  if (!perf || perf.status !== "onsale" || !perf.tix_shows?.on_sale) {
    return Response.json({ error: "not_on_sale" }, { status: 409 });
  }
  const tiers = await (await fetch(
    `${SUPABASE_URL2}/rest/v1/tix_tiers?show_id=eq.${perf.show_id}&select=name,price_cents,fee_cents`,
    { headers: svcHeaders() }
  )).json();
  const tierBy = Object.fromEntries(tiers.map((t) => [t.name, t]));
  const priced = rows.map((s) => {
    const t = tierBy[s.tier];
    if (!t) throw new Error(`no tier ${s.tier}`);
    return {
      cents: t.price_cents + t.fee_cents,
      line: `${s.section === "HL" ? "House Left" : "House Right"} ${s.row_label}${s.seat_no}`
    };
  });
  let total = priced.reduce((n, p) => n + p.cents, 0);
  const listTotal = total;
  const lines = priced.map((p) => p.line);
  let reward = null, rewardCents = 0;
  if (body.apply_reward) {
    const sessionEmail = await emailFromJwt(req);
    if (sessionEmail) reward = await rewardFor(sessionEmail);
    if (reward) {
      const byPrice = [...priced].sort((a, b) => b.cents - a.cents);
      rewardCents = byPrice.slice(0, 2).reduce((n, p) => n + p.cents, 0);
      total -= rewardCents;
      reward.email = sessionEmail;
    }
  }
  const couponCode = clean(body.coupon, 20).toUpperCase();
  let couponCents = 0;
  if (couponCode) {
    const c = await rpc("check_coupon", { p_code: couponCode });
    if (!c || !c.pct && !c.amount_cents) {
      return Response.json({ error: "bad_coupon" }, { status: 400 });
    }
    couponCents = c.pct ? Math.round(total * c.pct / 100) : Math.min(c.amount_cents, total);
    total -= couponCents;
  }
  let hold;
  try {
    hold = await rpc("tix_hold_seats", {
      p_performance_id: performanceId,
      p_seat_ids: seatIds,
      p_email: email
    });
  } catch (e) {
    if (/SEAT_TAKEN/.test(e.message)) return Response.json({ error: "seat_taken" }, { status: 409 });
    console.error("tix hold:", e.message);
    return Response.json({ error: "hold_failed" }, { status: 500 });
  }
  const when = new Date(perf.starts_at).toLocaleString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    timeZone: "America/New_York"
  });
  const creditMeta = {
    list_cents: String(listTotal),
    ...reward ? {
      reward_id: String(reward.id),
      reward_side: reward.side,
      reward_email: reward.email,
      reward_cents: String(rewardCents)
    } : {},
    ...couponCode && couponCents ? { coupon: couponCode, coupon_cents: String(couponCents) } : {}
  };
  if (total === 0) {
    try {
      const { confirmTickets: confirmTickets2 } = await Promise.resolve().then(() => (init_tix_confirm(), tix_confirm_exports));
      const res = await confirmTickets2({
        id: "free_" + hold.hold_id,
        metadata: {
          tix_hold_id: hold.hold_id,
          tix_performance_id: String(performanceId),
          email,
          buyer_name: buyerName,
          total_cents: "0",
          seats: lines.join(", ").slice(0, 480),
          show_title: perf.tix_shows.title.slice(0, 100),
          performance_when: when,
          ...creditMeta
        }
      });
      return Response.json({
        confirmed: true,
        code: res.code,
        pricing: { total_cents: 0, list_cents: listTotal, seats: lines }
      });
    } catch (e) {
      console.error("free ticket order failed:", e.message);
      return Response.json({ error: "confirm_failed" }, { status: 500 });
    }
  }
  if (total < 50) return Response.json({ error: "credit_leaves_tiny_total" }, { status: 400 });
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const pi = await stripe.paymentIntents.create({
    amount: total,
    currency: "usd",
    payment_method_types: ["card", "link"],
    description: `NOVAPA Tickets \u2014 ${perf.tix_shows.title}, ${when}`,
    statement_descriptor_suffix: "NOVAPA TIX",
    metadata: {
      // Branch key for the shared webhook. Nothing else in reg-webhook fires
      // without hold_id + plan, so tix events pass through it inert.
      tix_hold_id: hold.hold_id,
      tix_performance_id: String(performanceId),
      email,
      buyer_name: buyerName,
      total_cents: String(total),
      seats: lines.join(", ").slice(0, 480),
      show_title: perf.tix_shows.title.slice(0, 100),
      performance_when: when,
      ...creditMeta
    }
  });
  return Response.json({
    client_secret: pi.client_secret,
    hold_id: hold.hold_id,
    expires_in: hold.expires_in,
    pricing: {
      total_cents: total,
      list_cents: listTotal,
      reward_cents: rewardCents,
      coupon_cents: couponCents,
      seats: lines
    }
  });
};
var config = { path: "/api/tix-pay" };
export {
  config,
  tix_pay_default as default
};
