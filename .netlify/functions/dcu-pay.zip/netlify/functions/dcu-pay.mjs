
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/dcu-pay.mjs
import Stripe from "stripe";

// netlify/functions/reg-config.mjs
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;

// netlify/functions/reg-email.mjs
var GOLD = "#C8892A";
var NAVY = "#0F1E36";
function money(cents) {
  return "$" + (cents / 100).toLocaleString(
    "en-US",
    { minimumFractionDigits: cents % 100 ? 2 : 0, maximumFractionDigits: 2 }
  );
}
var TEEN_CONS_IDS = [1960809, 1960811, 1805731];
function spansLunch(w) {
  if (!w || !w.time) return false;
  const m = String(w.time).match(/(\d{1,2})(?::(\d{2}))?\s*(am|pm).*?(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i);
  if (!m) return false;
  const h = (hh, ap) => Number(hh) % 12 + (/pm/i.test(ap) ? 12 : 0);
  return h(m[1], m[3]) <= 12 && h(m[4], m[6]) >= 13;
}
var VENUE = "National Conference Center, 18945 Conference Center Drive, Plaza C, Leesburg, VA 20176";
var MAP_URL = "https://maps.google.com/?q=" + encodeURIComponent("18945 Conference Center Drive, Plaza C, Leesburg, VA 20176");
var ARRIVAL = [
  "We are in the South Building at Plaza C. Park in the south parking lot and take the walkway to the entrance.",
  "Parking is free. If you are dropping off and going, drop off at Plaza C.",
  "Pick-up has a fifteen minute grace period, after which a late fee of $15 per fifteen minutes applies. If you are running late, email us rather than letting us wonder.",
  "Email is our official channel for schedule changes, closures, casting and billing. Please check your spam folder and mark us as safe."
];
async function svcJson(path) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key) return [];
  try {
    const r = await fetch(
      `https://tlkuqwsqicxcjdmumkje.supabase.co/rest/v1/${path}`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } }
    );
    return r.ok ? await r.json() : [];
  } catch {
    return [];
  }
}
function whenFrom(classTimes) {
  const t = Array.isArray(classTimes) ? classTimes[0] : null;
  if (!t) return null;
  const day = (t.title_text || "").trim();
  const time = Array.isArray(t.primary_text) ? t.primary_text.join(", ") : t.primary_text || "";
  const span = t.secondary_text || t.product_detail_date || "";
  return { day, time, span };
}
async function itemDetails(m, pi) {
  const piId = pi && pi.id;
  let rows = [];
  if (piId) {
    const orders = await svcJson(`orders?stripe_payment_intent=eq.${encodeURIComponent(piId)}&select=id,order_items(camper_name,show,band,activity_id,unit_price_cents)`);
    rows = orders[0] && orders[0].order_items || [];
    if (orders[0]) m.__order_id = orders[0].id;
  }
  if (!rows.length) return [];
  const ids = [...new Set(rows.map((r) => r.activity_id).filter(Boolean))];
  const acts = ids.length ? await svcJson(`activities?id=in.(${ids.join(",")})&select=id,name,class_times,location,age_range,category,price_cents`) : [];
  const byId = Object.fromEntries(acts.map((a) => [a.id, a]));
  return rows.map((r) => {
    const a = r.activity_id ? byId[r.activity_id] : null;
    const w = a ? whenFrom(a.class_times) : null;
    const summer = !!r.show;
    const price = a ? a.price_cents || 0 : 99500;
    const cat = a ? a.category : "camp";
    return {
      camper: r.camper_name || "Camper",
      name: a ? a.name : r.show ? `${r.show} (ages ${r.band})` : "Program",
      ages: a && a.age_range ? a.age_range : "",
      when: w,
      price: r.unit_price_cents,
      // Day-1 auditions run for every production. Teen Conservatory casts
      // audition months ahead, so Sweeney, Hadestown and Dear Evan Hansen are
      // out — Mean Girls is back on day-1 auditions (Jason, Aug 13).
      production: summer || cat === "camp" && price >= 5e4 && !TEEN_CONS_IDS.includes(a && a.id),
      allDay: summer || spansLunch(w)
    };
  });
}
function confirmationHtml(m, pi, details) {
  const items = (m.order_desc || "").split("; ").filter(Boolean);
  const today = pi.amount_received ?? pi.amount;
  const total = parseInt(m.total_cents || "0", 10) || today;
  const nInst = parseInt(m.n_installments || "0", 10) || 0;
  const instCents = parseInt(m.installment_cents || "0", 10) || 0;
  const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
  const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  let planLine = "Paid in full \u2014 no future charges.";
  if (m.plan === "deposit" && nInst && firstInst) {
    const d = new Date(firstInst * 1e3);
    planLine = `Then ${nInst} monthly payments of ${money(instCents)}, automatic on your card, starting ${months[d.getUTCMonth()]} 1, ${d.getUTCFullYear()} \u2014 fully paid before your program begins.`;
  } else if (m.plan === "subscription") {
    planLine = m.first_month_free === "1" ? "Your first month is on us. Your card is saved, and monthly tuition starts October 1, then the 1st of each month through June 1, 2027. Nothing is charged in September, and nothing is charged after June \u2014 the plan ends itself. Cancel any time with 30 days' notice." : "Today's payment covers your first month, so there is no further charge in September. Monthly tuition then runs October 1 and the 1st of each month through June 1, 2027, and the plan ends itself after that. Cancel any time with 30 days' notice.";
  }
  const esc = (x) => String(x == null ? "" : x).replace(/&/g, "&amp;").replace(/</g, "&lt;");
  const rows = details && details.length ? details.map((d) => `<tr><td style="padding:14px 0;border-bottom:1px solid #eee8dd">
        <div style="font-size:15px;color:#2a2a2a"><b>${esc(d.name)}</b></div>
        <div style="font-size:14px;color:#444;margin-top:3px">Participant: ${esc(d.camper)}${d.ages ? " &nbsp;\xB7&nbsp; ages " + esc(d.ages) : ""}</div>
        ${d.when && (d.when.day || d.when.span) ? `<div style="font-size:14px;color:#444;margin-top:3px">
          ${d.when.day ? "<b>" + esc(d.when.day) + "</b>" : ""}${d.when.time ? " &nbsp;" + esc(d.when.time) : ""}
          ${d.when.span ? "<br>" + esc(d.when.span) : ""}</div>` : ""}
        ${d.price != null ? `<div style="font-size:13.5px;color:#666;margin-top:3px">${money(d.price)}</div>` : ""}
      </td></tr>`).join("") : items.map(
    (it) => `<tr><td style="padding:10px 0;border-bottom:1px solid #eee8dd;font-size:15px;color:#2a2a2a">${it}</td></tr>`
  ).join("");
  const couponRow = m.coupon ? `<tr><td style="padding:6px 0;font-size:14px;color:#2e7d4f">Coupon ${m.coupon}: \u2212${money(parseInt(m.coupon_cents || "0", 10))}</td></tr>` : "";
  return `<!doctype html><html><body style="margin:0;padding:0;background:#f5f2ec;font-family:Georgia,'Times New Roman',serif">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f2ec;padding:28px 12px"><tr><td align="center">
    <table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #e7e0d2">
      <tr><td style="background:${NAVY};padding:26px 32px;text-align:center">
        <div style="font-family:Georgia,serif;font-size:22px;letter-spacing:0.25em;color:#ffffff">NOVA<span style="color:#E8B84B">PA</span></div>
        <div style="font-size:12px;letter-spacing:0.18em;color:#c9b47a;text-transform:uppercase;margin-top:6px">Registration Confirmed</div>
      </td></tr>
      <tr><td style="padding:30px 32px 8px">
        <p style="margin:0 0 16px;font-size:16px;color:#2a2a2a">Hi${m.parent_name ? " " + m.parent_name.split(" ")[0] : ""},</p>
        <p style="margin:0 0 18px;font-size:15px;color:#444;line-height:1.6">You're in! Here's what we have for your family:</p>
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0">${rows}</table>
      </td></tr>
      <tr><td style="padding:14px 32px 6px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf7f0;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            ${couponRow ? '<table role="presentation" width="100%">' + couponRow + "</table>" : ""}
            <div style="font-size:15px;color:#2a2a2a"><b>Paid today: ${money(today)}</b>${total > today ? " &nbsp;\xB7&nbsp; Program total: " + money(total) : ""}</div>
            <div style="font-size:13.5px;color:#666;margin-top:6px;line-height:1.5">${planLine}</div>
          </td></tr>
        </table>
      </td></tr>

      ${details && details.some((d) => d.production) ? `
      <tr><td style="padding:14px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">Auditions are on day one</div>
            <p style="margin:8px 0 0;font-size:14px;color:#2a2a2a;line-height:1.6">
              This is for placement only. <b>Everyone who registered is in the company and everyone is cast.</b>
              Day one decides where your performer fits best.</p>
            <p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">What to bring to the audition:</p>
            <ul style="margin:6px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              <li style="margin:4px 0"><b>A song they are confident singing.</b> Sixteen to thirty-two bars is plenty. Sheet music in a binder, or a backing track on a phone with a way to play it.</li>
              <li style="margin:4px 0"><b>A short monologue</b> if they have one they like. Optional, but it helps us.</li>
              <li style="margin:4px 0">Themselves, warmed up, having slept.</li>
            </ul>
            <p style="margin:10px 0 0;font-size:13.5px;color:#666;line-height:1.6">
              An audition here is not a test anyone can fail. We already want them. We are listening for where their
              voice sits and which room will stretch them most.</p>
          </td></tr>
        </table>
      </td></tr>` : ""}
      <tr><td style="padding:14px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">What to bring and wear</div>
            <ul style="margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              ${details && details.some((d) => d.allDay) ? `<li style="margin:4px 0"><b>A packed lunch and a snack.</b> Lunch is not provided. No delivery during the day, and that one is firm.</li>` : ""}
              <li style="margin:4px 0">A refillable <b>water bottle</b>, named.</li>
              <li style="margin:4px 0">A <b>pencil</b>. Not a pen.</li>
              <li style="margin:4px 0">A <b>layer</b> \u2014 the building runs cold.</li>
              <li style="margin:4px 0">Anything with a name on it stands a much better chance of coming home.</li>
            </ul>
            <p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">
              <b>What to wear:</b> modest movement clothes with closed-toed shoes or dance shoes. Leggings, joggers or
              athletic shorts with a fitted top or t-shirt, things that stay put when you bend, lift your arms or lie on
              the floor. Hair tied back and off the face. No dangling jewellery or smartwatches. On the build crew,
              closed-toed shoes are the rule, not a suggestion.</p>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:18px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf7f0;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">Where to go</div>
            <div style="font-size:14.5px;color:#2a2a2a;margin-top:6px">${VENUE}</div>
            <div style="margin-top:8px"><a href="${MAP_URL}" style="color:${GOLD};font-size:14px">Get directions &rarr;</a></div>
            <ul style="margin:12px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              ${ARRIVAL.map((l) => `<li style="margin:4px 0">${l}</li>`).join("")}
            </ul>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:14px 32px 6px">
        <p style="margin:0;font-size:13.5px;color:#555;line-height:1.7">
          ${m.__order_id ? `Reference: order ${String(m.__order_id).slice(0, 8).toUpperCase()}<br>` : ""}
          ${m.fsa_eligible === "1" && pi && pi.id ? `Using a Dependent Care FSA? <a href="https://www.northernvirginiaperformingarts.org/api/fsa-receipt?pi=${pi.id}" style="color:${GOLD}">View and print your dependent-care receipt</a> (Tax ID 99-1421341).<br>` : m.fsa_eligible === "1" ? "Using a Dependent Care FSA? Print your dependent-care receipt from your confirmation page (Tax ID 99-1421341).<br>" : ""}
        </p>
      </td></tr>
      <tr><td style="padding:8px 32px 4px">
        <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fdfbf6;border:1px solid #eee5d2;border-radius:10px">
          <tr><td style="padding:16px 18px">
            <div style="font-size:13px;letter-spacing:.08em;text-transform:uppercase;color:#8a7a55">If plans change</div>
            <ul style="margin:8px 0 0;padding-left:18px;font-size:13.5px;color:#555;line-height:1.6">
              <li style="margin:5px 0"><b>All fees are non-refundable</b>, including for missed days or early withdrawal. Registering is a commitment to the full fee.</li>
              <li style="margin:5px 0"><b>Withdrawals must be in writing, at least one month before the program starts.</b> Email <a href="mailto:info@novapa.org" style="color:${GOLD}">info@novapa.org</a> \u2014 only written notice inside that window can be moved to another program.</li>
              <li style="margin:5px 0">Drop out <b>60 or more days before the start</b> with the balance paid in full and what you paid can go toward a future program as a tuition credit, good for one year, administrative fees apply.</li>
              <li style="margin:5px 0">Withdrawals <b>inside 30 days</b> are not eligible for a credit, and partial payments are non-transferable.</li>
              <li style="margin:5px 0">If we cancel for weather or an emergency, a make-up is scheduled rather than a refund issued.</li>
            </ul>
            ${m.insured === "1" ? `<p style="margin:10px 0 0;font-size:13.5px;color:#555;line-height:1.6">
              <b>You bought tuition insurance</b>, so a withdrawal refunds 100% at 90&ndash;76 days before the start,
              75% at 75&ndash;51 days, 50% at 50&ndash;31 days, and 0% inside 30 days. Email us to start a claim.
              The premium itself is non-refundable and is deducted from the refund.</p>` : ""}
            <p style="margin:10px 0 0;font-size:13px;color:#777;line-height:1.6">
              This is a summary. The full terms are at
              <a href="https://www.northernvirginiaperformingarts.org/policies#refunds" style="color:${GOLD}">novapa.org/policies</a>
              and they govern.</p>
          </td></tr>
        </table>
      </td></tr>
      <tr><td style="padding:20px 32px 26px">
        <p style="margin:0;font-size:13px;color:#999;line-height:1.6;border-top:1px solid #eee8dd;padding-top:16px">
          Northern Virginia Performing Arts \xB7 Leesburg, VA<br>
          <a href="mailto:info@novapa.org" style="color:${GOLD}">info@novapa.org</a> \xB7 (571) 571-2120
        </p>
      </td></tr>
    </table>
  </td></tr></table><table role="presentation" cellpadding="0" cellspacing="0" style="margin:22px auto 0"><tr><td style="background:${GOLD};border-radius:8px"><a href="https://www.northernvirginiaperformingarts.org/register/account.html" style="display:inline-block;padding:12px 26px;color:#fff;text-decoration:none;font-weight:700;font-size:14px;font-family:Georgia,serif">View or update in My NOVAPA</a></td></tr></table><p style="font-size:12px;color:#999;text-align:center;margin-top:8px;font-family:Georgia,serif">Your registrations, tickets, and credits live in your account.</p></body></html>`;
}
async function ccFor(email) {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!key || !email) return null;
  try {
    const r = await fetch(
      `https://tlkuqwsqicxcjdmumkje.supabase.co/rest/v1/families?select=cc_email&email=eq.${encodeURIComponent(email.toLowerCase())}&limit=1`,
      { headers: { apikey: key, Authorization: `Bearer ${key}` } }
    );
    const rows = r.ok ? await r.json() : [];
    return rows[0]?.cc_email || null;
  } catch {
    return null;
  }
}
var DCU_PINK = "#ff2d8f";
var DCU_INK = "#0d0d0d";
var DCU_VENUE = "The National Conference Center, 18665 Conference Center Drive, Leesburg, VA 20176";
var DCU_TRACKS = {
  970601: { when: "October 15\u201318, 2026", where: DCU_VENUE, note: null },
  970602: {
    when: "October 24\u201325, 2026",
    where: "Online \u2014 live callback weekend",
    note: "Your join details will be emailed to you before the event."
  },
  // No submission deadline is published on the site, so this promises a
  // follow-up rather than inventing a date.
  970603: {
    when: "Asynchronous \u2014 submit on your own schedule",
    where: "Online",
    note: "Your upload link and submission window will be emailed to you."
  }
};
function dcuConfirmationHtml(m, pi) {
  const paid = pi ? pi.amount_received ?? pi.amount ?? 0 : 0;
  const total = parseInt(m.total_cents || "0", 10) || 0;
  const nInst = parseInt(m.n_installments || "0", 10) || 0;
  const instCents = parseInt(m.installment_cents || "0", 10) || 0;
  const firstInst = parseInt(m.first_installment_utc || "0", 10) || 0;
  const track = DCU_TRACKS[parseInt(m.activity_id || "0", 10)] || {};
  const fmt = (t) => new Date(t * 1e3).toLocaleDateString(
    "en-US",
    { month: "long", day: "numeric", year: "numeric", timeZone: "UTC" }
  );
  const row = (k, v) => `<tr><td style="padding:7px 16px 7px 0;color:#666;font-size:14px">${k}</td><td style="padding:7px 0;font-size:14px;font-weight:600">${v}</td></tr>`;
  const facts = [
    row("Student", m.student_name || "\u2014"),
    row("Track", (m.order_desc || "").split(" \u2014 ").slice(1).join(" \u2014 ") || "DC Unifieds 2026"),
    track.when ? row("When", track.when) : "",
    track.where ? row("Where", track.where) : ""
  ].join("");
  const money2 = [
    row("Total", money(total)),
    row("Paid today", money(paid)),
    nInst ? row(
      "Remaining",
      `${nInst} \xD7 ${money(instCents)}, charged automatically starting ${fmt(firstInst)}`
    ) : ""
  ].join("");
  return `<div style="font-family:Helvetica,Arial,sans-serif;background:#f4f4f5;padding:28px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;margin:0 auto;background:#fff;border-radius:14px;overflow:hidden">
<tr><td style="background:${DCU_INK};padding:26px 28px">
  <div style="color:#fff;font-size:20px;font-weight:800;letter-spacing:.14em">DC UNIFIEDS</div>
  <div style="color:${DCU_PINK};font-size:13px;font-weight:700;margin-top:5px">COLLEGE AUDITIONS 2026</div>
</td></tr>
<tr><td style="padding:28px">
  <div style="font-size:23px;font-weight:800;color:${DCU_INK};margin-bottom:6px">You're registered.</div>
  <p style="font-size:15px;color:#444;line-height:1.6;margin:0 0 22px">
    Thanks${m.parent_name ? ", " + m.parent_name : ""} \u2014 your spot is confirmed. Here are the details.</p>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse">${facts}</table>
  ${track.note ? `<p style="font-size:14px;color:#444;line-height:1.6;margin:18px 0 0">${track.note}</p>` : ""}
  <div style="height:1px;background:#e5e5e5;margin:22px 0"></div>
  <div style="font-size:12px;font-weight:800;letter-spacing:.1em;color:#888;margin-bottom:8px">PAYMENT</div>
  <table role="presentation" cellpadding="0" cellspacing="0" style="width:100%;border-collapse:collapse">${money2}</table>
  ${nInst ? `<p style="font-size:13px;color:#666;line-height:1.6;margin:14px 0 0">
    Installments are charged to the card you used today. All installments are paid in full before the event.</p>` : ""}
  <div style="height:1px;background:#e5e5e5;margin:22px 0"></div>
  <p style="font-size:14px;color:#444;line-height:1.6;margin:0">
    Questions about your registration, or need to change something?
    Email <a href="mailto:support@dcunifieds.com" style="color:${DCU_PINK};font-weight:700">support@dcunifieds.com</a>.</p>
</td></tr>
<tr><td style="padding:18px 28px 24px;background:#fafafa;color:#888;font-size:12px;line-height:1.6">
  DC Unifieds \xB7 ${DCU_VENUE}<br>All sales final. Installment plans must be paid in full prior to the event.
</td></tr>
</table></div>`;
}
async function sendConfirmationEmail(m, pi) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS || !m.email) return;
  const { default: nodemailer } = await import("nodemailer");
  const transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
  });
  if (m.brand === "dcu") {
    await transporter.sendMail({
      from: `DC Unifieds <${process.env.SMTP_USER}>`,
      replyTo: "support@dcunifieds.com",
      to: m.email,
      subject: "You're registered \u2014 DC Unifieds 2026",
      html: dcuConfirmationHtml(m, pi)
    });
    return;
  }
  const cc = await ccFor(m.email);
  let details = [];
  try {
    details = await itemDetails(m, pi);
  } catch (e) {
    console.error("item details failed:", e.message);
  }
  await transporter.sendMail({
    from: `NOVAPA <${process.env.SMTP_USER}>`,
    replyTo: "info@novapa.org",
    to: m.email,
    ...cc ? { cc } : {},
    subject: "You're in \u2014 NOVAPA registration confirmed",
    html: confirmationHtml(m, pi, details)
  });
}

// netlify/functions/dcu-pay.mjs
var DCU_MIN = 970600;
var DCU_MAX = 970699;
var LAST_INSTALLMENT_UTC2 = Date.UTC(2026, 9, 1, 4, 0, 0);
var HOLD_MINUTES = 30;
function svcHeaders() {
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  return { apikey: key, Authorization: `Bearer ${key}`, "Content-Type": "application/json" };
}
async function serviceRpc(fn, args) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/rpc/${fn}`, {
    method: "POST",
    headers: svcHeaders(),
    body: JSON.stringify(args)
  });
  if (!res.ok) throw new Error(`rpc ${fn} failed ${res.status}`);
  const t = await res.text();
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}
function installmentDatesUTC(now = /* @__PURE__ */ new Date()) {
  const out = [];
  const y = now.getUTCFullYear(), mo = now.getUTCMonth();
  for (let i = 1; i <= 12; i++) {
    const t = Date.UTC(y, mo + i, 1, 4, 0, 0);
    if (t > LAST_INSTALLMENT_UTC2) break;
    if (t > now.getTime()) out.push(Math.floor(t / 1e3));
  }
  return out;
}
function splitPrice(totalCents, plan, dates) {
  if (plan !== "deposit" || !dates.length) {
    return { todayCents: totalCents, installmentCents: 0, n: 0, first: 0 };
  }
  const n = dates.length;
  const inst = Math.floor(totalCents / (n + 1));
  return { todayCents: totalCents - inst * n, installmentCents: inst, n, first: dates[0] };
}
var clean = (v, max) => String(v == null ? "" : v).trim().slice(0, max);
async function activityById(activityId) {
  const r = await fetch(
    `${SUPABASE_URL}/rest/v1/activities?id=eq.${activityId}&select=id,name,price_cents,capacity,sold,bookable,hidden`,
    { headers: svcHeaders() }
  );
  const rows = r.ok ? await r.json() : [];
  return rows[0] || null;
}
async function dcuCoupon(code, activityId, email) {
  const c = await serviceRpc("check_coupon", { p_code: code });
  if (!c) return { error: "bad_coupon" };
  let row = null;
  try {
    row = (await (await fetch(
      `${SUPABASE_URL}/rest/v1/coupons?code=ilike.${encodeURIComponent(code)}&select=email_lock,scope_activity_ids&limit=1`,
      { headers: svcHeaders() }
    )).json())?.[0] || null;
  } catch (e) {
    console.error("dcu coupon row lookup", e.message);
    return { error: "bad_coupon" };
  }
  const scope = row?.scope_activity_ids;
  if (!Array.isArray(scope) || !scope.map(Number).includes(Number(activityId))) {
    return { error: "coupon_not_for_this" };
  }
  if (row?.email_lock) {
    const locks = (Array.isArray(row.email_lock) ? row.email_lock : [row.email_lock]).map((e) => String(e).toLowerCase());
    if (!locks.includes(email)) return { error: "coupon_not_yours" };
  }
  const pct = Number(c.pct) || 0;
  const amt = Number(c.amount_cents) || 0;
  if (!pct && !amt) return { error: "bad_coupon" };
  return { pct, amountCents: amt, code: c.code || code };
}
async function quote(req) {
  const url = new URL(req.url);
  const activityId = parseInt(url.searchParams.get("activity_id"), 10);
  const qCoupon = clean(url.searchParams.get("coupon") || "", 40);
  const qEmail = clean(url.searchParams.get("email") || "", 200).toLowerCase();
  if (!activityId || activityId < DCU_MIN || activityId > DCU_MAX) {
    return Response.json({ error: "unknown_activity" }, { status: 400 });
  }
  const act = await activityById(activityId);
  if (!act) return Response.json({ error: "unknown_activity" }, { status: 400 });
  let held = 0;
  try {
    held = await serviceRpc("held_count_activity", { p_activity_id: activityId }) || 0;
  } catch {
  }
  const soldOut = act.capacity != null && (act.sold || 0) + held >= act.capacity;
  const dates = installmentDatesUTC();
  const listCents = act.price_cents || 0;
  let couponCents = 0, couponError = null, couponCode = "";
  if (qCoupon) {
    const cp = await dcuCoupon(qCoupon, activityId, qEmail);
    if (cp.error) couponError = cp.error;
    else {
      couponCents = cp.pct ? Math.round(listCents * Math.min(100, cp.pct) / 100) : Math.min(cp.amountCents, listCents);
      couponCode = cp.code;
    }
  }
  const total = Math.max(0, listCents - couponCents);
  const dep = splitPrice(total, "deposit", dates);
  return Response.json({
    activity_id: act.id,
    name: act.name,
    list_cents: listCents,
    coupon: couponCode,
    coupon_cents: couponCents,
    coupon_error: couponError,
    total_cents: total,
    available: !!act.bookable && !act.hidden && !soldOut,
    plans: {
      full: { today_cents: total },
      // Offered only while a full schedule can still complete before the event.
      deposit: dates.length ? {
        today_cents: dep.todayCents,
        installment_cents: dep.installmentCents,
        n_installments: dep.n,
        installment_dates: dates
      } : null
    }
  });
}
var dcu_pay_default = async (req) => {
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return Response.json({ error: "payments_not_configured" }, { status: 503 });
  }
  if (req.method === "GET") return quote(req);
  if (req.method !== "POST") {
    return Response.json({ error: "method_not_allowed" }, { status: 405 });
  }
  if (!process.env.STRIPE_SECRET_KEY || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
    return Response.json({ error: "payments_not_configured" }, { status: 503 });
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "bad_json" }, { status: 400 });
  }
  const activityId = parseInt(body.activity_id, 10);
  const plan = body.plan === "deposit" ? "deposit" : "full";
  const email = clean(body.email, 200).toLowerCase();
  const parentName = clean(body.parent_name, 100);
  const studentName = clean(body.student_name, 100);
  const phone = clean(body.phone, 40);
  const couponCode = clean(body.coupon, 40);
  if (!activityId || activityId < DCU_MIN || activityId > DCU_MAX) {
    return Response.json({ error: "unknown_activity" }, { status: 400 });
  }
  if (!/^[^@\s]+@[^@\s.]+\.[^@\s]+$/.test(email)) {
    return Response.json({ error: "bad_email" }, { status: 400 });
  }
  if (!studentName || !parentName) {
    return Response.json({ error: "missing_name" }, { status: 400 });
  }
  const act = await activityById(activityId);
  if (!act) return Response.json({ error: "unknown_activity" }, { status: 400 });
  if (!act.bookable || act.hidden) return Response.json({ error: "not_for_sale" }, { status: 409 });
  let held = 0;
  try {
    held = await serviceRpc("held_count_activity", { p_activity_id: activityId }) || 0;
  } catch (e) {
    console.error("held count failed:", e.message);
  }
  if (act.capacity != null && (act.sold || 0) + held >= act.capacity) {
    return Response.json({ error: "sold_out" }, { status: 409 });
  }
  const listCents = act.price_cents || 0;
  if (listCents < 50) return Response.json({ error: "bad_price" }, { status: 500 });
  let couponCents = 0, couponApplied = "";
  if (couponCode) {
    const cp = await dcuCoupon(couponCode, activityId, email);
    if (cp.error) return Response.json({ error: cp.error }, { status: 400 });
    couponCents = cp.pct ? Math.round(listCents * Math.min(100, cp.pct) / 100) : Math.min(cp.amountCents, listCents);
    couponApplied = cp.code;
  }
  const totalCents = Math.max(0, listCents - couponCents);
  if (totalCents > 0 && totalCents < 50) {
    return Response.json({ error: "coupon_too_large" }, { status: 400 });
  }
  const dates = installmentDatesUTC();
  if (plan === "deposit" && !dates.length) {
    return Response.json({ error: "plan_unavailable" }, { status: 409 });
  }
  const price = splitPrice(totalCents, plan, dates);
  const holdRes = await fetch(`${SUPABASE_URL}/rest/v1/holds`, {
    method: "POST",
    headers: { ...svcHeaders(), Prefer: "return=representation" },
    body: JSON.stringify({
      email,
      items: [{ activity_id: activityId, camper: studentName }],
      expires_at: new Date(Date.now() + HOLD_MINUTES * 60 * 1e3).toISOString(),
      status: "active"
    })
  });
  if (!holdRes.ok) {
    console.error("hold insert failed:", await holdRes.text());
    return Response.json({ error: "hold_failed" }, { status: 500 });
  }
  const hold = (await holdRes.json())[0];
  if (totalCents === 0) {
    const meta = {
      hold_id: hold.id,
      plan: "full",
      email,
      parent_name: parentName,
      total_cents: "0",
      coupon: couponApplied,
      coupon_cents: String(couponCents),
      order_desc: `${studentName} \u2014 ${act.name}`.slice(0, 480),
      brand: "dcu",
      activity_id: String(activityId),
      student_name: studentName,
      phone
    };
    try {
      await serviceRpc("confirm_order", {
        p_hold_id: hold.id,
        p_email: email,
        p_parent_name: parentName || null,
        p_plan: "full",
        p_amount_today_cents: 0,
        p_total_cents: 0,
        p_installment_cents: null,
        p_stripe_payment_intent: "free_" + hold.id,
        p_stripe_customer: null,
        p_unit_prices: [0]
      });
    } catch (e) {
      console.error("dcu free order confirm failed:", e.message);
      return Response.json({ error: "order_failed" }, { status: 500 });
    }
    if (couponApplied) {
      try {
        await serviceRpc("redeem_coupon", { p_code: couponApplied, p_applied_cents: couponCents });
      } catch (e) {
        console.error("dcu free order coupon redeem failed:", e.message);
      }
    }
    try {
      await sendConfirmationEmail(meta, { id: "free_" + hold.id });
    } catch (e) {
      console.error("dcu free order email failed:", e.message);
    }
    return Response.json({
      free: true,
      hold_id: hold.id,
      pricing: { name: act.name, total_cents: 0, today_cents: 0, coupon: couponApplied, coupon_cents: couponCents }
    });
  }
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
  const customer = await stripe.customers.create({
    email,
    name: parentName || void 0,
    phone: phone || void 0,
    metadata: { source: "dcunifieds", student_name: studentName }
  });
  const pi = await stripe.paymentIntents.create({
    amount: price.todayCents,
    currency: "usd",
    customer: customer.id,
    // A deposit plan charges the balance off-session on the 1st, so the card
    // has to be saved now — same rule as the camp deposit plans.
    setup_future_usage: plan === "deposit" ? "off_session" : void 0,
    payment_method_types: ["card", "link"],
    description: `DC Unifieds 2026 \u2014 ${plan === "deposit" ? "first payment" : "paid in full"}`,
    statement_descriptor_suffix: "DCUNIFIEDS",
    // No receipt_email on purpose: Stripe's automatic receipt is branded with
    // the Stripe account's business name (NOVAPA), which would undo the point
    // of this whole path. Our own confirmation carries the payment detail.
    metadata: {
      // --- contract read by reg-webhook.mjs; names must match reg-pay.mjs ---
      hold_id: hold.id,
      plan,
      email,
      parent_name: parentName,
      total_cents: String(totalCents),
      installment_cents: String(price.installmentCents),
      n_installments: String(price.n),
      first_installment_utc: String(price.first),
      insurance_cents: "0",
      insured: "0",
      coupon: couponApplied,
      coupon_cents: String(couponCents),
      plan_fee_cents: "0",
      fsa_eligible: "0",
      // college audition coaching is not dependent care
      unit_prices: JSON.stringify([totalCents]),
      monthly_items: "[]",
      n_items: "1",
      order_desc: `${studentName} \u2014 ${act.name}`.slice(0, 480),
      credit_grants: "[]",
      credit_redeems: "[]",
      // --- DC Unifieds additions ---
      brand: "dcu",
      activity_id: String(activityId),
      student_name: studentName,
      phone
    }
  });
  return Response.json({
    client_secret: pi.client_secret,
    hold_id: hold.id,
    pricing: {
      name: act.name,
      total_cents: totalCents,
      today_cents: price.todayCents,
      installment_cents: price.installmentCents,
      n_installments: price.n,
      first_installment_utc: price.first,
      installment_dates: dates
    }
  });
};
var config = { path: "/api/dcu-pay" };
export {
  config,
  dcu_pay_default as default,
  installmentDatesUTC,
  splitPrice
};
