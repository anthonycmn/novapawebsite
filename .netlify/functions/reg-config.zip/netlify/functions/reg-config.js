var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/reg-config.mjs
var reg_config_exports = {};
__export(reg_config_exports, {
  BANDS: () => BANDS,
  CAMP_START: () => CAMP_START,
  CLASS_BILL_ANCHOR_UTC: () => CLASS_BILL_ANCHOR_UTC,
  CLASS_PRICE_CENTS: () => CLASS_PRICE_CENTS,
  CLASS_SEASON_END_UTC: () => CLASS_SEASON_END_UTC,
  COACHING_ID_MAX: () => COACHING_ID_MAX,
  COACHING_ID_MIN: () => COACHING_ID_MIN,
  DAY_CAMP_MAX_CENTS: () => DAY_CAMP_MAX_CENTS,
  DAY_CAMP_PACK_CENTS: () => DAY_CAMP_PACK_CENTS,
  DAY_CAMP_PACK_CREDITS: () => DAY_CAMP_PACK_CREDITS,
  DAY_CAMP_PACK_ID: () => DAY_CAMP_PACK_ID,
  DAY_CAMP_PACK_SIZE: () => DAY_CAMP_PACK_SIZE,
  DAY_CAMP_PACK_SNOW_BONUS: () => DAY_CAMP_PACK_SNOW_BONUS,
  DAY_CAMP_PACK_SNOW_END: () => DAY_CAMP_PACK_SNOW_END,
  DEPOSIT_PER_ITEM_CENTS: () => DEPOSIT_PER_ITEM_CENTS,
  EARLYBIRD_END: () => EARLYBIRD_END,
  INSURANCE_PCT: () => INSURANCE_PCT,
  LAST_INSTALLMENT_UTC: () => LAST_INSTALLMENT_UTC,
  MAX_INSTALLMENTS: () => MAX_INSTALLMENTS,
  MEANGIRLS_ID: () => MEANGIRLS_ID,
  MEANGIRLS_IDS: () => MEANGIRLS_IDS,
  PAY_FULL_CUTOFF_DAYS: () => PAY_FULL_CUTOFF_DAYS,
  PLAN_FEE_PCT: () => PLAN_FEE_PCT,
  PRICE_CENTS: () => PRICE_CENTS,
  PUBLIC_OPEN_AT: () => PUBLIC_OPEN_AT,
  SHOWS: () => SHOWS,
  SIBLING_PCT: () => SIBLING_PCT,
  SPECIAL_PLANS: () => SPECIAL_PLANS,
  SUPABASE_ANON_KEY: () => SUPABASE_ANON_KEY,
  SUPABASE_URL: () => SUPABASE_URL,
  TEEN_CONSERVATORY_IDS: () => TEEN_CONSERVATORY_IDS,
  TEEN_INTENSIVE_IDS: () => TEEN_INTENSIVE_IDS,
  classMonthlyCents: () => classMonthlyCents,
  installmentDates: () => installmentDates,
  isCoachingId: () => isCoachingId,
  isSnowDayName: () => isSnowDayName,
  kidKey: () => kidKey,
  perKidRate: () => perKidRate,
  priceCart: () => priceCart,
  showStartFor: () => showStartFor,
  siblingActive: () => siblingActive,
  specialCovers: () => specialCovers,
  specialFromCouponRow: () => specialFromCouponRow
});
module.exports = __toCommonJS(reg_config_exports);
var SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
var SUPABASE_ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
var PRICE_CENTS = 99500;
var DEPOSIT_PER_ITEM_CENTS = 18e3;
var EARLYBIRD_END = "2026-08-15T23:59:59-04:00";
var PUBLIC_OPEN_AT = "2026-08-01T10:00:00-04:00";
var MAX_INSTALLMENTS = 8;
var PAY_FULL_CUTOFF_DAYS = 14;
var LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
var SPECIAL_PLANS = {
  "SOK20": {
    email: "isabel.castillejo13@gmail.com",
    waivePlanFee: true,
    months: 10
    // Mrs. Sok, approved Jul 30 2026. Her 20% comes from the global
    // show+camp combo now — this code only waives the plan fee and
    // stretches her schedule to 10 months.
  },
  "SMITH20": {
    // Jamie + Christie Smith — Grace. Todd approved 20% off (Aug 5 2026) for
    // Grace doing four productions across summer, fall and spring; the launch
    // ladder lapsed Aug 15 before they registered Frozen + Mermaid, and CJ
    // extended the discount (Aug 17, "Voice Classes" thread). Both household
    // emails are unlocked: the paid summer order lives under Christie's
    // address, the email thread under Jamie's.
    email: ["christieamstadt@gmail.com", "jcs@smith82.com"],
    pctOffList: 20,
    // Plus the retro true-up Todd approved Aug 10: their summer camps were
    // paid at the 15% two-show rate, and with four productions the whole set
    // is 20% — $49.75 x 2 = $99.50 back, delivered as a credit on this
    // checkout (the coupons row has carried the amount since Aug 10).
    creditCents: 9950,
    // months: 5 spreads the Frozen+Mermaid cart Sep-Jan instead of the
    // 1-payment collapse the Sep-15 Frozen start forces — same concession
    // as ANSELL0. Jamie asked Aug 24; Jason approved same day.
    months: 5
  },
  "ANSELL0": {
    email: "ajansell@gmail.com",
    waivePlanFee: true,
    months: 5
    // Andrea Ansell, approved by Todd Aug 7 2026: no 5% plan fee. months: 5
    // spreads her Frozen+Mermaid cart Sep-Jan instead of the 1-payment
    // collapse the Sep-15 Frozen start forces (Jason, Aug 7).
  },
  "ANSELLO": {
    email: "ajansell@gmail.com",
    waivePlanFee: true,
    months: 5
    // Same waiver, letter-O spelling — ANSELL0 ends in a zero that reads as
    // the letter O in most fonts, and Andrea typed the O. Both work.
  }
};
var CLASS_PRICE_CENTS = 9e3;
var CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
var CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;
var SIBLING_PCT = 5;
var INSURANCE_PCT = 10;
var PLAN_FEE_PCT = 5;
var DAY_CAMP_MAX_CENTS = 2e4;
var DAY_CAMP_PACK_ID = 990010;
var DAY_CAMP_PACK_SIZE = 5;
var DAY_CAMP_PACK_CENTS = 34900;
var DAY_CAMP_PACK_CREDITS = 5;
var DAY_CAMP_PACK_SNOW_BONUS = 2;
var DAY_CAMP_PACK_SNOW_END = /* @__PURE__ */ new Date("2026-09-08T03:59:59Z");
var isSnowDayName = (name) => /snow day/i.test(name || "");
var SHOWS = {
  httyd: "How to Train Your Dragon JR.",
  charlie: "Charlie and the Chocolate Factory JR.",
  trolls: "Trolls The Musical JR."
};
var BANDS = ["5-9", "9-12", "12-15", "tech"];
var CAMP_START = {
  httyd: "2027-07-05",
  charlie: "2027-07-19",
  trolls: "2027-08-02"
};
function showStartFor(name) {
  if (/frozen/i.test(name)) return "2026-09-15";
  if (/mermaid/i.test(name)) return "2027-02-03";
  if (/mean girls/i.test(name)) return "2027-06-14";
  if (/sweeney/i.test(name)) return "2026-10-23";
  if (/hadestown/i.test(name)) return "2027-03-05";
  return null;
}
var MEANGIRLS_IDS = [990001, 990002];
var MEANGIRLS_ID = 990001;
var TEEN_CONSERVATORY_IDS = [1960809, 1960811];
var TEEN_INTENSIVE_IDS = [1805731];
var COACHING_ID_MIN = 97e4;
var COACHING_ID_MAX = 979999;
var isCoachingId = (id) => Number.isFinite(id) && id >= COACHING_ID_MIN && id <= COACHING_ID_MAX;
var kindOf = (it) => it.offering_kind || null;
var isCoaching = (it) => kindOf(it) ? kindOf(it) === "coaching" : isCoachingId(it.activity_id);
function specialFromCouponRow(row) {
  if (!row) return null;
  const locked = Array.isArray(row.email_lock) && row.email_lock.length > 0;
  if (!row.pct_off_list && !row.waive_plan_fee && !row.plan_months && !locked) return null;
  const s = {};
  if (locked) s.email = row.email_lock;
  if (row.pct_off_list) s.pctOffList = row.pct_off_list;
  if (row.waive_plan_fee) s.waivePlanFee = true;
  if (row.plan_months) s.months = row.plan_months;
  if (row.balance_cents) s.creditCents = row.balance_cents;
  if (Array.isArray(row.scope_activity_ids) && row.scope_activity_ids.length) s.scopeActivityIds = row.scope_activity_ids;
  if (Array.isArray(row.scope_shows) && row.scope_shows.length) s.scopeShows = row.scope_shows;
  return s;
}
function specialCovers(special, it) {
  if (!special) return false;
  const scoped = special.scopeActivityIds && special.scopeActivityIds.length || special.scopeShows && special.scopeShows.length;
  if (!scoped) return true;
  if (it.activity_id && (special.scopeActivityIds || []).includes(it.activity_id)) return true;
  if (it.show && (special.scopeShows || []).includes(it.show)) return true;
  return false;
}
function perKidRate(nCampsForKid, now = /* @__PURE__ */ new Date()) {
  if (now > new Date(EARLYBIRD_END)) return 0;
  if (nCampsForKid >= 3) return 0.2;
  if (nCampsForKid === 2) return 0.15;
  if (nCampsForKid === 1) return 0.1;
  return 0;
}
function classMonthlyCents(nClassesForKid) {
  if (nClassesForKid <= 0) return 0;
  if (nClassesForKid === 1) return 9e3;
  if (nClassesForKid === 2) return 15900;
  return 19900 + (nClassesForKid - 3) * 4e3;
}
function siblingActive(isBB, now = /* @__PURE__ */ new Date()) {
  return isBB ? now > new Date(EARLYBIRD_END) : true;
}
function installmentDates(startISO, now = /* @__PURE__ */ new Date(), forceMonths = 0) {
  const dates = [];
  let d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1, 4, 0, 0));
  if (forceMonths > 0) {
    while (dates.length < forceMonths) {
      dates.push(Math.floor(d.getTime() / 1e3));
      d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1, 4, 0, 0));
    }
    return dates;
  }
  if (!startISO) return [];
  const start = /* @__PURE__ */ new Date(startISO + "T00:00:00-04:00");
  const lastOk = new Date(Math.min(
    start.getTime() - PAY_FULL_CUTOFF_DAYS * 864e5,
    LAST_INSTALLMENT_UTC
  ));
  while (d <= lastOk && dates.length < MAX_INSTALLMENTS) {
    dates.push(Math.floor(d.getTime() / 1e3));
    d = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth() + 1, 1, 4, 0, 0));
  }
  return dates;
}
var kidKey = (it) => it && it.ci != null ? "i" + it.ci : it && it.camper || "?";
function priceCart(cart, plan, opts = {}) {
  const now = opts.now || /* @__PURE__ */ new Date();
  const insurance = !!opts.insurance;
  const special = opts.special || null;
  const couponPct = special ? 0 : Math.min(100, Math.max(0, opts.couponPct || 0));
  const couponFixed = special ? Math.max(0, special.creditCents || 0) : Math.max(0, opts.couponFixedCents || 0);
  const priorCampsByKid = opts.priorCampsByKid || {};
  const priorShowsByKid = opts.priorShowsByKid || {};
  const isDayCampItem = (it) => kindOf(it) ? kindOf(it) === "day_camp" : !it.show && !isCoaching(it) && (it.price_cents || 0) <= DAY_CAMP_MAX_CENTS;
  const isCounted = (it) => it.show || !isDayCampItem(it) && !isCoaching(it) && it.activity_id !== DAY_CAMP_PACK_ID;
  const countByKid = {};
  for (const it of cart) if (isCounted(it)) {
    const k = kidKey(it);
    countByKid[k] = (countByKid[k] || 0) + 1;
  }
  for (const k of Object.keys(countByKid)) {
    countByKid[k] += (priorCampsByKid[k] || 0) + (priorShowsByKid[k] || 0);
  }
  const kidOrder = [...new Set(cart.map(kidKey))];
  const firstKid = kidOrder[0];
  const priced = cart.map((it) => {
    if (it.activity_id === DAY_CAMP_PACK_ID) {
      return { ...it, unit: DAY_CAMP_PACK_CENTS, rate: 0, daycamp: true, pack: true };
    }
    if (it.show) {
      const kid2 = kidKey(it);
      const rate2 = perKidRate(countByKid[kid2], now);
      let unit2 = Math.round(PRICE_CENTS * (1 - rate2));
      if (rate2 === 0 && siblingActive(true, now) && kid2 !== firstKid) {
        unit2 = Math.round(unit2 * (1 - SIBLING_PCT / 100));
      }
      return { ...it, unit: unit2, rate: rate2 };
    }
    if (isCoaching(it)) {
      return { ...it, unit: it.price_cents || 0, rate: 0, daycamp: true, coaching: true };
    }
    if (isDayCampItem(it)) {
      let unit2 = it.price_cents;
      if (kidKey(it) !== firstKid) {
        unit2 = Math.round(unit2 * (1 - SIBLING_PCT / 100));
      }
      return { ...it, unit: unit2, rate: 0, daycamp: true };
    }
    const kid = kidKey(it);
    const rate = perKidRate(countByKid[kid], now);
    let unit = Math.round((it.price_cents || 0) * (1 - rate));
    if (rate === 0 && siblingActive(true, now) && kid !== firstKid) {
      unit = Math.round(unit * (1 - SIBLING_PCT / 100));
    }
    return { ...it, unit, rate };
  }).map((it) => {
    if (!special || !special.pctOffList || it.daycamp || !specialCovers(special, it)) return it;
    const list = it.show ? PRICE_CENTS : it.price_cents || 0;
    const rate = special.pctOffList / 100;
    return { ...it, unit: Math.round(list * (1 - rate)), rate };
  });
  const byKidDc = {};
  for (const it of priced) {
    if (it.daycamp && !it.coaching && !it.pack) (byKidDc[kidKey(it)] = byKidDc[kidKey(it)] || []).push(it);
  }
  const dayPacksByKid = {};
  for (const k of Object.keys(byKidDc)) {
    const arr = byKidDc[k];
    const packs = Math.floor(arr.length / DAY_CAMP_PACK_SIZE);
    if (!packs) continue;
    dayPacksByKid[k] = packs;
    arr.sort((a, b) => b.unit - a.unit);
    const packed = arr.slice(0, packs * DAY_CAMP_PACK_SIZE);
    const target = packs * DAY_CAMP_PACK_CENTS;
    const packedSum = packed.reduce((sum, it) => sum + it.unit, 0);
    let acc = 0;
    packed.forEach((it, i) => {
      const u = i === packed.length - 1 ? target - acc : Math.round(it.unit * target / packedSum);
      acc += u;
      it.unit = u;
      it.pack = true;
    });
  }
  const creditsByKid = opts.creditsByKid || {};
  const creditsUsed = {};
  const redeemable = priced.filter((it) => it.daycamp && !it.coaching && !it.pack).sort((a, b) => b.unit - a.unit);
  for (const it of redeemable) {
    const k = kidKey(it);
    const bal = creditsByKid[k];
    if (!bal) continue;
    const kind = isSnowDayName(it.name) ? "snow" : "day";
    const used = creditsUsed[k] || (creditsUsed[k] = { day: 0, snow: 0 });
    if ((bal[kind] || 0) - used[kind] > 0) {
      used[kind] += 1;
      it.unit = 0;
      it.credited = true;
    }
  }
  const grossSubtotal = priced.reduce((s, it) => s + it.unit, 0);
  const couponCents = couponPct ? Math.round(grossSubtotal * couponPct / 100) : Math.min(couponFixed, grossSubtotal);
  const subtotal = grossSubtotal - couponCents;
  const couponFactor = grossSubtotal > 0 ? subtotal / grossSubtotal : 1;
  const listInsurableCents = priced.reduce(
    (s, it) => s + (it.daycamp ? 0 : it.show ? PRICE_CENTS : it.price_cents || 0),
    0
  );
  const insuranceCents = insurance ? Math.round(listInsurableCents * INSURANCE_PCT / 100 * (1 - couponPct / 100)) : 0;
  const totalCents = subtotal + insuranceCents;
  const starts = cart.map((it) => it.show ? CAMP_START[it.show] : it.start || showStartFor(it.name || "")).filter(Boolean).sort();
  const schedule = installmentDates(starts[0], now, special && special.months || 0);
  const payFullOnly = schedule.length === 0;
  if (plan === "full" || payFullOnly) {
    return {
      items: priced,
      creditsUsed,
      dayPacksByKid,
      subtotal,
      couponCents,
      insuranceCents,
      totalCents,
      planFeeCents: 0,
      todayCents: totalCents,
      installmentCents: 0,
      installmentDatesUTC: [],
      payFullOnly,
      plan: "full"
    };
  }
  const dayCampCents = priced.reduce((s, it) => s + (it.daycamp ? it.unit : 0), 0);
  const planFeeCents = special && special.waivePlanFee ? 0 : Math.round(subtotal * PLAN_FEE_PCT / 100);
  if (special) {
    const planCount = priced.filter((it) => !it.daycamp).length;
    const depositCents = Math.min(DEPOSIT_PER_ITEM_CENTS * planCount + dayCampCents, subtotal);
    const remainder = subtotal - depositCents;
    if (remainder <= 0) {
      return {
        items: priced,
        creditsUsed,
        dayPacksByKid,
        subtotal,
        couponCents,
        insuranceCents,
        totalCents,
        planFeeCents: 0,
        todayCents: totalCents,
        installmentCents: 0,
        installmentDatesUTC: [],
        payFullOnly: false,
        plan: "full"
      };
    }
    return {
      items: priced,
      creditsUsed,
      dayPacksByKid,
      subtotal,
      couponCents,
      insuranceCents,
      totalCents: totalCents + planFeeCents,
      planFeeCents,
      todayCents: depositCents + insuranceCents,
      installmentCents: Math.max(0, Math.ceil((remainder + planFeeCents) / schedule.length)),
      installmentDatesUTC: schedule,
      payFullOnly: false,
      plan: "deposit"
    };
  }
  const financeable = subtotal - dayCampCents + planFeeCents;
  const payments = schedule.length + 1;
  const installmentCents = Math.floor(financeable / payments);
  const todayShare = financeable - installmentCents * schedule.length;
  if (installmentCents <= 0) {
    return {
      items: priced,
      creditsUsed,
      dayPacksByKid,
      subtotal,
      couponCents,
      insuranceCents,
      totalCents,
      planFeeCents: 0,
      todayCents: totalCents,
      installmentCents: 0,
      installmentDatesUTC: [],
      payFullOnly: false,
      plan: "full"
    };
  }
  return {
    items: priced,
    creditsUsed,
    dayPacksByKid,
    subtotal,
    couponCents,
    insuranceCents,
    totalCents: totalCents + planFeeCents,
    planFeeCents,
    todayCents: todayShare + insuranceCents + dayCampCents,
    installmentCents,
    installmentDatesUTC: schedule,
    payFullOnly: false,
    plan: "deposit"
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  BANDS,
  CAMP_START,
  CLASS_BILL_ANCHOR_UTC,
  CLASS_PRICE_CENTS,
  CLASS_SEASON_END_UTC,
  COACHING_ID_MAX,
  COACHING_ID_MIN,
  DAY_CAMP_MAX_CENTS,
  DAY_CAMP_PACK_CENTS,
  DAY_CAMP_PACK_CREDITS,
  DAY_CAMP_PACK_ID,
  DAY_CAMP_PACK_SIZE,
  DAY_CAMP_PACK_SNOW_BONUS,
  DAY_CAMP_PACK_SNOW_END,
  DEPOSIT_PER_ITEM_CENTS,
  EARLYBIRD_END,
  INSURANCE_PCT,
  LAST_INSTALLMENT_UTC,
  MAX_INSTALLMENTS,
  MEANGIRLS_ID,
  MEANGIRLS_IDS,
  PAY_FULL_CUTOFF_DAYS,
  PLAN_FEE_PCT,
  PRICE_CENTS,
  PUBLIC_OPEN_AT,
  SHOWS,
  SIBLING_PCT,
  SPECIAL_PLANS,
  SUPABASE_ANON_KEY,
  SUPABASE_URL,
  TEEN_CONSERVATORY_IDS,
  TEEN_INTENSIVE_IDS,
  classMonthlyCents,
  installmentDates,
  isCoachingId,
  isSnowDayName,
  kidKey,
  perKidRate,
  priceCart,
  showStartFor,
  siblingActive,
  specialCovers,
  specialFromCouponRow
});
