
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};

// netlify/functions/reg-config.mjs
var SUPABASE_URL, SUPABASE_ANON_KEY, LAST_INSTALLMENT_UTC, CLASS_BILL_ANCHOR_UTC, CLASS_SEASON_END_UTC;
var init_reg_config = __esm({
  "netlify/functions/reg-config.mjs"() {
    SUPABASE_URL = "https://tlkuqwsqicxcjdmumkje.supabase.co";
    SUPABASE_ANON_KEY = "sb_publishable_8ar97CkK-C0YlWuOGtI_tA_mwTDVE6H";
    LAST_INSTALLMENT_UTC = Date.UTC(2027, 4, 1, 4, 0, 0);
    CLASS_BILL_ANCHOR_UTC = Date.UTC(2026, 9, 1, 4, 0, 0) / 1e3;
    CLASS_SEASON_END_UTC = Date.UTC(2027, 5, 30, 4, 0, 0) / 1e3;
  }
});

// netlify/functions/reg-campaign-test.mjs
init_reg_config();

// netlify/functions/reg-campaign.mjs
init_reg_config();
import crypto from "node:crypto";
var FROM = "Broadway Bound <hello@mail.novapa.org>";
var REPLY_TO = "info@novapa.org";
async function mailer() {
  const { default: nodemailer } = await import("nodemailer");
  return nodemailer.createTransport({
    host: "smtp.resend.com",
    port: 465,
    secure: true,
    auth: { user: "resend", pass: process.env.RESEND_API_KEY }
  });
}
function unsubToken(email) {
  return crypto.createHmac("sha256", process.env.SUPABASE_SERVICE_ROLE_KEY).update(email.toLowerCase()).digest("hex").slice(0, 24);
}
function unsubUrl(email) {
  return `https://novapa.org/api/unsubscribe?e=${encodeURIComponent(email.toLowerCase())}&t=${unsubToken(email)}`;
}
function renderEmail(rawBody, vars) {
  let body = rawBody;
  const personal = body.startsWith("[plain]\n");
  if (personal) body = body.slice("[plain]\n".length);
  for (const [k, v] of Object.entries(vars)) body = body.replaceAll(`{${k}}`, v);
  const LINK = /\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g;
  const IMG_LINE = /^!\[([^\]]*)\]\((https?:\/\/[^)\s]+)\)$/;
  const text = body.split("\n").filter((l) => !IMG_LINE.test(l.trim())).join("\n").replace(LINK, (_, t, u) => `${t}: ${u}`);
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const inline = (s) => esc(s).replace(LINK, '<a href="$2" style="color:#0b5fff">$1</a>');
  let footer = false;
  const blocks = body.split(/\n\s*\n/).map((block) => {
    let lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
    if (lines[0] === "--") {
      footer = true;
      lines = lines.slice(1);
    }
    if (!lines.length) return "";
    const base = footer ? "font-size:13px;color:#8a93a3" : "font-size:16px;color:#1a2233";
    const img = lines.length === 1 && lines[0].match(IMG_LINE);
    if (img) {
      return `<p style="margin:0 0 22px"><img src="${esc(img[2])}" alt="${esc(img[1])}" width="520" style="width:100%;max-width:520px;height:auto;border-radius:12px;display:block;margin:0 auto"></p>`;
    }
    const imgs = lines.map((l) => l.match(IMG_LINE)).filter(Boolean);
    if (imgs.length > 1 && imgs.length === lines.length) {
      const w = Math.floor(520 / imgs.length) - 8;
      return `<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="margin:0 0 20px"><tr>` + imgs.map((m) => `<td align="center" style="padding:0 4px" valign="top"><img src="${esc(m[2])}" alt="${esc(m[1])}" width="${w}" style="width:100%;max-width:${w}px;height:auto;border-radius:10px;display:block"></td>`).join("") + `</tr></table>`;
    }
    const btn = !personal && lines.length === 1 && lines[0].match(/^\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)$/);
    if (btn) {
      return `<p style="text-align:center;margin:28px 0"><a href="${esc(btn[2])}" style="display:inline-block;background:#f2c94c;color:#0b1b33;font-weight:700;font-size:16px;padding:13px 30px;border-radius:8px;text-decoration:none">${esc(btn[1])}</a></p>`;
    }
    if (lines.every((l) => l.startsWith("* "))) {
      return `<ul style="margin:0 0 18px;padding-left:22px;${base}">` + lines.map((l) => `<li style="margin:5px 0">${inline(l.slice(2))}</li>`).join("") + `</ul>`;
    }
    const bold = lines.length === 1 && lines[0].endsWith(":") && lines[0].length < 40;
    return `<p style="margin:0 0 18px;${base}${bold ? ";font-weight:700" : ""}">${lines.map(inline).join("<br>")}</p>`;
  }).filter(Boolean).join("\n");
  const html = personal ? `<!doctype html><html><body style="margin:0;padding:0"><div style="max-width:560px;padding:8px 4px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;line-height:1.55">
${blocks}
</div></body></html>` : `<!doctype html><html><body style="margin:0;padding:0;background:#f6f7f9"><div style="max-width:560px;margin:0 auto;padding:32px 20px;font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;line-height:1.55">
<p style="text-align:center;margin:0 0 22px"><img src="https://www.northernvirginiaperformingarts.org/favicon.png" width="56" height="56" alt="NOVAPA" style="display:inline-block"></p>
${blocks}
</div></body></html>`;
  return { text, html };
}

// netlify/functions/reg-campaign-test.mjs
async function isAdmin(userToken) {
  const r = await fetch(`${SUPABASE_URL}/rest/v1/rpc/is_admin`, {
    method: "POST",
    headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${userToken}`, "Content-Type": "application/json" },
    body: "{}"
  });
  return r.ok && (await r.text()).trim() === "true";
}
var reg_campaign_test_default = async (req) => {
  if (req.method !== "POST") return new Response("method", { status: 405 });
  const auth = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!auth || !await isAdmin(auth)) return Response.json({ error: "not admin" }, { status: 403 });
  let body = {};
  try {
    body = await req.json();
  } catch {
  }
  if (!body.test_to || !body.campaign) return Response.json({ error: "bad_request" }, { status: 400 });
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const rows = await (await fetch(`${SUPABASE_URL}/rest/v1/campaigns?name=eq.${encodeURIComponent(body.campaign)}&limit=1`, {
    headers: { apikey: key, Authorization: `Bearer ${key}` }
  })).json();
  if (!rows.length) return Response.json({ error: "campaign_not_found" }, { status: 404 });
  const c = rows[0];
  const t = await mailer();
  const unsub = unsubUrl(String(body.test_to));
  const { text, html } = renderEmail(c.body, { first_name: "Jason", unsub_url: unsub, email: encodeURIComponent(String(body.test_to)) });
  await t.sendMail({
    from: FROM,
    replyTo: REPLY_TO,
    to: String(body.test_to),
    subject: c.subject,
    text,
    html,
    headers: { "List-Unsubscribe": `<${unsub}>`, "List-Unsubscribe-Post": "List-Unsubscribe=One-Click" }
  });
  return Response.json({ ok: true, test: true, to: body.test_to, from: FROM });
};
export {
  reg_campaign_test_default as default
};
